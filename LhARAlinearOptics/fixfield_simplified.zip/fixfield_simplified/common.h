/*
 *  common.h
 *  Fixfield
 *
 *  Copyright 2009 Kyoto University. All rights reserved.
 *
 */

#ifndef COMMON
#define COMMON
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <complex.h>

/* ******************** strutures ******************** */
struct Framework {
	double xc;						//[m] position of the framwork origin in the global framework
	double yc;						// .
	double ae;						//[rad] angle between the framework and the global framework
};

struct Particle {
	struct Framework fwk;			//local framework in which particle coorinates are given
	int status;						//particle status ("alive" or lost)
	int hat;						//Not accelerated particles (and not kicked in thin-dipole):	-1 write related data in trackout.dat,	-2 don't write related data in trackout.dat, -3 compute max angle
									//Accelerated particles:		1 write related data in trackout.dat,	2 don't write related data in trackout.dat, 3 init t0 of RF cavities
	double m0;						//[kg] tracked particle rest mass
	double q;						//[C] tracked particle charge
	//++//unknowns of the differential equations to integrate://++//
	double x;						//[m] particle coordinates in cartesian coordinates
    double y;						//[m]
	double z;						//[m]
	double ux;						//[\] px/ptot (momentum ratio)
	double uy;						//[\] py/ptot
	double uz;						//[\] pz/ptot
	double brho;					//[T.m] particle rigidity
	double t;						//[s] particle time of flight since the origin of time (generally injection of the "on-phase" particle)
	//++//variable of the differential equation://++//
	double s;						//[m] particle length of flight since the new turn
};

struct Beam {
	int npart;						//number of particles in the bunch (>= 1) 
	struct Particle *part;			//array to store all the bunch's particles - memory has to be allocated for this array
};

struct Collimator {
	double rmin;					//[m]
	double rmax;					//[m]
	double zmin;					//[m]
	double zmax;					//[m]
};

struct Boundary {
	double thmax;					//[rad]
	double ymax;					//[m]
};

struct Mapnode {
	double coord[3];				//coord[0,1,2] =[x,y,z] in cartesian maps, [r,th,z] in cylindrical maps
	double b[3];					//b[0,1,2] =[bx,by,bz] in cartesian maps, [br,bth,bz] in cylindrical maps
};

struct Map {
	int nnodes[3];					//number of nodes in x, y, z /or r, th, z dimensions
	int sym;						//YES if median plane symmetry assumed, NO if not.
	double stepsize[3];				//stepsize[0,1,2] =[step_x,step_y,step_z] in cartesian maps, [step_r,step_th,step_z] in cylindrical maps (all in I.S. unites)
	double mapdim[6];				//mapdim[1...6] = [xmin, xmax, ymin, ymax, zmin, zmax] in cartesian maps, [rmin, rmax, thmin, thmax, zmin, zmax]  in cylindrical maps (all in I.S. unites)
	struct Mapnode ***node;			//memory to be allocated
};

struct Cavity {
	char keyword[KEYWORDL];			//cavity name (not used yet)
	double frf;						//[Hz]
	double v0;						//[V]
	double phi0;					//[rad]
	double t0;						//[s]
};

struct Cell {
	char keyword[KEYWORDL];
	double stepsize;				//[m] stepsize
	struct Framework framework;
	double deltar;					//[m]
	struct Collimator collim;
	struct Boundary boun;
	int nbcomp;						//[/] number of components in the Cell
	
	//instrument (pickup of cup)
	int instrutype;					//=NO for no istrument, =PICKUP for a pickup, =CUP for a Faraday cup.
	struct Boundary *instru;
	
	//if field is obtained from analytical field modeld: 
	double **mpara;					//components body parameters, memory to be allocated
	double **mpolyn;				//polynom components parameters of 'polyn' poles, memory to be allocated
	double **efben;					//components entrance effective filed boundary (EFB) parameters, memory to be allocated
	double **efbex;					//components exit effective filed boundary (EFB) parameters, memory to be allocated
	
	//3D translation and rotation of each magnetic pole to simulate alignment errors
	int doyou_err;				//switch, error are included in the tracking only if doyou_errtrack == YES (see get_field.c)
	double **alierror;			//memory to be allocated: 
								//alierror[][0] not used, alierror[][1],[2], and [3] define the pole translation (unit = [m,m,m]); 
								//rotation of the magnetic element of an angle theta = alierror[][4] (unit = [rad], right-hand oriented) 
								//is done around and axe passing by the point ([5],[6],[7]) (unit = [m,m,m]) and parallel to the unit vector ([8],[9],[10]). 
	
	//if field is obtained from interpolation in a field map, memory to be allocated:
	struct Map map;
	
	//if the Cell is an RF cavity
	struct Cavity *cav;				//array of "lattice periodicity" number of cavity. memory to be allocated
};

struct Lattice {
	int nbcell;						//number of Cells in the Lattice
	int periodicity;				//periodicity
	int cellnumber;					//when periodicity > 1, it is necessary to identify the cell number for RF phase computation issues
	struct Cell *cell;				//lattice Cells, memory to be allocated
};

/* ******************** global variables (the fewer the better!) ******************** */
//int debug;					//NO: no debug output, YES: maximum output (especially init.c)
//int doyou_long_boun_sym;	//YES: field symmetry at longitudinal boundary, NO: field=0 outside of cell
//int sound_option;			//sound option YES:ON, NO:OFF 
//int write_enge;				//flag to write in spi_enge the fields components (in "data/field_spi_enge.dat")
//int print_color;			//flag to use color in terminal output
//double force_spi_deg; 		//spiral angle in [deg] to force spiral global theta calculation in trackout
//double force_spi_r0; 		//r0 in [m] to force spiral global theta calculation in trackout
/* ******************** global functions ******************** */

//m_alloc.c
void alloc_beam(struct Beam *beam, int npart);
void free_beam(struct Beam *beam);
void copy_beam(struct Beam *copy, struct Beam *ini_beam);
struct Cell *alloccell(int nbcell);
double **allocmatrix(int n1, int n2);
struct Map allocmap(int nnode_r, int nnode_th, int nnode_z);
struct Cavity *alloccav(int periodicity);
struct Boundary *alloc_instru(int instrutype);
void free_map(struct Map *map, int nnode_r, int nnode_th);
void free_latt(struct Lattice *cell);
void copy_latt(struct Lattice *copy, struct Lattice *ini_latt);
void copy_latt_1period(struct Lattice *reference_latt, struct Lattice *copy_latt);
void copy_latt_n_first_cells(struct Lattice *copy, struct Lattice *ini_latt, int nb_cell);
void copy_cell_map(struct Cell *copycell, struct Cell *inicell);
void gene_alignerror_latt(struct Lattice *reference_latt, struct Lattice *err_latt);

//frameworks.c
void getready_part(struct Particle *part, struct Cell *cell);
void update_part(int awd_answer, struct Particle *part, struct Cell *cell);
void fwk_pt_loctoglob(double *x, double *y, struct Framework *framework);
void fwk_vect_loctoglob(double *x, double *y, struct Framework *framework);
void fwk_pt_globtoloc(double *x, double *y, struct Framework *framework);
void fwk_vect_globtoloc(double *x, double *y, struct Framework *framework);
void fwk_pt_fwktofwk(double *x, double *y, struct Framework *fwk1, struct Framework *fwk2);
void fwk_vect_fwktofwk(double *x, double *y, struct Framework *fwk1, struct Framework *fwk2);
void changefwk_part(struct Particle *part, struct Framework *newfwk);
void find_fwk_exitface(struct Framework *fwk_exitface, struct Cell *cell);
void find_fwk_instru(struct Framework *fwk_exitface, struct Cell *cell);
void latt_move_exit_to_entrance(struct Lattice *latt);
void shitf_fwk(struct Framework *fwk, double deltax);

//toolbox.c
void errorstop(char *error_text);
void newline(FILE *rfile);
void emptyfile(char *filename);
char* itoa(int value, char* result, int base);
char* my_itoa(int i);
void print_latt_para(char *filename, char *lattname, struct Lattice *latt);
void print_rf_cell(char *filename, char *cellname, struct Cell *cell, int periodicity);
void print_cell_para(char *filename, char *cellname, struct Cell *cell);
void print_collimator_cell(char *filename, char *cellname, struct Cell *cell);
int nb_poles_latt(struct Lattice *latt);
void get_x0_y0_from_pole(struct Cell *cell, int pole, double *x_0, double *y_0);
void print_alierror_para(char *filename, struct Lattice *err_latt);
void print_beam_para(char *beamname, struct Beam *beam);
void print_part_para(char *partname, struct Particle *part);
void print_get_bfield(double x, double y, double z, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
void printf_mat_1dim_complex(char *message, double complex *m, int nb_dim, char *name_mat, int option, char *txtout);
void printf_mat_4d_real(char *message, double m[4][4], char *name_mat, char *txtout);
double round_nb(double value, int nb_decimal);
int test_power2(unsigned int x);
void get_ebg_part(double *e_tot, double *beta, double *gamma, struct Particle *part);
void twissTMtransform(double m[2][2], double twm[3][3]);
void fix_boundingbox(char *txtfilename, int doyouprint);
void say(char *text_say);
void convert_file(char *ori_file, char *final_file, int resolution, int doyouprint);
double comp_step(double val_start, double val_end, int nvalues, int doyouprintf);
void write_ellipse(char *wfilename, double emitt_pimmmrad, double beta, double alpha, double xcenter, double ycenter);
void write_ellipse2(char *wfilename, double emitt_pimmmrad, double beta, double alpha, double xcenter, double ycenter);
void write_ellipse_mm_mevc(char *wfilename, double emitt_pimmmrad, double beta, double alpha, double xcenter, double ycenter, double pcenter);
int get_nb_lines_file(char *txtfilename);
void pick_with_para_from_trackout(FILE *fp, char keyword[][20], int nb_para_taken, double para[], int total_nb_para);
void pick_columns_from_file(FILE *fp, int para_list_nb[], int nb_para_taken, double para[], int total_nb_para);
void get_boundaries_from_file(char *txtfilename, int para_list_nb[], int nb_para_taken, double min[], double max[], int total_nb_para);
void find_range_column_2files(char *range, char *file1, int column1, int nb_tot_column1, char *file2, int column2, int nb_tot_column2, int flag_extent, int flag_sym_around_0);
int para_clm_trackout(char *keyword);
void get_smax_file(char *txtfilename, double *smax);
void get_betamax_file(char *txtfilename, double *betamax);
void get_betax_z_max_file(char *txtfilename, double *betax_max, double *betaz_max);
void get_dispmax_file(char *txtfilename, double *dispmax);
void get_dispmin_file(char *txtfilename, double *dispmin);
void get_xrange(char *txtfilename, char *xrange);
void get_betarange(char *txtfilename, char *betarange);
void get_disprange(char *txtfilename, char *disprange);
void get_dispmax_file_4d(char *txtfilename, double *dispxmax, double *dispzmax);
void get_dispmin_file_4d(char *txtfilename, double *dispxmin, double *dispzmin);
void get_disprange_4d(char *txtfilename, char *disprangehor, char *disprangevert);
void get_tune_range(char *txtfilename, double *qx_min, double *qx_max, double *qz_min, double *qz_max, double *qx_tot_min, double *qx_tot_max, double *qz_tot_min, double *qz_tot_max);
void get_space_range(char *aspectfile, double *xmin, double *xmax, double *ymin, double *ymax);
void find_boundaries_column_file(char *file, double *min, double *max, int column, int nb_tot_column);
void find_range_column_file(char *file, char *range, int column, int nb_tot_column, int flag_extent, int flag_sym_around_0);
void find_boundaries_heated_map_file(char *file, double *xmin, double *xmax, double *ymin, double *ymax, double *val_min, double *val_max);
void find_boundaries_heated_map_file_range(char *file, char *xrange, char *yrange, double *val_min, double *val_max);
void find_ur_zero_from_trackout(char *trackout, double *theta, double *rco, double *b_boun);
int adjust_r0_with_b0(struct Lattice *latt, struct Particle *part, double r_co, double *r0, double eps_clo);
int adjust_r0_with_b0_ffag_spi(struct Lattice *latt, struct Particle *part, double r_co, double eps_clo, double eps_r0);
int adjust_rav_with_b0_ffag_spi(struct Lattice *latt, struct Particle *part, double r_co_av, double eps_clo, double eps_r0);
void reverse_latt(struct Lattice *new_latt, struct Lattice *latt);
double rec_mul_minus(double a, int i);
double rec_mul_plus(double a, int i);
int fit_ellipse1(int *n, double *x, double *y, double *p);
int fit_ellipse2(int *n, double *x, double *y, double *p, double *e, int *m);
void get_betamin_file(char *txtfilename, double *betamin);
void comp_phase_space_coord(double *x, double *xprime, double *z, double *zprime, double test_x, double test_z, double test_ux, double test_uy, double test_uz, double x_ref, double xprime_ref, double z_ref, double zprime_ref);
double compute_av_radius_from_trackout_1cell(char *trackout, int doyouprintf);
void compute_av_min_max_radius_from_trackout_1cell(char *trackout, double *r_av, double *rmin, double *rmax, int doyouprintf);
double compute_s_latt(struct Particle *part, struct Lattice *latt);
void compute_sxy_latt(struct Particle *part, struct Lattice *latt, double *s, double *x, double *y);
void int_bz_liney_cell(double *intbdl, double *intbdlabs, double x, double ymin, double ymax, int nstep, struct Cell *cell,void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
void int_bz_radius_cell(double *intbdl, double *intbdlabs, double r, double thmin, double thmax, int nstep, struct Cell *cell,void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
void int_bz_max_min_radius_cell(double *intbdl, double *intbdlabs, double *bmax, double *bmin, double r, double thmin, double thmax, int nstep, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
double comp_k_value_local(double r, double deltar, double bdeltar, double b);
double comp_k_value_local_2ndorder(double r, double b0, double deltar, double bdeltar, double b);
void k_loc_cell2(char *outfilename, double thmin, double thmax, int nstep_th, double rmin, double rmax, int nstep_r, double deltar, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
void compute_local_k_difference(char *text_write, char *case_name, double k_target);
void compute_k_value_heatmap(char *textfile, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int), 
	double r0, double rmax, int nbr, double th0, double thmax, int nbth, double z0, double deltar, double spi_angle_deg);
void print_get_bfield_across_cell_radius(char *fileout, double r, double thmax_deg, int nbsteps, double z, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
void print_get_bfield_straight_line(char *fileout, double x, double ymax, int nbsteps, double z, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
void print_get_bfield_across_cell_radius_difference(char *fileout, double r, double thmax_deg, int nbsteps, double z, struct Cell *cell1, void(*add_contribution_comp1)(double,double,double,double*,double*,double*,struct Cell*,int), struct Cell *cell2, void(*add_contribution_comp2)(double,double,double,double*,double*,double*,struct Cell*,int), int flip);
void print_get_bfield_straight_line_difference(char *fileout, double x, double ymax, int nbsteps, double z, struct Cell *cell1, void(*add_contribution_comp1)(double,double,double,double*,double*,double*,struct Cell*,int), struct Cell *cell2, void(*add_contribution_comp2)(double,double,double,double*,double*,double*,struct Cell*,int), int flip);
void compute_fieldmap(char *filename, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int), double r0, double rmax, int nbr, double th0, double thmax, int nbth, double z0, double zmax, int nbz);
void compute_map(char *filename, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int), double unitlength, double bscale, int loop_order, int line_order, int header_skip, double rstart, double rend, int nbr, double rshift, double thstart, double thend, int nbth, double thshift, double zstart, double zend, int nbz, double zshift);
void compute_map_polar(char *filename, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int), 
	double rstart, double rend, int nbr, double rshift, double thstart, double thend, int nbth, double thshift, double zstart, double zend, int nbz, double zshift);
void compute_str_map(char *filename, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int), double unitlength, double bscale,
	int loop_order, int line_order, int header_skip, double xstart, double xend, int nbx, double ystart, double yend, int nby, double zstart, double zend, int nbz);
void test_field_maxwell(double x, double y, double z, double dx, double dy, double dz, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
void test_field_maxwell2(double x, double y, double z, double dx, double dy, double dz, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
double maxwell_test_max(double x, double y, double z, double dx, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int), int doyouglob);
int maxwell_test(double x, double y, double z, double dx, double dy, double dz, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int),double *divb, double *curlbx, double *curlby, double *curlbz, int doyouglob);
void maxwell_test_txtfile(char *textfile, double x, double y, double z, double dx, double dy, double dz, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
double maxwell_test_across_cell_max(double r, double z, double dx, int th_step, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
void maxwell_test_heatmap(char *extension, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int),
	double r0, double rmax, int nbr, double th0, double thmax, int nbth, double z0, double zmax, int nbz, int doyoucirc, double dx, double dy, double dz, int doyouglob);


//init.c
void gene_singlepart(struct Particle *part, double m0, double q, double x, double y, double z,double px, double py, double pz, double t0, int doyouprintf);
void gene_ellibunch(struct Beam *beam, double dt, double dp_ov_p, double dx, double dxprime, double dz, double dzprime, int nsteps[]);
void gene_rectbunch(struct Beam *beam, double dt, double dp_ov_p, double dx, double dxprime, double dz, double dzprime, int nsteps[]);
void gene_elliran_h(struct Beam *beam, double dt, double dp_ov_p, double emit_x, double twiss_betax, double twiss_alphax, double emit_z, double twiss_betaz, double twiss_alphaz, int nparts, long seed);
void gene_elligasdev_6d(struct Beam *beam, double dt, double dp_ov_p, double emit_x, double twiss_betax, double twiss_alphax, double emit_z, double twiss_betaz, double twiss_alphaz, int nparts, long seed);
void gene_elligasdev_4d(struct Beam *beam, double dt, double dp_ov_p, double emit_x, double twiss_betax, double twiss_alphax, double emit_z, double twiss_betaz, double twiss_alphaz, int nparts, long seed);
void gene_4D_beam_gasdev(struct Beam *beam, double emit_x, double twiss_betax, double twiss_alphax, double emit_z, double twiss_betaz, double twiss_alphaz, double factor_rms_tot, int nparts, long seed);
void load_beam(struct Beam *beam, char *inputfilename, struct Lattice *latt, int doyouprint);
void load_ao_beam(struct Beam *beam, char *inputfilename, double x_center_pipe);
void load_lattice(struct Lattice *latt, char *inputfilename);
int test_cell_rect_vffa_bend_cell(struct Cell *cell);
int test_cell_vffa(struct Cell *cell);
int test_cell_spiangle(struct Cell *cell);
int polynom_cell_test(struct Cell *cell);
//void set_up_instru(struct Cell *cell, int type, double thmax, double ymax);
void set_up_instru(struct Cell *cell, int type, double thmax[], double ymax[]);
int test_cell_map(struct Cell *cell);
void compute_convergence_limit_vffa(struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));//, int doyouglob);
void set_vffa_rect_convergence_limit(struct Cell *cell, int doyoucompute, double conv_lim, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
void gene_alignerror_latt_old(struct Lattice *reference_latt, struct Lattice *err_latt, long *idum, double rms_shift_error, double rms_twist_error, double r_ref_twist);
void add_error_pole(struct Cell *cell, int npole, double xshift, double yshift, double zshift, double angle_rot, double rot_point_x, double rot_point_y, double rot_point_z, double rot_vect_x, double rot_vect_y, double rot_vect_z);
void comp_error_latt_vffa(struct Lattice *err_latt, long seed, double rms_shift_error, double rms_twist_error);
void comp_m_error_latt_vffa(struct Lattice *err_latt, long seed, double rms_error);
void gene_latt_1cell(struct Lattice *new_latt, struct Cell *cell);
void copy_error_latt(struct Lattice *copy_latt, struct Lattice *ori_latt);
void comp_error_latt(struct Lattice *err_latt, long seed, double rms_shift_error, double rms_twist_error);
void apply_alierror_comp(struct Cell *cell, int i, double x, double y, double z, double *xwerr, double *ywerr, double *zwerr, int sign);
void declare_pole_id_latt(struct Lattice *latt, int id_pole[], int n);
//void write_beam_file(char *beamfile, struct Particle *part, char *title, int nbkeywords);
void write_beam_file(char *beamfile, char *title, double e0_mev, double ekin_ev, int nbkeywords, double x0, double z0, double xprime_deg, double zprime_deg);
void write_maplatt_cyldeg_file(char *lattfile, char *title, int periodicity, char *mapfile, double stepsize, double cell_length, double rmin, double rmax, int nbr, double thmin, double thmax, int nbth, double zmin, double zmax, int nbz);
void write_pole_lattfile(struct Cell *cell, int i, FILE *fp, double shift_deg);

//plot.c
FILE *gnuplot_start(void);
void gnuplot_set(FILE *gp, char *xlabel, char *ylabel, char *y2label, char *cblabel, char *zlabel, char *xrange, char *yrange, char *y2range, char *zrange, char *setoption);
void gnuplot2d_plot(FILE *gp, char *txtfilename, char *xcolumn, char *ycolumn, char *with, char *title, int left, int start, int end);
void gnuplot3d_plot(FILE *gp, char *txtfilename, char *xcolumn, char *ycolumn, char *zcolumn, char *with, char *title, int start, int end);
void gnuplot_postscript(FILE *gp, char *psfilename);
void gnuplot_histo(FILE *gp, double xmin, double xmax, double nb_bin);
void gnuplot_end(FILE *gp, char *psfilename);
void aspectview(char *filename, struct Lattice *latt);
void aspect_fringe_view(char *filename_en, char *filename_ex, struct Lattice *latt);
void easyplot(char *txtfilename, char *xcolumn, char *ycolumn, char *with, char *xlabel,char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void easyplot2(char *txtfilename1, char *txtfilename2, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *with1, char *with2, char *title1, char*title2, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void easyplot3(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *with1, char *with2, char *with3, char *title1, char *title2, char *title3, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void easyplot4(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *xcolumn4, char *ycolumn4, char *with1, char *with2, char *with3, char *with4, char *title1, char *title2, char *title3, char *title4, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void easyplot5(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *xcolumn4, char *ycolumn4, char *xcolumn5, char *ycolumn5, char *with1, char *with2, char *with3, char *with4, char *with5, char *title1, char *title2, char *title3, char *title4, char *title5, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void easyplot6(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *txtfilename6, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *xcolumn4, char *ycolumn4, char *xcolumn5, char *ycolumn5, char *xcolumn6, char *ycolumn6, char *with1, char *with2, char *with3, char *with4, char *with5, char *with6, char *title1, char *title2, char *title3, char *title4, char *title5, char *title6, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void easyplot8(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *txtfilename6,  char *txtfilename7, char *txtfilename8,char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *xcolumn4, char *ycolumn4, char *xcolumn5, char *ycolumn5, char *xcolumn6, char *ycolumn6, char *xcolumn7, char *ycolumn7, char *xcolumn8, char *ycolumn8, char *with1, char *with2, char *with3, char *with4, char *with5, char *with6,  char *with7, char *with8,char *title1, char *title2, char *title3, char *title4, char *title5, char *title6, char *title7, char *title8, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void easyplot11(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *txtfilename6,  char *txtfilename7, char *txtfilename8, char *txtfilename9, char *txtfilename10, char *txtfilename11, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *xcolumn4, char *ycolumn4, char *xcolumn5, char *ycolumn5, char *xcolumn6, char *ycolumn6, char *xcolumn7, char *ycolumn7, char *xcolumn8, char *ycolumn8, char *xcolumn9, char *ycolumn9, char *xcolumn10, char *ycolumn10, char *xcolumn11, char *ycolumn11, char *with1, char *with2, char *with3, char *with4, char *with5, char *with6,  char *with7, char *with8, char *with9, char *with10, char *with11, char *title1, char *title2, char *title3, char *title4, char *title5, char *title6, char *title7, char *title8, char *title9, char *title10, char *title11, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void easyplot2_left_right(char *txtfilename1, char *txtfilename2, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *with1, char *with2, char *xlabel, char *ylabel, char *y2label, char *xrange, char *yrange, char *y2range, char *psfilename, char *setoption);
void easyplot3_left_right(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *with1, char *with2, char *with3, char *title1, char *title2, char *title3, char *xlabel, char *ylabel, char *y2label, char *xrange, char *yrange, char *y2range, char *psfilename, char *setoption);
void easyplot4_left_right(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *xcolumn4, char *ycolumn4, char *with1, char *with2, char *with3, char *with4, char *title1, char *title2, char *title3, char *title4, char *xlabel, char *ylabel, char *y2label, char *xrange, char *yrange, char *y2range, char *psfilename, char *setoption);
//void easyplot3dmap(char *txtfilename, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_min, double dens_max);
void easyplot3dmap(char *txtfilename, char *xlabel, char *ylabel, char *cblabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_min, double dens_max);
void easyplot3dmap_withlegend(char *txtfilename, char *xlabel, char *ylabel, char *cblabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_min, double dens_max, char *legend);
void easyplot3dmap_gen(char *txtfilename, char *xcolumn, char *ycolumn, char *ccolumn, char *xlabel, char *ylabel, char *cblabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_min, double dens_max);
void easyplot3dmap_plusfile(char *txtfile_2d, char *xcolumn_2d, char *ycolumn_2d, char *with_2d, char *txtfilename, char *xlabel, char *ylabel, char *cblabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_min, double dens_max);
void easyplot3dmap_plus2files(char *txtfile_2d, char *xcolumn_2d, char *ycolumn_2d, char *with_2d, char *txtfile_2d2, char *xcolumn_2d2, char *ycolumn_2d2, char *with_2d2, char *txtfilename, char *xlabel, char *ylabel, char *cblabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_min, double dens_max);
//void easyplot3d(char *txtfilename, char *with, char *xlabel, char *ylabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption);
void easyplot3d(char *txtfilename, char *xcolumn, char *ycolumn, char *zcolumn, char *with, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption);
void easyplot2_3d(char *txtfilename1, char *txtfilename2, char *xcolumn1, char *ycolumn1, char *zcolumn1, char *xcolumn2, char *ycolumn2, char *zcolumn2, char *with1, char *with2, char *title1, char *title2, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption);
void easyplot3_3d(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *xcolumn1, char *ycolumn1, char *zcolumn1, char *xcolumn2, char *ycolumn2, char *zcolumn2, char *xcolumn3, char *ycolumn3, char *zcolumn3, char *with1, char *with2, char *with3, char *title1, char *title2, char *title3, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption);
void easyplot4_3d(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *xcolumn1, char *ycolumn1, char *zcolumn1, char *xcolumn2, char *ycolumn2, char *zcolumn2, char *xcolumn3, char *ycolumn3, char *zcolumn3, char *xcolumn4, char *ycolumn4, char *zcolumn4, char *with1, char *with2, char *with3, char *with4, char *title1, char *title2, char *title3, char *title4, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption);
void easyplot5_3d(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *xcolumn1, char *ycolumn1, char *zcolumn1, char *xcolumn2, char *ycolumn2, char *zcolumn2, char *xcolumn3, char *ycolumn3, char *zcolumn3, char *xcolumn4, char *ycolumn4, char *zcolumn4, char *xcolumn5, char *ycolumn5, char *zcolumn5, char *with1, char *with2, char *with3, char *with4, char *with5, char *title1, char *title2, char *title3, char *title4, char *title5, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption);
void easyplot6_3d(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *txtfilename6, char *xcolumn1, char *ycolumn1, char *zcolumn1, char *xcolumn2, char *ycolumn2, char *zcolumn2, char *xcolumn3, char *ycolumn3, char *zcolumn3, char *xcolumn4, char *ycolumn4, char *zcolumn4, char *xcolumn5, char *ycolumn5, char *zcolumn5, char *xcolumn6, char *ycolumn6, char *zcolumn6, char *with1, char *with2, char *with3, char *with4, char *with5, char *with6, char *title1, char *title2, char *title3, char *title4, char *title5, char *title6, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption);
void easyplot7_3d(double x0, double z0, char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *txtfilename6, char *txtfilename7, char *xcolumn1, char *ycolumn1, char *zcolumn1, char *xcolumn2, char *ycolumn2, char *zcolumn2, char *xcolumn3, char *ycolumn3, char *zcolumn3, char *xcolumn4, char *ycolumn4, char *zcolumn4, char *xcolumn5, char *ycolumn5, char *zcolumn5, char *xcolumn6, char *ycolumn6, char *zcolumn6, char *xcolumn7, char *ycolumn7, char *zcolumn7, 
	char *with1, char *with2, char *with3, char *with4, char *with5, char *with6, char *with7, char *title1, char *title2, char *title3, char *title4, char *title5, char *title6, char *title7, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption);
void easyplot_beta_disp(char *txtfilename1, char *txtfilename3, char *txt_filename_efb, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *with1, char *with2, char *with3, char *xlabel, char *ylabel, char *y2label, char *xrange, char *yrange, char *y2range, char *psfilename, char *setoption, double efb_scale, int title);
void write_efb_txtfile(char *filename, struct Particle *reference, struct Lattice *latt);
void plot_twiss_gamma(char *filename, char *with1, char *with2, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void plot_twiss_gamma_w_efb(char *filename, char *file_efb, double efb_scale, char *with1, char *with2, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void plot_one_histogram(char *txtfilename, double xmin, double xmax, double nb_bin, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void plot_two_histogram(char *txtfilename, char *title1, char *txtfilename2, char *title2, double xmin, double xmax, double nb_bin, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void plot_three_histogram(char *txtfilename, char *title1, char *txtfilename2, char *title2, char *txtfilename3, char *title3, double xmin, double xmax, double nb_bin, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void plot_four_histogram(char *txtfilename, char *title1, char *txtfilename2, char *title2, char *txtfilename3, char *title3, char *txtfilename4, char *title4, double xmin, double xmax, double nb_bin, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void plot_five_histogram(char *txtfilename, char *title1, char *txtfilename2, char *title2, char *txtfilename3, char *title3, char *txtfilename4, char *title4, char *txtfilename5, char *title5, double xmin, double xmax, double nb_bin, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void plot_traj(struct Lattice *latt, char *trackout, char *aspectfile, char *xcolumn_out, char *ycolumn_out, char *xcolumn_asp, char *ycolumn_asp, char *with_out, char *with_asp, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption);
void auto_plot_traj(struct Lattice *latt, char *trackout, char *aspectfile, char *psfilename, char *setoption);
void plot_traj_3d(char *trackout1, char *trackout2, char *trackout3, struct Lattice *latt, double xmin, double zmin, char *title1, char *title2, char *title3, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption);
void plot_traj_3d_5mom(char *trackout1, char *trackout2, char *trackout3, char *trackout4, char *trackout5, struct Lattice *latt, double xmin, double zmin, 
	char *title1, char *title2, char *title3, char *title4, char *title5, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption);
void auto_plot_trackout_gen(char *trackout, char *xkeyword, char *ykeyword, double xcol_mult, double xcol_add, double ycol_mult, double ycol_add, char *with, char *xlabel, char *ylabel, char *output, char *option);
void gnuplot_fit_general(char *txtfilename, char *xcolumn1, char *ycolumn1, char *fit_function_of_x, char *variables_name, char *init_variables, char *with1, 
 char *with2, char *xlabel, char *ylabel, char *title1, char *title2, char *xrange, char *yrange, char *psfilename, char *setoption);
void tune_diag(char *textfilename, int supersym, double qxmin, double qxmax, double qzmin, double qzmax, int maxorder_s, int maxorder_ns, int doyounorm, int doyouskew, char *output_name);
void gene_elligasdev_h(struct Beam *beam, double dt, double dp_ov_p, double sigmax, double sigmaxp, double twiss_alphax, double twiss_betax, int nparts, long seed);
void plotfunction(char *function, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *title, char *setoption);
void gnuplot_3d_scatered_points(char *txtfilename, char *xcolumn, char *ycolumn, char *cbcolumn, char *xlabel, char *ylabel, char *cblabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_max);
void compute_fieldheatmap(char *filename_prefix, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int), double r0, double rmax, int nbr, double th0, double thmax, int nbth, double z0, double zmax, int nbz, int doyouradial);
void compute_fieldheatmap_btot(char *filename, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int),
	double x0, double xmax, int nbx, double y0, double ymax, int nby, double z0, double zmax, int nbz);
void compute_fieldheatmap_difference(char *filename_prefix, struct Cell *cell1, void(*add_contribution_comp1)(double,double,double,double*,double*,double*,struct Cell*,int), struct Cell *cell2, void(*add_contribution_comp2)(double,double,double,double*,double*,double*,struct Cell*,int), double r0, double rmax, int nbr, double th0, double thmax, int nbth, double z0, double zmax, int nbz, int doyouradial);

//numerical.c
//void rkdrive(struct Particle *part, int *nsteps, double stepsize,void (*derivs)(struct Particle*, double[], double[], struct Cell*, void(*)(double,double,double,double*,double*,double*,struct Cell*,int)),struct Cell* cell, char *txtfile, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
void rkdrive(struct Particle *part, int *awd_answer, double stepsize, void (*derivs)(struct Particle*, double[], double[], struct Cell*, void(*)(double,double,double,double*,double*,double*,struct Cell*,int)), struct Cell* cell, char *txtfile, char *pickupfile, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
void four1(double data[], unsigned long nn, int isign);
int sign(double a);
double atan_ratio(double y, double x);
void convert_polar_to_cart(double r, double th, double *x, double *y);
void convert_cart_to_polar(double x, double y, double *r, double *th);
double bessj0(double x);
double bessj1(double x);
double bessy0(double x);
double bessy1(double x);
double bessel_j(double alpha, double x, int n);
double bessel_y(double alpha, double x, int n);
int overflow_test(double a);
int sanity_test_number(double a);
int factorial(int n);
void mmprod2(double fst[2][2], double sec[2][2], double mul[2][2]);
void mmprod4(double fst[4][4], double sec[4][4], double mul[4][4]);
void mvprod3(double v[], double a[][3], double u[]);
void mvprod4(double v[], double a[][4], double u[]);
void mvprod5(double v[], double a[][5], double u[]);
void matrix_dot_1dim(double complex a[], double complex b[],double complex mult[],int r1,int c1,int r2,int c2);
double matrix_det_4d(double mat[4][4], int n);
double matrix_det_5d(double mat[5][5], int n);
void matrix_transpose_4d(double m[4][4], double tr[4][4], int r);
void matrix_cofactor_4d(double num[4][4], double fac[4][4], int f);
int matrix_inverse_4d(double num[4][4], double inverse[4][4]);
//void zgeev(char* jobvl, char* jobvr, int* n, double complex *a, int* lda, double complex *w, double complex *vl, int* ldvl, double complex *vr, int* ldvr, double complex *work, int* lwork, double complex *rwork, int* info);
//int zgetrf_(int *m, int *n, double complex *a, int *lda, int *ipiv, int *info);
//int zgetri_(int *n, double complex *a, int *lda, int *ipiv, double complex *work, int *lwork, int *info);
//void matrix_complex_inverse(double complex *A, double complex *invA, int n);
//void lu_factorisation(double complex A[], double complex L[], double complex U[], int n);
int invmat(double matrix[5][5], int nfree);
double inimat( double s[5][5], double rl[5], double *x, double *y, int n, double *p, double *e, int ip[5], int nfree);
int inivec( double s[5][5], double s1[5][5], double rl[5], double labda, double *q, double *p, double *e, double *x, double *y, int n, int ip[5], int nfree);
void zge_transpose(double complex *Transposed, double complex *M ,int n);
//void matrix_complex_eigensystem(double complex *eigenvectorsVR, double complex *eigenvaluesW, double complex *A, int N);
double comp_print_det_matrix_1dim(char *matrixname, double complex *m_1dim, int n, char *txtout);
//int compute_eigenvector_parzen(double complex *eigenvectorsVR, double complex *eigenvaluesW, double complex *m_1dim);
//int decouple_matrix_parzen(double m[4][4], double decoup_m[4][4], double decoup_to_coup[4][4], double output[6], char *txtout);
float ran1(long *idum);
float gasdev(long *idum);
int get_int_from_double(double a);

//track.c
int find_closed_orbite_x(struct Particle *part, double *x_clo, double eps_clo, struct Lattice *latt, int doyouprintf);
int find_closed_orbite_xz(struct Particle *part, double *x_clo, double *z_clo, double eps_clo, struct Lattice *latt, int doyouprintf);
int find_closed_orbite_xxp(struct Particle *part, double *x_clo, double *ux_clo, double *uy_clo, double eps_clo, struct Lattice *latt, int doyouprintf);
int find_closed_orbite_xxp_zzp(struct Particle *part, double *x_clo, double *ux_clo, double *uy_clo, double *z_clo, double *uz_clo, double eps_clo, struct Lattice *latt, int doyouprintf);
int find_co_ellipse(struct Particle *part, double *x_clo, double *z_clo, double *ux_clo, double *uy_clo, double *uz_clo, double eps_clo, int nb_points, struct Lattice *latt, int doyouprintf);
double fn_co_xxp(struct Lattice *latt, struct Particle *part, double x[], double betax);
void find_co_nelmin_xxp(struct Lattice *latt, struct Particle *part, double betax, double fn_co_xxp(struct Lattice*, struct Particle*, double x[], double), int n, double xmin[], double *ynewlo, double reqmin, double step[], int konvge, int kcount, int *icount, int *numres, int *ifault, int doyouprintf);
int put_on_co_nelmin_xxp(struct Lattice *latt, struct Particle *part, double reqmin, double stepx, double stepux, int doyouprintf);
double fn_co(struct Lattice *latt, struct Particle *part, double x[], double betax, double betaz);
void find_co_nelmin(struct Lattice *latt, struct Particle *part, double betax, double betaz, double fn_co(struct Lattice*, struct Particle*, double x[], double, double), int n, double xmin[], double *ynewlo, double reqmin, double step[], int konvge, int kcount, int *icount, int *numres, int *ifault);
int put_on_co_nelmin(struct Lattice *latt, struct Particle *part, double reqmin, double stepx, double stepux, double stepz, double stepuz, int doyouprintf);
void find_new_closed_orbit_afterb0adjust_spi(struct Particle *newpart, double x, double ux, double brho_ori, struct Lattice *latt, double ux_ori, double eps_clo);
int acceptancex(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double axmin, double axmax, double axstep, double az);
int acceptancez(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double azmin, double azmax, double azstep, double ax);
int acceptancezprime(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double zprimemin, double zprimemax, double zprimestep, double ax);
void acceptancex_auto(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double axmin, double *axmax, double axstep, double az);
void acceptancez_auto(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double azmin, double *azmax, double azstep, double ax);
int track_n_turns_amp(double x[],double z[], double ux[], double uy[], double uz[], struct Particle *reference, struct Lattice *latt, int nbpass, double ax, double az);
void acceptance_2d_emit_auto(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double emitmin, double *emitmax, double emitstep);
int acceptanceu(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double aumin, double aumax, double austep, double av);
int acceptancev(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double avmin, double avmax, double avstep, double au);
int acceptanceu_auto(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double aumin, double *aumax, double austep, double av);
int acceptancev_auto(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double avmin, double *avmax, double avstep, double au);
int acceptance_uv(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double au, double av, double decoup_to_coup[4][4]);
void beam_oneturn(struct Beam *bunch, struct Lattice *latt, char *txtfile, char *pickupfile);
void beam_cross_latt(struct Beam *bunch, struct Lattice *latt, char *txtfile, char *pickupfile);
void part_oneturn(struct Particle *part, struct Lattice *latt, char *txtfile, char *pickupfile);
void part_cross_latt(struct Particle *part, struct Lattice *latt, char *txtfile, char *pickupfile);
int part_cross_cell(struct Particle *part, struct Cell *cell, char *txtfile, char *pickupfile);
int part_callrk(struct Particle *part, struct Cell *cell, char *txtfile, char *pickupfile);
void part_cross_thingap(struct Particle *part, struct Cavity *cav);
void part_thindipole(struct Particle *part, struct Cell *cell);
void part_collimator(struct Particle *part, struct Cell *cell);
void part_float_faraday(struct Particle *part, struct Cell *cell);
void derivs(struct Particle *part, double dfds[], double bprobe[], struct Cell *cell,void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));

//get_field.c
int get_bfield(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell,void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int));
void add_field_comp_FFAGradial_he(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_FFAGradial_lin(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_FFAGradial_purescale(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_FFAGspiral_he(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_FFAGspiral_lin(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_FFAGspiral_enge(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_FFAGspiral_fullenge(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_polynom_spiral_he(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_polynom_spiral_lin(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_polynom_spiral_enge(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_FFAGstraight_he (double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_FFAGstraight_lin(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_FFAGstraight_purescale(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_FFAGstraighttilt_he (double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_FFAGstraighttilt_lin(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_rect_he(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_rect_he_str(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_rect_lin(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_rect_lin_str(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_rect_he(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_rect_enge(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_rect_enge_add(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_rect_str_enge(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_rect_enge_separate_func(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_sect_lin(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_sect_he(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_sect_enge(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_drift(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_realbend(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_sector_purebend(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_sector_purebend_lin(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_quad_he (double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_quad_lin(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_quad_enge(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void get_bfield_cylindrical_map(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void get_bfield_cylindrical_map_tricubic(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void get_bfield_2dpolarmap(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void get_bfield_2dcartmap(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void get_bfield_cartesian_map(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void get_bfield_cartesian_map_tricubic(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void get_bfield_cylmap(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void get_bfield_cylmap_nosym(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void get_bfield_cartmap(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void get_bfield_cartmap_nosym(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_FFAGstraight_add(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_rect_bx_add(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_rect_atan(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
void add_field_comp_VFFA_rect_str_atan(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);
//void add_multiple_poles(double x, double y, double z, double *bx, double *by, double *bz, struct Cell *cell, int ic);

//lin_para.c
void tune_calculate_fft(struct Particle *reference, double *nux, double *nuz, int tune_turn, double amp_x, double amp_z, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf, char *output_name);
void tune_calc_matrix_no_period(struct Particle *reference, double *qx, double *qz, double amp_x, double amp_xprime, double amp_z, double amp_zprime, double betax0, double alphax0,  double betaz0, double alphaz0, double *betaxfin, double *alphaxfin, double *betazfin, double *alphazfin, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf, char *output_name);
void tune_calc_matrix(struct Particle *reference, double *qx, double *qz, double *twiss_bx, double *twiss_ax, double *twiss_bz, double *twiss_az, double amp_x, double amp_xprime, double amp_z, double amp_zprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf, char *output_name);
double calc_phase_advance(double m[2][2], double beta0, double alpha0);
double calc_tune1(double m[2][2]);
double calc_tune2(double m[2][2]);
int calc_phadv_twiss_hor(struct Particle *reference, double *nux, double *qx, double *betaf, double *alphaf, double amp_x, double amp_xprime, double betax0, double alphax0, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int calc_phadv_twiss_vert(struct Particle *reference, double *nuz, double *qz, double *betaf, double *alphaf, double amp_z, double amp_zprime, double betaz0, double alphaz0, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int calc_tune_twiss_4d(struct Particle *reference, double *nux, double *qx, double *nuz, double *qz, double *betax, double *alphax, double *betaz, double *alphaz, double amp_x, double amp_xprime, double amp_z, double amp_zprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf, int together_decoupled);
int calc_phadv_twiss(struct Particle *reference, double *qx, double *qz, double betax0, double alphax0, double betaz0, double alphaz0, double amp_x, double amp_xprime, double amp_z, double amp_zprime, double *betaxf, double *alphaxf, double *betazf, double *alphazf, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf, char *outfile);
int calc_tune_twiss_hor(struct Particle *reference, double *nux, double *qx, double *betax, double *alphax, double amp_x, double amp_xprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int calc_tune_twiss_vert(struct Particle *reference, double *nuz, double *qz, double *betaz, double *alphaz, double amp_z, double amp_zprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int calc_tune_twiss_4d(struct Particle *reference, double *nux, double *qx, double *nuz, double *qz, double *betax, double *alphax, double *betaz, double *alphaz, double amp_x, double amp_xprime, double amp_z, double amp_zprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf, int together_decoupled);
int calc_tune_twiss(struct Particle *reference, double *qx, double *qz, double *betax, double *alphax, double *betaz, double *alphaz, double amp_x, double amp_xprime, double amp_z, double amp_zprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf, char *outfile,int together_decoupled);
int iterative_calc_tune_twiss(struct Particle *reference, double *qx, double *qz, double *betax, double *alphax, double *betaz, double *alphaz, double amp_x, double amp_z, 
	struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf, char *outfile);
void phase_adv_scan_woco(char *outfilename, struct Lattice *latt, struct Particle *reference_part, double emin_ev, double emax_ev, int nbstep, double amp);
void phase_adv_scan(char *outfilename, struct Lattice *latt, struct Particle *reference_part, double eps_clo, double emin_ev, double emax_ev, int nbstep, double amp);
int calc_tune_eigenvalue(double *qu, double *qv, double ampx, double ampxp, double ampz, double ampzp, struct Particle *part, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf, char *outfile);
double find_s(struct Particle *reference, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*));
void calc_twiss(double m[2][2], double *beta1, double *alpha1, double beta0, double alpha0);
void calc_periodic_twiss(double m[2][2], double nu, double *beta, double *alpha);
void get_periodic_twiss(double *betax0, double *alphax0, double *betaz0, double *alphaz0, double amp_x, double amp_xprime, double amp_z, double amp_zprime, struct Particle *reference, struct Lattice *latt, int together_decoupled);
void get_twissx_atinstru(double *betax, double *alphax, double beta0, double alpha0, double amp_x, double amp_xprime, struct Particle *reference, struct Lattice *latt);
void get_twissz_atinstru(double *betaz, double *alphaz, double beta0, double alpha0, double amp_x, double amp_xprime, struct Particle *reference, struct Lattice *latt);
void get_twiss_atinstru(double *betax, double *alphax, double *betaz, double *alphaz, double betax1, double alphax1, double betaz1, double alphaz1, double amp_x, double amp_xprime, double amp_z, double amp_zprime, struct Particle *reference, struct Lattice *latt, int together_decoupled);
void compute_betafunc(char *filename, int nsteps_cell, double amp_x, double amp_xprime, double amp_z, double amp_zprime,struct Particle *reference, struct Lattice *latt, double betax0, double alphax0, double betaz0, double alphaz0, int together_decoupled);
void compute_betafunc_cell(char *filename, int nsteps_cell, double amp_x, double amp_xprime, double amp_z, double amp_zprime, struct Particle *reference, struct Cell *cell, double betax0, double alphax0, double betaz0, double alphaz0, int together_decoupled);
void compute_betafunc_latt(char *filename, int nsteps_cell, double amp_x, double amp_xprime, double amp_z, double amp_zprime, struct Particle *reference, struct Lattice *latt, double betax0, double alphax0, double betaz0, double alphaz0, int together_decoupled);
void compute_periodic_betafunc(char *filename, int nsteps_cell, double amp_x, double amp_xprime, double amp_z, double amp_zprime, struct Particle *reference, struct Lattice *latt, int together_decoupled);
void compute_periodic_dispersion_2d(char *filename, int nsteps_cell, double amp_x, double amp_xprime, double amp_dpovp,struct Particle *reference, struct Lattice *latt, int hor);
void compute_dispersion_2d(char *filename, int nsteps_cell, double amp_x, double amp_xprime, double amp_dpovp,struct Particle *reference, struct Lattice *latt, double disp0, double dispprime0, int hor);
void get_periodic_dispersion_2d(double *disp0, double *dispprime0,  double amp_x, double amp_xprime, double amp_dpovp, struct Particle *reference, struct Lattice *latt, int hor);
void compute_periodic_dispersion_4d(char *filename, int nsteps_cell, double amp_x, double amp_xprime, double amp_z, double amp_zprime, double amp_dpovp, struct Particle *reference, struct Lattice *latt);
void compute_dispersion_4d(char *filename, int nsteps_cell, double amp_x, double amp_xprime, double amp_z, double amp_zprime, double amp_dpovp, struct Particle *reference, struct Lattice *latt, double dispx0, double dispprimex0, double dispz0, double dispprimez0);
void get_periodic_dispersion_4d(double *dispx0, double *dispprimex0, double *dispz0, double *dispprimez0, double amp_x, double amp_xprime, double amp_z, double amp_zprime, double amp_dpovp, struct Particle *reference, struct Lattice *latt);
void find_x(double *x, double *bias, struct Particle *part_ref, struct Particle *part);
void find_z(double *z, double *bias, struct Particle *part_ref, struct Particle *part);
int get_matrix_hor_vert(double mh[2][2], double mv[2][2], double *band_bias, struct Particle *reference, double amp_x, double amp_xprime, double amp_z, double amp_zprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf, int together_decoupled);
int get_trmatrix_h(double mh[2][2], double *band_bias, struct Particle *reference, double amp_x, double amp_xprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int get_trmatrix_v(double mv[2][2], struct Particle *reference, double amp_z, double amp_zprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int get_trmatrix_firstorder_h(double mh[2][2], double *band_bias, struct Particle *reference, double amp_x, double amp_xprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int get_trmatrix_firstorder_v(double mv[2][2], struct Particle *reference, double amp_z, double amp_zprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int get_trmatrix_h3x3(double mh[3][3], double *band_bias, struct Particle *reference, double amp_x, double amp_xprime, double amp_dpovp, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int get_trmatrix_v3x3(double mv[3][3], double *band_bias, struct Particle *reference, double amp_z, double amp_zprime, double amp_dpovp, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int get_matrix_firstorder_4d(double m[4][4], double *band_bias, struct Particle *reference, double amp_x, double amp_xprime, double amp_z, double amp_zprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int get_matrix_secondorder_4d(double m[4][4], double *band_bias, struct Particle *reference, double amp_x, double amp_xprime, double amp_z, double amp_zprime, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int get_matrix_firstorder_5d(double m[5][5], double *band_bias, struct Particle *reference, double amp_x, double amp_xprime, double amp_z, double amp_zprime, double amp_dpovp, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int get_matrix_secondorder_5d(double m[5][5], double *band_bias, struct Particle *reference, double amp_x, double amp_xprime, double amp_z, double amp_zprime, double amp_dpovp, struct Lattice *latt, void(*transport_part)(struct Particle*, struct Lattice*,char*,char*), int doyouprintf);
int symplectify_2d(double m[2][2], double symplec_m[2][2]);
int symplectify_4d(double m[4][4], double symplec_m[4][4]);

//bricabrac.c
void load_textfile_beam_nustorm(struct Beam *beam, char *textfile, double x_offset);
void export_textfile_beam_nustorm(struct Beam *beam, char *textfile, double x_offset);

/* ****************** common MACROs ********************* */
#define MAX(a,b)    (( a > b ) ? a : b )
#define MIN(a,b)    (( a < b ) ? a : b )
#define SIGN(a,b)	((b) >= 0.0 ? fabs(a) : -fabs(a))
#define SWAP(a,b)	tempr=(a);(a)=(b);(b)=tempr 

#endif

