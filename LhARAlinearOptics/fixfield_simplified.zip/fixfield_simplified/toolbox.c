/*
 *  toolbox.c
 *  Fixfield
 *
 *  Copyright 2009 Kyoto University. All rights reserved.
 *
 */

#include "toolbox.h"

// ************************************************************************************ //
///////////////////////  general functions  ////////////////////////////
// ************************************************************************************ //

extern void errorstop(char *error_text) {
	char shell_write[100];
	int sound_option = NO;
	FILE *shell_read;
	//if(print_color==YES) COLOR("1;31");
	printf("\nerrorstop procedure...\n");
	printf("%s\n", error_text);
	printf("...now exiting to system...\n");
	//if(print_color==YES) COLOR("0");
	if(sound_option==YES) {
		sprintf(shell_write,"say unexpected error %s", error_text);
		shell_read = popen(shell_write,"r");
		pclose(shell_read);
	}
	exit(1);
}

//when read a file, read until the end of the line
extern void newline(FILE *rfile) {
	char temp_str[MAX_CHARINLINE+2];
	
	fgets(temp_str, MAX_CHARINLINE+2, rfile);
	if(strlen(temp_str) > MAX_CHARINLINE) errorstop("!!!ERROR in newline (toolbox.c): maximum number of char per line in input file exceeded!!!");
}

//create an empty data file
extern void emptyfile(char *filename) {
	FILE *fill;
	
	fill = fopen(filename, "w");
	fclose(fill);
}

extern char* itoa(int value, char* result, int base) {
	// check that the base if valid
	if (base < 2 || base > 36) { *result = '\0'; return result; }

	char* ptr = result, *ptr1 = result, tmp_char;
	int tmp_value;
	
	do {
		tmp_value = value;
		value /= base;
		*ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
	} while ( value );
	
	// Apply negative sign
	if (tmp_value < 0) *ptr++ = '-';
	*ptr-- = '\0';
	
	// Reverse the string
	while(ptr1 < ptr) {
		tmp_char = *ptr;
		*ptr--= *ptr1;
		*ptr1++ = tmp_char;
	}
	return result;
}

//print lattice parameters
extern void print_latt_para(char *filename, char *lattname, struct Lattice *latt) {
	char cellname[KEYWORDL];
	int i;
	
	if(filename!=NULL) {
		FILE *wfile;
		
		printf("writing lattice in %s\n",filename);
		wfile = fopen(filename, "w");
		fprintf(wfile, "%s\n\n",lattname);
		fprintf(wfile, "%i				//lattice periodicity [int]\n", latt->periodicity);
		fprintf(wfile, "%i				//number of elements [int]\n", latt->nbcell);
		fprintf(wfile, "%i				//number of cell types [int]\n\n\n", latt->nbcell);
		fclose(wfile);
		for(i=0; i<latt->nbcell; i++) {
			sprintf(cellname, "cell[%i]", i);
			print_cell_para(filename, cellname, &(latt->cell[i]));
		}
	}
	else {
		printf("%s: \n", lattname);
		printf("nb of cells: %i\n", latt->nbcell);
		printf("superperiod: %i\n", latt->periodicity);
		for(i=0; i<latt->nbcell; i++) {
			sprintf(cellname, "cell[%i]", i);
			if(strcmp(latt->cell[i].keyword, "rf-thingap") == 0) {
				print_rf_cell(filename, cellname, &(latt->cell[i]), latt->periodicity);
			}
			else if(strcmp(latt->cell[i].keyword, "collimator") == 0) {
				print_collimator_cell(filename, cellname, &(latt->cell[i]));
			}
			else if(strcmp(latt->cell[i].keyword, "float-faraday") == 0) {
				printf("warning float faraday!!\n");
			}
			else {
				print_cell_para(filename, cellname, &(latt->cell[i]));
			}
			
		}
		printf("\n");
	}
}

extern void print_rf_cell(char *filename, char *cellname, struct Cell *cell, int periodicity) {
	int j;
	
	for(j = 0; j < periodicity; j++) {
		printf("periodicity %i/%i\n", j+1, periodicity);
		if(filename!=NULL) {
			FILE *wfile;
			wfile = fopen(filename, "a");
			fprintf(wfile, "%le		//rf frequency [Hz]\n", cell->cav[j].frf);
			fprintf(wfile, "%le			//V0 [V] of Vrf=sin(w(t-t0)+phi0)\n", cell->cav[j].v0);
			fprintf(wfile, "%lf					//phi0 [deg] of Vrf\n", cell->cav[j].phi0);
			fprintf(wfile, "%lf					//t0 [s] of Vrf\n", cell->cav[j].t0);
			fclose(wfile);
		}
		else {
			printf("%s: \n", cellname);
			printf("keyword: %s\n", cell->keyword);
			printf("	Frf = %le [Hz]\n", cell->cav[j].frf);
			printf("	V0 = %le [V]\n", cell->cav[j].v0);
			printf("	phi0 = %le [rad]\n", cell->cav[j].phi0);
			printf("	t0 = %le [s]\n", cell->cav[j].t0);
		}
	}
}

extern void print_collimator_cell(char *filename, char *cellname, struct Cell *cell) {
	if(filename!=NULL) {
		FILE *wfile;
		wfile = fopen(filename, "a");
		fprintf(wfile, "1 %s	//%s\n", cell->keyword, cellname);
		fprintf(wfile, "%lf %lf %lf	//collimators rmin [m], rmax [m], zmax [m]\n", cell->collim.rmin, cell->collim.rmax, cell->collim.zmax);
		fclose(wfile);
	}
	else {
		printf("%s: \n", cellname);
		printf("keyword: %s\n", cell->keyword);
		printf("collimators: rmin = %lf [m], rmax = %lf [m], zmin = %lf [m], zmax = %lf [m]\n", cell->collim.rmin, cell->collim.rmax, cell->collim.zmin, cell->collim.zmax);
	}
}

extern void print_cell_para(char *filename, char *cellname, struct Cell *cell) {
	int j, n;
	
	if(filename!=NULL) {
		FILE *wfile;
		wfile = fopen(filename, "a");
		fprintf(wfile, "1 %s %i	//%s\n", cell->keyword, cell->nbcomp, cellname);
		fprintf(wfile, "%lf			//step size [m]\n", cell->stepsize);
		if(test_cell_vffa(cell)==TRUE) fprintf(wfile, "%lf  %lf  %lf  %lf	//collimators rmin [m], rmax [m], zmin [m], zmax [m]\n", cell->collim.rmin, cell->collim.rmax, cell->collim.zmin, cell->collim.zmax);
		else fprintf(wfile, "%lf  %lf  %lf	//collimators rmin [m], rmax [m], zmax [m]\n", cell->collim.rmin, cell->collim.rmax, cell->collim.zmax);
		if(cell->boun.thmax != 0) fprintf(wfile, "%lf			//element total opening angle [deg]\n", cell->boun.thmax*180./PI);
		else if(cell->boun.ymax != 0) fprintf(wfile, "%lf			//element total length [m]\n", cell->boun.ymax);
		fprintf(wfile, "%lf				//deltar\n\n", cell->deltar);
		if(test_cell_map(cell)==NO) {
			//printf("not a map!\n");
			for(n = 0; n < cell->nbcomp; n++) {
				if(cell->boun.thmax != 0) fprintf(wfile, "%lf	", cell->mpara[n][0]*180./PI);
				else if(cell->boun.ymax != 0) fprintf(wfile, "%lf	", cell->mpara[n][0]);
				for(j = 1; j < SIZE_MPARA; j++) {
					if(	(test_cell_spiangle(cell)==6 && j==5) ||
						(test_cell_spiangle(cell)==1 && j==4) ||
						(test_cell_spiangle(cell)==3 && j==4) ||
						(test_cell_spiangle(cell)==4 && j==4)) {
						fprintf(wfile, "%lf	", cell->mpara[n][j]*180./PI);
					}
					else fprintf(wfile, "%lf	", cell->mpara[n][j]);
				}
				fprintf(wfile,"\n\t");
				if(cell->boun.thmax != 0 && test_cell_rect_vffa_bend_cell(cell)!=TRUE) fprintf(wfile,"%lf	", cell->efben[n][0]*180./PI);
				else if(cell->boun.ymax != 0 || test_cell_rect_vffa_bend_cell(cell)==TRUE) fprintf(wfile,"%lf	", cell->efben[n][0]);
				for(j = 1; j < SIZE_EFB; j++) fprintf(wfile,"%lf	", cell->efben[n][j]);
				fprintf(wfile,"\n\t");
				if(cell->boun.thmax != 0 && test_cell_rect_vffa_bend_cell(cell)!=TRUE) fprintf(wfile,"%lf	", cell->efbex[n][0]*180./PI);
				else if(cell->boun.ymax != 0 || test_cell_rect_vffa_bend_cell(cell)==TRUE) fprintf(wfile,"%lf	", cell->efbex[n][0]);
				for(j = 1; j < SIZE_EFB; j++) fprintf(wfile,"%lf	", cell->efbex[n][j]);
				fprintf(wfile,"\n\n");
			}
		}
		else if(test_cell_map(cell)==YES) {
			fprintf(wfile, "map symmetry: %i, (%i=YES, %i=NO)\n", cell->map.sym, YES, NO);
			fprintf(wfile, "map dimensions min:(%le, %le, %le), max: (%le, %le, %le)\n", cell->map.mapdim[0], cell->map.mapdim[2], cell->map.mapdim[4], cell->map.mapdim[1], cell->map.mapdim[3], cell->map.mapdim[5]);
			fprintf(wfile, "map step size (%le, %le, %le)\n", cell->map.stepsize[0], cell->map.stepsize[1], cell->map.stepsize[2]);
			fprintf(wfile, "nb of nodes: (%i, %i, %i)\n", cell->map.nnodes[0], cell->map.nnodes[1], cell->map.nnodes[2]);
		}
		else errorstop("strange, map or not?\n");
		fclose(wfile);
	}
	else {
		printf("%s: \n", cellname);
		printf("keyword: %s, nb of components: %i\n", cell->keyword, cell->nbcomp);
		printf("stepsize = %le\n", cell->stepsize);
		printf("collimators: rmin = %lf [m], rmax = %lf [m], zmin = %lf [m], zmax = %lf [m]\n", cell->collim.rmin, cell->collim.rmax, cell->collim.zmin, cell->collim.zmax);
		printf("framework: xc = %lf[m] yc = %lf[m] ae = %lf[deg]\n", cell->framework.xc, cell->framework.yc, cell->framework.ae*180./(PI));
		printf("deltar = %lf\n", cell->deltar);
		printf("boundary (thmax, ymax): (%le[deg], %le[m])\n", cell->boun.thmax*180./PI, cell->boun.ymax);
		if(cell->doyou_err==NO) printf("alignment error: NO\n");
		else if(cell->doyou_err==YES) printf("alignment error: YES\n");
		else errorstop("alignment error flag has a strange value!\n");
		if(test_cell_map(cell)==NO) {
			for(n = 0; n < cell->nbcomp; n++) {
				printf("\t");
				if(cell->boun.thmax != 0) printf("%lf	", cell->mpara[n][0]*180./PI);
				else if(cell->boun.ymax != 0) printf("%lf	", cell->mpara[n][0]);
				for(j = 1; j < SIZE_MPARA; j++) printf("%lf ", cell->mpara[n][j]);
				printf("\n\t\t");
				for(j = 0; j < SIZE_EFB; j++) printf("%lf ", cell->efben[n][j]);
				printf("\n\t\t");
				for(j = 0; j < SIZE_EFB; j++) printf("%lf ", cell->efbex[n][j]);
				printf("\n\t");
				if(cell->doyou_err==YES) {
					printf("ali_err: ");
					for(j = 1; j < 4; j++) printf("%lf ", cell->alierror[n][j]);
					printf("\n\t");//%lf\n\t\t", cell->alierror[n][4]);
					for(j = 4; j < 11; j++) printf("%lf ", cell->alierror[n][j]);
					printf("\n");
				}
				printf("\n");
			}
		}
		else if(test_cell_map(cell)==YES) {
			printf("map symmetry: %i, (%i=YES, %i=NO)\n", cell->map.sym, YES, NO);
			printf("map dimensions min:(%le, %le, %le), max: (%le, %le, %le)\n", cell->map.mapdim[0], cell->map.mapdim[2], cell->map.mapdim[4], cell->map.mapdim[1], cell->map.mapdim[3], cell->map.mapdim[5]);
			printf("map step size (%le, %le, %le)\n", cell->map.stepsize[0], cell->map.stepsize[1], cell->map.stepsize[2]);
			printf("nb of nodes: (%i, %i, %i)\n", cell->map.nnodes[0], cell->map.nnodes[1], cell->map.nnodes[2]);
		}
		else errorstop("strange, map or not?\n");
	}
}

extern int nb_poles_latt(struct Lattice *latt) {
	int i, j, n=0;
	for(i=0;i< latt->nbcell; i++) {
		if((latt->cell[i].boun.thmax!=0 || latt->cell[i].boun.ymax!=0) && test_cell_map(&latt->cell[i])==NO) {
			for(j = 0; j < latt->cell[i].nbcomp; j++) n++;
		}
	}
	return n;
}

extern void get_x0_y0_from_pole(struct Cell *cell, int pole, double *x_0, double *y_0) {
	if((cell->boun.thmax!=0 && cell->boun.ymax!=0) || test_cell_map(cell)!=NO) errorstop("no pole in cell\n");
	if(cell->boun.thmax!=0) {
		if(strcmp(cell->keyword, "realbend") == 0) {
			*x_0 = cell->mpara[pole][0]*cos(cell->boun.thmax/2.); //r0*cos(th_centre)
			*y_0 = cell->mpara[pole][0]*sin(cell->boun.thmax/2.);
		}
		else {
			*x_0 = cell->mpara[pole][1]*cos(cell->mpara[pole][0]); //r0*cos(th_centre)
			*y_0 = cell->mpara[pole][1]*sin(cell->mpara[pole][0]);
		}
	}
	else {
		*x_0 = cell->mpara[pole][1];
		*y_0 = cell->mpara[pole][0];
	}
}

extern void print_alierror_para(char *filename, struct Lattice *err_latt)
{
	int i,j;
	FILE *wfile;
	
	if(filename!=NULL) {
		wfile = fopen(filename, "w");
		for(i=0;i<err_latt->nbcell;i++) {
			for(j=0;j<err_latt->cell[i].nbcomp;j++) {
				fprintf(wfile, "%le  %le  %le  %le  %le  %le  %le\n", 
				err_latt->cell[i].alierror[j][1],err_latt->cell[i].alierror[j][2],err_latt->cell[i].alierror[j][3],
				err_latt->cell[i].alierror[j][4],err_latt->cell[i].alierror[j][5],err_latt->cell[i].alierror[j][6],
				err_latt->cell[i].alierror[j][7]);
			}
		}
		fclose(wfile);
	}
	else {
		printf("alignment error: xshift, yshift, zshift, angle_rot, rot_point_x,y,z, rot_vect_x,y,z\n");
		for(i=0;i<err_latt->nbcell;i++) {
			for(j=0;j<err_latt->cell[i].nbcomp;j++) {
				printf("%le  %le  %le  %le  %le  %le  %le\n", 
				err_latt->cell[i].alierror[j][1],err_latt->cell[i].alierror[j][2],err_latt->cell[i].alierror[j][3],
				err_latt->cell[i].alierror[j][4],err_latt->cell[i].alierror[j][5],err_latt->cell[i].alierror[j][6],
				err_latt->cell[i].alierror[j][7]);
			}
		}
	}
}

//print particle parameters
extern void print_beam_para(char *beamname, struct Beam *beam) {
	char partname[15];
	int i;
	
	printf("%s: \n", beamname);
	for(i=0;i<beam->npart;i++) {
		sprintf(partname,"part[%i]", i);
		print_part_para(partname, &(beam->part[i]));
	}
}

extern void print_part_para(char *partname, struct Particle *part) {
	printf("%s: \n", partname);
	printf("framework: xc = %lf[m] yc = %lf[m] ae = %lf[deg]\n", part->fwk.xc, part->fwk.yc, part->fwk.ae*180./(PI));
	printf("(status,m0,q) = (%i, %le, %le)\n", part->status, part->m0, part->q);
	printf("(brho,s,t) = (%le, %le, %le)\n", part->brho, part->s, part->t);
	printf("(x,y,z) = (%.8e, %.8e, %.8e)\n", part->x, part->y, part->z);
	printf("(ux,uy,uz) = (%.8e, %.8e, %.8e)\n", part->ux, part->uy, part->uz);
	printf("x' = %.8e[deg], z' = %.8e[deg]\n\n", atan(part->ux/(part->uy))*180./(PI), atan(part->uz/(sqrt((part->uy)*(part->uy)+(part->ux)*(part->ux))))*180./(PI));
}

extern void print_get_bfield(double x, double y, double z, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int)) {
	double bx, by, bz;
	double br,bth, r, th;
	
	get_bfield(x, y, z, &bx, &by, &bz, cell, add_contribution_comp);
	//printf("at (%lf, %lf, %lf), field (%le, %le, %le)\n",x,y,z,bx,by,bz);
	if(cell->boun.thmax != 0) {
		convert_cart_to_polar(x, y, &r, &th);
		//r= sqrt(x*x + y*y); 
		//th = atan_ratio(y, x);
		br = bx*cos(th) + by*sin(th);
		bth = by*cos(th) - bx*sin(th);
		printf("r=%lf [m], th=%lf [deg], z=%lf [m], (Br,Bth, Bz)=(%le, %le, %le)\n",r,th*180./PI, z, br, bth, bz);
	}
}

extern void printf_mat_1dim_complex(char *message, double complex *m, int nb_dim, char *name_mat, int option, char *txtout) {
	int i,j;
	FILE *wfile;
	
	if(txtout !=NULL) {
		wfile = fopen(txtout, "a");
		fprintf(wfile, "%s\n", message);
	}
	
	printf("%s\n", message);
	for(i=0;i<nb_dim;i++) {
		if(option==1) {
			for(j=0;j<nb_dim;j++) {
				printf("%s[%i]=(%le, %le)\t",name_mat, i*nb_dim+j, creal(m[i*nb_dim+j]), cimag(m[i*nb_dim+j]));
				if(txtout != NULL) fprintf(wfile, "%s[%i]=(%le, %le)\t",name_mat, i*nb_dim+j, creal(m[i*nb_dim+j]), cimag(m[i*nb_dim+j]));
			}
			printf("\\\\\n");
			if(txtout != NULL) fprintf(wfile, "\\\\\n");
		}
		else if(option==2) {
			for(j=0;j<nb_dim;j++) {
				printf("%lf & ",creal(m[i*nb_dim+j]));
				if(txtout != NULL) fprintf(wfile, "%lf & ",creal(m[i*nb_dim+j]));
			}
			printf("\\\\\n");
			if(txtout != NULL) fprintf(wfile, "\\\\\n");
		}
		else if(option==3) {
			for(j=0;j<nb_dim;j++) {
				printf("%lf\t ",creal(m[i*nb_dim+j]));
				if(txtout != NULL) fprintf(wfile, "%lf\t ",creal(m[i*nb_dim+j]));
			}
			printf("\n");
			if(txtout != NULL) fprintf(wfile, "\n");
		}
	}
	//printf("\n");
	if(txtout !=NULL) {
		fprintf(wfile, "\n");
		fclose(wfile);
	}

}

extern void printf_mat_4d_real(char *message, double m[4][4], char *name_mat, char *txtout) {
	int i,j,n=4;
	FILE *wfile;
	
	if(txtout !=NULL) {
		wfile = fopen(txtout, "a");
		fprintf(wfile, "%s\n", message);
		fprintf(wfile, "%s\n", name_mat);
	}
	
	printf("%s\n", message);
	printf("%s\n", name_mat);
	for(i=0;i<n;i++) {
		for(j=0;j<n;j++) {
			printf("%le 	",m[i][j]);
			if(txtout != NULL) fprintf(wfile, "%le  ",m[i][j]);
		}
		printf("\n");
		if(txtout != NULL) fprintf(wfile, "\n");
	}
	//printf("\n");
	if(txtout !=NULL) {
		fprintf(wfile, "\n");
		fclose(wfile);
	}
}

extern double round_nb(double value, int nb_decimal) {
	double coef = pow(10., nb_decimal);
	return (round(value*coef))/coef;
}

// test if number is 2^n
extern int test_power2(unsigned int x) {
 while (((x % 2) == 0) && x > 1) x /= 2; // While x is even and > 1
 if(x == 1) return TRUE;
 else return FALSE;
}

//get total energy, beta, gamma of a given Particle
extern void get_ebg_part(double *e_tot, double *beta, double *gamma, struct Particle *part) {
	*e_tot	= sqrt(pow(part->m0*CLIGHT2, 2) + (part->brho*part->q*part->brho*part->q)*CLIGHT2);
	*gamma	= *e_tot/(part->m0*CLIGHT2);
	*beta	= sqrt((*gamma)*(*gamma) - 1)/(*gamma);
}

//generate the Twiss transfer matrix from a usual 2x2 transfer matrix
extern void twissTMtransform(double m[2][2], double twm[3][3]) {
	twm[0][0] = m[0][0]*m[0][0];
	twm[0][1] = -2.*m[0][0]*m[0][1];
	twm[0][2] = m[0][1]*m[0][1];
	twm[1][0] = -m[0][0]*m[1][0];
	twm[1][1] = m[0][0]*m[1][1] + m[0][1]*m[1][0];
	twm[1][2] = -m[0][1]*m[1][1];
	twm[2][0] = m[1][0]*m[1][0];
	twm[2][1] = -2.*m[1][0]*m[1][1];
	twm[2][2] = m[1][1]*m[1][1];
}

//warning: doyouprint must be YES otherwise doesn't work...
//extern void fix_boundingbox(char *txtfilename, int doyouprint) {
//	char shell_write[500], buf[MAX_CHARINLINE];
//	FILE *shell_read;
//
//	sprintf(shell_write,"./bbfix.sh %s", txtfilename);
//	shell_read = popen(shell_write,"r");
//	if(doyouprint==YES) {
//		if(fgets(buf, MAX_CHARINLINE-1, shell_read) == NULL) printf("no output in fix_boundingbox");
//		printf("%s",buf);
//	}
//	pclose(shell_read);
//}

extern void say(char *text_say) {
	char shell_write[500];
	FILE *shell_read;
	sprintf(shell_write,"say %s", text_say);
	shell_read = popen(shell_write,"r");
	pclose(shell_read);
}

extern void convert_file(char *ori_file, char *final_file, int resolution, int doyouprint) {
	char shell_write[500], buf[MAX_CHARINLINE];
	FILE *shell_read;
	
	if(resolution != 0) sprintf(shell_write,"convert -density %i %s %s", resolution, ori_file, final_file);
	else sprintf(shell_write,"convert %s %s", ori_file, final_file);
	shell_read = popen(shell_write,"r");
	if(doyouprint==YES) {
		if(fgets(buf, MAX_CHARINLINE-1, shell_read) == NULL) printf("no output in convert_file");
		printf("%s",buf);
	}
	pclose(shell_read);
	
}

extern double comp_step(double val_start, double val_end, int nvalues, int doyouprintf) {
	double step;
	
	if(nvalues>1) {
		step=(val_end-val_start)/(nvalues-1);
		if(doyouprintf == YES) printf("start=%lf, end=%lf, n=%i, step=%le)\n",val_start, val_end, nvalues, step);
		return step;
	}
	else {
		if(doyouprintf == YES) printf("n=1, step=0\n");
		return 0;
	}
}

extern void write_ellipse(char *wfilename, double emitt_pimmmrad, double beta, double alpha, double xcenter, double ycenter) {
	int npoints = 100, i;
	double x, y, xn, yn, t;//, gamma_cs, angle;
	FILE *wfile;
	if(beta==0) errorstop("beta=0, cannot write ellipse");
	//gamma_cs = (1+alpha*alpha)/beta;
	//angle = 0.5*atan(alpha/(gamma_cs-beta));
	wfile = fopen(wfilename, "w");
	
	for(i = 0; i <= npoints; i++) {
		t = i*2.*PI/npoints;
		//xn = sqrt(emitt_pimmmrad*1.e-6)*cos(t)*sqrt(beta);
		//yn = sqrt(emitt_pimmmrad*1.e-6)*sin(t)/sqrt(beta);
		//x = xn*cos(angle)-yn*sin(angle);
		//y = yn*cos(angle) + xn*sin(angle);
		xn = sqrt(emitt_pimmmrad*1.e-6)*cos(t);
		yn = sqrt(emitt_pimmmrad*1.e-6)*sin(t);
		x = sqrt(beta)*xn;
		y = (yn - alpha*xn)/sqrt(beta);
		fprintf(wfile, "%le  %le\n", x + xcenter, y + ycenter);
	}
	
	fprintf(wfile, "\n%le %le\n", xcenter, ycenter);
	
	fclose(wfile);
	
}

extern void write_ellipse2(char *wfilename, double emitt_pimmmrad, double beta, double alpha, double xcenter, double ycenter) {
	int npoints = 100, i;
	double x, y, xmin, xstep, xmax, gamma_cs;
	FILE *wfile;
	if(beta==0) errorstop("beta=0, cannot write ellipse");
	gamma_cs = (1+alpha*alpha)/beta;
	//angle = 0.5*asin(alpha/(gamma_cs-beta));
	wfile = fopen(wfilename, "w");
	xmin = -sqrt(emitt_pimmmrad*1.e-6/gamma_cs);
	xmax = sqrt(emitt_pimmmrad*1.e-6/gamma_cs);
	xstep = (xmax-xmin)/npoints;
	
	for(i = 0; i <= npoints; i++) {
		x = xmin+i*xstep;
		y = (-alpha*x+sqrt(beta*emitt_pimmmrad*1.e-6-x*x))/beta;
		fprintf(wfile, "%le  %le\n", x + xcenter, y + ycenter);
	}
	for(i=0;i<=npoints;i++) {
		x = xmax-i*xstep;
		y = (-alpha*x-sqrt(beta*emitt_pimmmrad*1.e-6-x*x))/beta;
		fprintf(wfile, "%le  %le\n", x + xcenter, y + ycenter);
	}
	
	fprintf(wfile, "\n%le %le\n", xcenter, ycenter);
	
	fclose(wfile);
	
}

extern void write_ellipse_mm_mevc(char *wfilename, double emitt_pimmmrad, double beta, double alpha, double xcenter, double ycenter, double pcenter) {
	int npoints = 1000, i;
	double x, y, xmin, xstep, xmax, gamma_cs;
	FILE *wfile;
	if(beta==0) errorstop("beta=0, cannot write ellipse");
	gamma_cs = (1+alpha*alpha)/beta;
	//angle = 0.5*asin(alpha/(gamma_cs-beta));
	wfile = fopen(wfilename, "w");
	xmin = -sqrt(emitt_pimmmrad*1.e-6/gamma_cs);
	xmax = sqrt(emitt_pimmmrad*1.e-6/gamma_cs);
	xstep = (xmax-xmin)/npoints;
	
	for(i = 0; i <= npoints; i++) {
		x = xmin+i*xstep;
		if(beta*emitt_pimmmrad*1.e-6-x*x<0.) {
			printf("sqrt neg (%le), force to 0\n", beta*emitt_pimmmrad*1.e-6-x*x);
			y = (-alpha*x)/beta*pcenter;
		}
		else y = (-alpha*x+sqrt(beta*emitt_pimmmrad*1.e-6-x*x))/beta*pcenter;
		fprintf(wfile, "%le  %le\n", x*1000. + xcenter, y + ycenter);
		//printf("%le, %le, %le\n",x, y, sqrt(beta*emitt_pimmmrad*1.e-6-x*x));
	}
	for(i=0;i<=npoints;i++) {
		x = xmax-i*xstep;
		if(beta*emitt_pimmmrad*1.e-6-x*x<0.) {
			printf("sqrt neg (%le), force to 0\n", beta*emitt_pimmmrad*1.e-6-x*x);
			y = (-alpha*x)/beta*pcenter;
		}
		y = (-alpha*x-sqrt(beta*emitt_pimmmrad*1.e-6-x*x))/beta*pcenter;
		fprintf(wfile, "%le  %le\n", x*1000. + xcenter, y + ycenter);
	}
	x = xmin;
	if(beta*emitt_pimmmrad*1.e-6-x*x<0.) {
		printf("sqrt neg (%le), force to 0\n", beta*emitt_pimmmrad*1.e-6-x*x);
		y = (-alpha*x)/beta*pcenter;
	}
	else y = (-alpha*x+sqrt(beta*emitt_pimmmrad*1.e-6-x*x))/beta*pcenter;
	fprintf(wfile, "%le  %le\n", x*1000. + xcenter, y + ycenter);
	
	fprintf(wfile, "\n%le %le\n", xcenter, ycenter);
	
	fclose(wfile);
}


// ************************************************************************************ //
////////////////  TEXT FILES MANIPULATIONS  ////////////////////////////
// ************************************************************************************ //

extern int get_nb_lines_file(char *txtfilename) {
	char name[500], shell_write[500];
	double nblines_double;
	FILE *shell_read;

	sprintf(shell_write,"wc -l %s", txtfilename);
	shell_read = popen(shell_write,"r");
	fscanf(shell_read, "%lf %s", &nblines_double, name);
	pclose(shell_read);
	return (int) nblines_double;
}

extern void pick_with_para_from_trackout(FILE *fp, char keyword[][20], int nb_para_taken, double para[], int total_nb_para) {
	int i, para_list_nb[nb_para_taken];
	for(i=0;i<nb_para_taken;i++) para_list_nb[i] = para_clm_trackout(keyword[i]);
	//for(i=0;i<nb_para_taken;i++) printf("%i\n", para_list_nb[i]);
	pick_columns_from_file(fp, para_list_nb, nb_para_taken, para, total_nb_para);
	
}

extern void pick_columns_from_file(FILE *fp, int para_list_nb[], int nb_para_taken, double para[], int total_nb_para) {
	int i,n, j=0;
	double temp;
	
	for(i=0;i<nb_para_taken;i++) {
		if(para_list_nb[i]>total_nb_para) errorstop("nb of columns in file exceeded\n");
		for(n=0;n<i;n++) {
			if(para_list_nb[n]>para_list_nb[i]) errorstop("columns should be listed in growing order\n");
		}
	}
	for(i=0;i<total_nb_para;i++) {
		fscanf(fp, "%le", &temp);
		//printf("%le	", temp);
		if((para_list_nb[j]-1)==i) {
			para[j] = temp;
			if(j==nb_para_taken-1) break;
			j++;
		}
		//printf("\n");
	}
	if(para_list_nb[nb_para_taken-1] != total_nb_para) newline(fp);
}

extern void get_boundaries_from_file(char *txtfilename, int para_list_nb[], int nb_para_taken, double min[], double max[], int total_nb_para) {
	int i,j,nblines;
	double para[nb_para_taken];
	FILE *rfile=NULL;
	
	nblines = get_nb_lines_file(txtfilename);
	
	for(j=0;j<nb_para_taken;j++) {
		min[j] = 1.e15;
		max[j] = -1.e15;
	}
	rfile = fopen(txtfilename, "r");
	if(rfile==NULL) errorstop("cannot open rfile\n");
	
	for(i=0;i<nblines;i++) {
		pick_columns_from_file(rfile, para_list_nb, nb_para_taken, para, total_nb_para);
		for(j=0;j<nb_para_taken;j++) {
			min[j] = MIN(min[j], para[j]);
			max[j] = MAX(max[j], para[j]);
		}
	}
	fclose(rfile);
}

extern int para_clm_trackout(char *keyword) {
	//1: s; 2: x; 3: y; 4: z; 5: bx; 6: by; 7: bz; 8: ux; 9: uy; 10: uz; 
	//11: r; 12: theta_deg; 13: th_glob_deg; 14: br; 15: btheta; 16: Brho
	if(strcmp(keyword, "s") == 0) return 1;
	else if(strcmp(keyword, "x") == 0) return 2;
	else if(strcmp(keyword, "y") == 0) return 3;
	else if(strcmp(keyword, "z") == 0) return 4;
	else if(strcmp(keyword, "bx") == 0) return 5;
	else if(strcmp(keyword, "by") == 0) return 6;
	else if(strcmp(keyword, "bz") == 0) return 7;
	else if(strcmp(keyword, "ux") == 0) return 8;
	else if(strcmp(keyword, "uy") == 0) return 9;
	else if(strcmp(keyword, "uz") == 0) return 10;
	else if(strcmp(keyword, "r") == 0) return 11;
	else if(strcmp(keyword, "th_deg") == 0) return 12;
	else if(strcmp(keyword, "th_glob_deg") == 0) return 13;
	else if(strcmp(keyword, "br") == 0) return 14;
	else if(strcmp(keyword, "bth") == 0) return 15;
	else if(strcmp(keyword, "brho") == 0) return 16;
	else {
		printf("keyword not recognised '%s'\n", keyword);
		return 999;//errorstop("strange keyword!");
	}
}

extern void get_smax_file(char *txtfilename, double *smax) {
	int n, nblines;
	FILE *rfile = NULL;
	
	nblines = get_nb_lines_file(txtfilename);
	rfile = fopen(txtfilename, "r");
	if(rfile==NULL) errorstop("cannot open rfile");
	for(n=0;n<nblines-2;n++) newline(rfile);	
	fscanf(rfile, "%le", smax);
	fclose(rfile);
}

extern void get_betamax_file(char *txtfilename, double *betamax) {
	int n, nblines;
	double s, bx, ax, bz, bmax=0.;//, az;
	FILE *rfile = NULL;
	
	nblines = get_nb_lines_file(txtfilename);
	rfile = fopen(txtfilename, "r");
	if(rfile==NULL) errorstop("cannot open rfile");
	for(n=0;n<nblines-1;n++) {
		//fscanf(rfile, "%le	%le	%le	%le	%le", &s, &bx, &ax, &bz, &az);
		fscanf(rfile, "%le	%le	%le	%le", &s, &bx, &ax, &bz);
		if(bmax < bx || bmax < bz) bmax = MAX(bx, bz);
		newline(rfile);
	}
	*betamax = bmax;
	//printf("betamax = %lf\n", bmax);
	fclose(rfile);
}

extern void get_betax_z_max_file(char *txtfilename, double *betax_max, double *betaz_max) {
	int n, nblines;
	double s, bx, ax, bz, az, bxmax=0.,bzmax=0.;
	FILE *rfile = NULL;
	
	nblines = get_nb_lines_file(txtfilename);
	rfile = fopen(txtfilename, "r");
	if(rfile==NULL) errorstop("cannot open rfile");
	for(n=0;n<nblines-1;n++) {
		fscanf(rfile, "%le	%le	%le	%le	%le", &s, &bx, &ax, &bz, &az);
		if(bxmax < bx) bxmax = bx;
		if(bzmax < bz) bzmax = bz;
		newline(rfile);
	}
	*betax_max = bxmax;
	*betaz_max = bzmax;
	//printf("betaxmax = %lf, betazmax=%lf\n", bxmax,bzmax);
	fclose(rfile);
}

extern void get_xrange(char *txtfilename, char *xrange) {
	double smax;
	get_smax_file(txtfilename, &smax);
	//printf("smax = %lf\n", smax);
	sprintf(xrange,"[0:%lf]", smax);
}

extern void get_betarange(char *txtfilename, char *betarange) {
	double bmin, bmax, brange;
	get_betamax_file(txtfilename, &bmax);
	brange = floor(bmax)+1;
	//sprintf(betarange,"[0:%lf]", brange);
	
	get_betamin_file(txtfilename, &bmin);
	bmin = floor(bmin);
	sprintf(betarange,"[%lf:%lf]", bmin, brange);
}

extern void get_dispmax_file(char *txtfilename, double *dispmax) {
	int n, nblines;
	double s, d=-1.0e18, dp;
	FILE *rfile = NULL;
	
	nblines = get_nb_lines_file(txtfilename);
	rfile = fopen(txtfilename, "r");
	if(rfile==NULL) errorstop("cannot open rfile");
	for(n=0;n<nblines-1;n++) {
		fscanf(rfile, "%le	%le	%le", &s, &d, &dp);
		//printf("%le\n", d);
		if(*dispmax < d) *(dispmax) = d;
	}
	//printf("in get_dispmax_file, dmax=%lf", *dispmax);
	fclose(rfile);
}

extern void get_dispmin_file(char *txtfilename, double *dispmin) {
	int n, nblines;
	double s, d=1.0e18, dp;
	FILE *rfile = NULL;
	
	nblines = get_nb_lines_file(txtfilename);
	rfile = fopen(txtfilename, "r");
	if(rfile==NULL) errorstop("cannot open rfile");
	for(n=0;n<nblines-2;n++) {
		fscanf(rfile, "%le	%le	%le", &s, &d, &dp);
		//printf("%le\n", d);
		if(*dispmin > d) *(dispmin) = d;
	}
	//printf("in get_dispmax_file, dmax=%lf", *dispmax);
	fclose(rfile);
}

extern void get_disprange(char *txtfilename, char *disprange) {
	double dmax, dmin, drange;
	get_dispmax_file(txtfilename, &dmax);
	get_dispmin_file(txtfilename, &dmin);
	printf("dmin = %lf, dmax = %lf\n",dmin, dmax);
	drange = dmax*1.02;
	sprintf(disprange,"[%lf:%lf]", dmin, drange);
}

extern void get_dispmax_file_4d(char *txtfilename, double *dispxmax, double *dispzmax) {
	int n, nblines;
	double s, dx=-1.0e18, dpx, dz=-1.0e18, dpz;
	FILE *rfile = NULL;
	
	nblines = get_nb_lines_file(txtfilename);
	rfile = fopen(txtfilename, "r");
	if(rfile==NULL) errorstop("cannot open rfile");
	for(n=0;n<nblines-1;n++) {
		fscanf(rfile, "%le	%le	%le	%le	%le", &s, &dx, &dpx, &dz, &dpz);
		//printf("dx=%le, dz=%le\n", dx, dz);
		if(*dispxmax < dx) *(dispxmax) = dx;
		if(*dispzmax < dz) *(dispzmax) = dz;
	}
	//printf("in get_dispmax_file, dmax=%lf", *dispmax);
	fclose(rfile);
}

extern void get_dispmin_file_4d(char *txtfilename, double *dispxmin, double *dispzmin) {
	int n, nblines;
	double s, dx=1.0e18, dpx, dz=1.0e18, dpz;
	FILE *rfile = NULL;
	
	nblines = get_nb_lines_file(txtfilename);
	rfile = fopen(txtfilename, "r");
	if(rfile==NULL) errorstop("cannot open rfile");
	for(n=0;n<nblines-2;n++) {
		fscanf(rfile, "%le	%le	%le	%le	%le", &s, &dx, &dpx, &dz, &dpz);
		//printf("%le\n", d);
		if(*dispxmin > dx) *(dispxmin) = dx;
		if(*dispzmin > dz) *(dispzmin) = dz;
	}
	//printf("in get_dispmax_file, dmax=%lf", *dispmax);
	fclose(rfile);
}

extern void get_disprange_4d(char *txtfilename, char *disprangehor, char *disprangevert) {
	double dxmax, dxmin, dzmax, dzmin, dxrange, dzrange;
	get_dispmax_file_4d(txtfilename, &dxmax, &dzmax);
	get_dispmin_file_4d(txtfilename, &dxmin, &dzmin);
	printf("dxmin = %lf, dxmax = %lf, dzmin = %lf, dzmax = %lf\n",dxmin, dxmax, dzmin, dzmax);
	dxrange = dxmax*1.02;
	dzrange = dzmax*1.02;
	sprintf(disprangehor,"[%lf:%lf]", dxmin, dxrange);
	sprintf(disprangevert,"[%lf:%lf]", dzmin, dzrange);
}

extern void get_tune_range(char *txtfilename, double *qx_min, double *qx_max, double *qz_min, double *qz_max, double *qx_tot_min, double *qx_tot_max, double *qz_tot_min, double *qz_tot_max) {
	char buf[MAX_CHARINLINE];
	double e_tot, qx=0.0, qz=0.0, qx_tot=0.0, qz_tot=0.0, temp;
	FILE *rfile = NULL;
	
	rfile = fopen(txtfilename, "r");
	if(rfile==NULL) errorstop("cannot open rfile");
	if(fgets(buf, MAX_CHARINLINE-1, rfile) == NULL) errorstop("strange in get_tune_range");
	if(sscanf(buf, "%le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le", &e_tot, qx_min, qz_min, qx_tot_min, qz_tot_min, &temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp) != 13) errorstop("strange2 in get_tune_range");
	printf("qx=%lf, qz=%lf\n",*qx_min, *qz_min);
	if(isnan(qx)==TRUE || isnan(qz)==TRUE || isnan(qx_tot)==TRUE || isnan(qz_tot)==TRUE) printf("ole!\n");
	*qx_max = *qx_min;
	*qx_tot_max = *qx_tot_min;
	*qz_max = *qz_min;
	*qz_tot_max = *qz_tot_min;
	while(!feof(rfile)) {
	    if(fgets(buf, MAX_CHARINLINE-1, rfile) == NULL) break;
	    buf[MAX_CHARINLINE-1]='\0';

	    if(sscanf(buf, "%le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le", &e_tot, &qx, &qz, &qx_tot, &qz_tot, &temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp) != 13) errorstop("strange...");
		if(isnan(qx)==TRUE || isnan(qz)==TRUE || isnan(qx_tot)==TRUE || isnan(qz_tot)==TRUE) printf("ole!\n");
		*qx_min = MIN(qx,*qx_min);
		*qx_max = MAX(qx,*qx_max);
		*qz_min = MIN(qz,*qz_min);
		*qz_max = MAX(qz,*qz_max);
		*qx_tot_min = MIN(qx_tot,*qx_tot_min);
		*qx_tot_max = MAX(qx_tot,*qx_tot_max);
		*qz_tot_min = MIN(qz_tot,*qz_tot_min);
		*qz_tot_max = MAX(qz_tot,*qz_tot_max);
	}
	fclose(rfile);
	*qx_min = floor(*qx_min);
	*qx_max = floor(*qx_max)+1;
	*qz_min = floor(*qz_min);
	*qz_max = floor(*qz_max)+1;
	*qx_tot_min = floor(*qx_tot_min);
	*qx_tot_max = floor(*qx_tot_max)+1;
	*qz_tot_min = floor(*qz_tot_min);
	*qz_tot_max = floor(*qz_tot_max)+1;
}

extern void get_space_range(char *aspectfile, double *xmin, double *xmax, double *ymin, double *ymax) {
	char buf[MAX_CHARINLINE];
	double x,y;
	FILE *rfile = NULL;
	
	rfile = fopen(aspectfile, "r");
	if(rfile==NULL) errorstop("cannot open rfile");
	
	while(!feof(rfile)) {
	    
	    if(fgets(buf, MAX_CHARINLINE-1, rfile) == NULL) break;
	    buf[MAX_CHARINLINE-1]='\0';

	    if(sscanf(buf, "%le %le", &x, &y) != 2) continue;
		*xmin = MIN(x, *xmin);
		*xmax = MAX(x, *xmax);
		*ymin = MIN(y, *ymin);
		*ymax = MAX(y, *ymax);
	}
	fclose(rfile);
}

extern void find_boundaries_column_file(char *file, double *min, double *max, int column, int nb_tot_column) {
	int i,j,nblines;
	double a[nb_tot_column];
	FILE *rfile=NULL;
	
	nblines = get_nb_lines_file(file);
	
	rfile = fopen(file, "r");
	if(rfile==NULL) errorstop("cannot open rfile\n");
	
	*min = 1.e15;
	*max = -1.e15;
	for(i=0;i<nblines;i++) {
		for(j=0;j<nb_tot_column;j++) fscanf(rfile, "%le", &a[j]);
		//for(j=0;j<nb_tot_column;j++) printf("%lf\t", a[j]);
		//printf("\n");
		if(sanity_test_number(a[column-1])==TRUE) {
			//*min = MIN(a[column-1],*xmin);
			//*max = MAX(a[column-1],*xmax);
			if(a[column-1]<*min) *min = a[column-1];
			if(a[column-1]>*max) *max = a[column-1];
		}
	}
	fclose(rfile);
}

extern void find_range_column_file(char *file, char *range, int column, int nb_tot_column, int flag_extent, int flag_sym_around_0) {
	double min, max;
	find_boundaries_column_file(file, &min, &max, column, nb_tot_column);
	printf("min, max = (%le, %le)\n", min ,max);
	if(flag_extent==YES) {
		if(min<0) min *= 1.02;
		else min /= 1.02;
		if(max<0) max /= 1.02;
		else max *= 1.02;
	}
	if(flag_sym_around_0==YES) {
		if(min>0 || max<0) errorstop("in find_range_column_file, flag_sym_around_0 with min and max not around 0\n");
		min = -(MAX(fabs(min), max));
		max = MAX(fabs(min), max);
	}
	sprintf(range,"[%lf:%lf]", min, max);
	printf("range %s\n",range);
}

extern void find_range_column_2files(char *range, char *file1, int column1, int nb_tot_column1, char *file2, int column2, int nb_tot_column2, int flag_extent, int flag_sym_around_0) {
	double min, max, min1, max1, min2, max2;
	find_boundaries_column_file(file1, &min1, &max1, column1, nb_tot_column1);
	printf("min1, max1 = (%le, %le)\n", min1 ,max1);
	find_boundaries_column_file(file2, &min2, &max2, column2, nb_tot_column2);
	printf("min2, max2 = (%le, %le)\n", min2 ,max2);
	min = MIN(min1, min2);
	max = MAX(max1, max2);
	if(flag_extent==YES) {
		if(min<0) min *= 1.02;
		else min /= 1.02;
		if(max<0) max /= 1.02;
		else max *= 1.02;
	}
	if(flag_sym_around_0==YES) {
		if(min>0 || max<0) errorstop("in find_range_column_file, flag_sym_around_0 with min and max not around 0\n");
		min = -(MAX(fabs(min), max));
		max = MAX(fabs(min), max);
	}
	sprintf(range,"[%lf:%lf]", min, max);
	printf("range %s\n",range);
}

extern void find_boundaries_heated_map_file(char *file, double *xmin, double *xmax, double *ymin, double *ymax, double *val_min, double *val_max) {
	int i,nblines;
	double x, y, val, x_val_min, y_val_min, x_val_max, y_val_max;
	FILE *rfile=NULL;
	
	nblines = get_nb_lines_file(file);
	
	rfile = fopen(file, "r");
	if(rfile==NULL) errorstop("cannot open rfile\n");
	
	*xmin = 1.e9;
	*xmax = -1.e9;
	*ymin = 1.e9;
	*ymax = -1.e9;
	*val_min = 1.e9;
	*val_max = -1.e9;
	for(i=0;i<nblines;i++) {
		fscanf(rfile, "%le	%le	%le", &x,&y,&val);
		if(x==x && y==y && val==val) {
			if(x<*xmin) *xmin = x;
			if(x>*xmax) *xmax = x;
			if(y<*ymin) *ymin = y;
			if(y>*ymax) *ymax = y;
			if(val<*val_min) {
				*val_min = val;
				x_val_min = x;
				y_val_min = y;
			}
			if(val>*val_max) {
				*val_max = val;
				x_val_max = x;
				y_val_max = y;
			}
		}
	}
	fclose(rfile);
	printf("in %s:\n \tmin value %le at (%le,%le)\n \tmax value %le at (%le,%le)\n",file,*val_min,x_val_min,y_val_min, *val_max, x_val_max, y_val_max);
	printf(" xrange:[%lf:%lf], yrange:[%lf:%lf]\n", *xmin, *xmax, *ymin, *ymax);
	
}

extern void find_boundaries_heated_map_file_range(char *file, char *xrange, char *yrange, double *val_min, double *val_max) {
	double xmin, xmax, ymin, ymax;
	
	find_boundaries_heated_map_file(file, &xmin, &xmax, &ymin, &ymax, val_min, val_max);
	sprintf(xrange,"[%lf:%lf]", xmin, xmax);
	sprintf(yrange,"[%lf:%lf]", ymin, ymax);
	//printf("xrange:[%lf:%lf]", xmin, xmax);
	//printf("yrange:[%lf:%lf]", ymin, ymax);
}

extern void find_ur_zero_from_trackout(char *trackout, double *theta, double *rco, double *b_boun) {
	int i, nblines;
	double s,x,y,z,bx,by,bz,ux,uy,uz,r,th, ur_temp,btemp,th_temp,r_temp, ur;
	FILE *rfile=NULL;
	nblines = get_nb_lines_file(trackout);
	*b_boun = 1.e10;
	
	rfile = fopen(trackout, "r");
	if(rfile==NULL) errorstop("cannot open trackout");
	
	for(i=0;i<nblines;i++) {
		fscanf(rfile, "%le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le",&s,&x,&y,&z,&bx,&by,&bz,&ux,&uy,&uz,&r,&th);
		newline(rfile);
		ur = ux*cos(th*PI/180.)+uy*sin(th*PI/180.);
		//printf("ur = %le, bz = %le, th = %lf\n", ur, bz, th);
		if(i!=0) {
			if(sign(ur_temp)!=sign(ur)) {
				//printf("found change of ur! th=%lf, Bz=%lf\n", th, bz);
				if(fabs(ur)>fabs(ur_temp)) {
					if(*b_boun>fabs(btemp)) {
						*b_boun = fabs(btemp);
						*theta = th_temp;
						*rco = r_temp;
					}
				}
				else {
					if(*b_boun>fabs(bz)) {
						*b_boun=fabs(bz);
						*theta = th;
						*rco = r;
					}
				}
				printf("bmin=%lf, glob_th=%lf\n", *b_boun, *theta);
			}
		}
		ur_temp = ur;
		btemp = bz;
		th_temp = th;
		r_temp = r;
	}
	
	fclose(rfile);
}

// adjust the fields of the element to keep the same FD ratio, with the particle on the wanted closed orbit (r0)
//warning!! this box only works with a 1-element lattice!
// works also with straights : r0 = x0 and k = novero.
extern int adjust_r0_with_b0(struct Lattice *latt, struct Particle *part, double r_co, double *r0, double eps_clo) {
	int i, j;
	double rnew;
	printf("adjust_r0:\n\n");
	if(test_cell_map(&latt->cell[0])==YES) errorstop("adjust_r0 not working with maps!");
	if(latt->nbcell!=1) errorstop("adjust_r0 works with only 1 cell lattice");
	for(i = 0; i < 10; i++) {
		if(find_closed_orbite_xxp(part, &rnew, &(part->ux), &(part->uy), eps_clo, latt, YES) == TRUE) {
			//part->x = rnew;
			part->x = r_co;
			//tune_calc_matrix(part, &nux, &nuz, &betax, &alphax, &betaz, &alphaz, 1.e-4, 1.e-5, 1.e-4, 1.e-5, latt, part_cross_latt, NO, NULL);
			if (fabs(rnew - r_co) < eps_clo) {
				printf("\n\tr0adjust = %.8f [m]\n", latt->cell[0].mpara[0][1]);
				*r0 = latt->cell[0].mpara[0][1];
				return TRUE;
			}
			
			for(j = 0; j < latt->cell[0].nbcomp; j++) {
				latt->cell[0].mpara[j][1] -= (rnew-r_co);
			}
			//printf("rnew = %lf, r_co = %lf\n", rnew, r_co);
			//for(j = 0; j < latt->cell[0].nbcomp; j++) printf("latt->cell[0].mpara[%i][1] = %lf\n", j, latt->cell[0].mpara[j][1]); 
		}
		else {
			printf("\n \nproblem in adjust_r0, closed orbit not found!\n");
			return FALSE;
		}
	}
	printf("\n \nin adjust_r0 precision not achieved: eps = %le, increase the number of turns or decrease demanded precision\n \n", fabs(rnew - r_co));
	printf("\n\n\t\t\tr0adjust = %lf [m]\n\n\n", latt->cell[0].mpara[0][1]);
	return FALSE;
}

//adjust closed orbit on r_co by changing B0
extern int adjust_r0_with_b0_ffag_spi(struct Lattice *latt, struct Particle *part, double r_co, double eps_clo, double eps_r0) {
	int i, j, k;
	double rnew, stepx = 1.e-4;
	printf("adjust_B0:\n\n");
	for(i = 0; i < 30; i++) {
		//printf("i=%i\n",i);
		put_on_co_nelmin_xxp(latt, part, eps_clo, stepx, stepx, NO);
		//if(put_on_co_nelmin(latt, part, eps_clo, stepx, stepx, stepx, stepx, YES) == TRUE) {
		if(find_closed_orbite_xxp(part, &(part->x), &(part->ux), &(part->uy), eps_clo, latt, NO) == TRUE) {
			rnew = part->x;
			//part->x = rnew;
			//tune_calc_matrix(part, &nux, &nuz, &betax, &alphax, &betaz, &alphaz, 1.e-4, 1.e-5, 1.e-4, 1.e-5, latt, part_cross_latt, NO, NULL);
			if (fabs(rnew - r_co) < eps_r0) {
				//printf("\n\tr0adjust = %.8f [m]\n", latt->cell[0].mpara[0][1]);
				printf("Adjusted B0 at r0=%lf: (%le, %le) [T]\n", latt->cell[0].mpara[0][1], latt->cell[0].mpara[0][2], latt->cell[0].mpara[1][2]);
				return TRUE;
			}
			for(k=0;k<latt->nbcell;k++) {
				for(j = 0; j < latt->cell[k].nbcomp; j++) {
					latt->cell[k].mpara[j][2] *= pow((rnew-r_co + latt->cell[k].mpara[j][1])/latt->cell[k].mpara[j][1], latt->cell[k].mpara[j][3]);
				}
			}
			part->x = r_co;
			//part->ux -= (rnew-r_co)*tan(latt->cell[0].mpara[0][4])/rnew;
			//part->uy = sqrt(1-part->ux*part->ux);
			//printf("rnew = %lf, r_co = %lf\n", rnew, r_co);
			//for(j = 0; j < latt->cell[0].nbcomp; j++) printf("latt->cell[0].mpara[%i][1] = %lf\n", j, latt->cell[0].mpara[j][1]); 
		}
		else {
			printf("\n \nproblem in adjust_r0, closed orbit not found!\n");
			return FALSE;
		}
	}
	printf("\n \nin adjust_r0 precision not achieved: eps = %le, increase the number of turns or decrease demanded precision\n \n", fabs(rnew - r_co));
	printf("\n\n\t\t\tB0adjust = %lf [m]\n\n\n", latt->cell[0].mpara[0][2]);
	return FALSE;
}

//adjust closed orbit on average r_co by changing B0 (1 cell only!)
extern int adjust_rav_with_b0_ffag_spi(struct Lattice *latt, struct Particle *part, double r_co_av, double eps_clo, double eps_r0) {
	int i, j, k, nb_iterations=50;
	double rnew, rnew_av;
	printf("adjust_B0 for r_co=%lf:\n\n", r_co_av);
	for(i = 0; i < nb_iterations; i++) {
		//printf("i=%i\n",i);
		if(find_closed_orbite_xxp(part, &rnew, &(part->ux), &(part->uy), eps_clo, latt, NO) == TRUE) {
			emptyfile("data/r_av_computation.dat");
			part->x = rnew;
			part->s = 0;
			part_cross_latt(part, latt, "data/r_av_computation.dat", NULL);
			rnew_av = compute_av_radius_from_trackout_1cell("data/r_av_computation.dat", YES);
			printf("r_co(s0)=%lf, r_new_av = %lf\n", rnew, rnew_av);
			//tune_calc_matrix(part, &nux, &nuz, &betax, &alphax, &betaz, &alphaz, 1.e-4, 1.e-5, 1.e-4, 1.e-5, latt, part_cross_latt, NO, NULL);
			if (fabs(rnew_av - r_co_av) < eps_r0) {
				//printf("\n\tr0adjust = %.8f [m]\n", latt->cell[0].mpara[0][1]);
				printf("iteration %i, adjusted B0 at r0=%lf: (%le, %le) [T]\n", i, latt->cell[0].mpara[0][1], latt->cell[0].mpara[0][2], latt->cell[0].mpara[2][2]);
				part->s = 0;
				return TRUE;
			}
			for(k=0;k<latt->nbcell;k++) {
				for(j = 0; j < latt->cell[k].nbcomp; j++) {
					latt->cell[k].mpara[j][2] *= pow(((rnew_av-r_co_av) + latt->cell[k].mpara[j][1])/latt->cell[k].mpara[j][1], latt->cell[k].mpara[j][3]);
					printf("B0[%i]=%lf T, ", j, latt->cell[k].mpara[j][2]);
				}
				printf("\n");
			}
			part->x = rnew - (rnew_av-r_co_av);
			//part->x = r_co_av;
			printf("rnew = %lf, r_co_av = %lf\n", rnew, r_co_av);
			//for(j = 0; j < latt->cell[0].nbcomp; j++) printf("latt->cell[0].mpara[%i][1] = %lf\n", j, latt->cell[0].mpara[j][1]); 
		}
		else {
			printf("\n \niteration %i, problem in adjust_r0, closed orbit not found!\n", i);
			part->s = 0;
			return FALSE;
		}
	}
	printf("\n \nin adjust_r0 precision not achieved: eps = %le, increase the number of iterations (now %i) or decrease demanded precision\n \n", fabs(rnew - r_co_av), nb_iterations);
	printf("\n\n\t\t\tB0adjust = %lf [m]\n\n\n", latt->cell[0].mpara[0][2]);
	part->s = 0;
	return FALSE;
}

// reverse the lattice
// ! works with one cell lattices !
extern void reverse_latt(struct Lattice *new_latt, struct Lattice *latt) {
	int n,l;
	
	new_latt->periodicity = 1;
	new_latt->nbcell = 1;
	new_latt->cell = alloccell(new_latt->nbcell);
	new_latt->cell[0].deltar = 0; //default value
	new_latt->cell[0].nbcomp = 1; //default value
	new_latt->cell[0].instrutype = NO; //default value
	//set cell.framework
	new_latt->cell[0].framework = latt->cell[0].framework;
	
	strcpy((new_latt->cell[0].keyword), (latt->cell[0].keyword));
	//printf("  --> Cell[%i] type: \"%s\"\n",nb_refcell+m, latt->cell[nb_refcell+m].keyword);
	if(strcmp(latt->cell[0].keyword, "ffag-r-he") == 0 ||
	   strcmp(latt->cell[0].keyword, "ffag-r-lin") == 0 || 
	   strcmp(latt->cell[0].keyword, "ffag-r-enge") == 0 ||
	   strcmp(latt->cell[0].keyword, "ffag-s-lin") == 0 || 
	   strcmp(latt->cell[0].keyword, "ffag-s-he") == 0 ||
	   strcmp(latt->cell[0].keyword, "ffag-s-enge") == 0 ||
	   strcmp(latt->cell[0].keyword, "ffag-sdl-lin") == 0) {
		new_latt->cell[0].nbcomp = latt->cell[0].nbcomp;
		//allocate memory
		new_latt->cell[0].mpara = allocmatrix(new_latt->cell[0].nbcomp, SIZE_MPARA);
		new_latt->cell[0].efben = allocmatrix(new_latt->cell[0].nbcomp, SIZE_EFB);
		new_latt->cell[0].efbex = allocmatrix(new_latt->cell[0].nbcomp, SIZE_EFB);
		
		//allocate memory for errors
		new_latt->cell[0].alierror = allocmatrix(new_latt->cell[0].nbcomp, SIZE_ALIERR);
		
		new_latt->cell[0].stepsize = latt->cell[0].stepsize;
		new_latt->cell[0].deltar = latt->cell[0].deltar;
		new_latt->cell[0].collim.rmin = latt->cell[0].collim.rmin;
		new_latt->cell[0].collim.rmax = latt->cell[0].collim.rmax;
		new_latt->cell[0].collim.zmin = latt->cell[0].collim.zmin;
		new_latt->cell[0].collim.zmax = latt->cell[0].collim.zmax;
		new_latt->cell[0].boun.thmax = latt->cell[0].boun.thmax;
		new_latt->cell[0].boun.ymax = latt->cell[0].boun.ymax;
		for(n = 0; n < latt->cell[0].nbcomp; n++) {
			new_latt->cell[0].mpara[n][0] = latt->cell[0].boun.ymax - latt->cell[0].mpara[latt->cell[0].nbcomp-1-n][0];
			for(l=1;l<SIZE_MPARA;l++) new_latt->cell[0].mpara[n][l] = latt->cell[0].mpara[latt->cell[0].nbcomp-1-n][l];
			for(l=0;l<SIZE_EFB;l++) new_latt->cell[0].efben[n][l] = latt->cell[0].efben[latt->cell[0].nbcomp-1-n][l];
			for(l=0;l<SIZE_EFB;l++) new_latt->cell[0].efbex[n][l] = latt->cell[0].efbex[latt->cell[0].nbcomp-1-n][l];
		}
	}
}

extern double rec_mul_minus(double a, int i) {
	return (i==0) ? a : rec_mul_minus(a,i-1)*(a-i);
}

extern double rec_mul_plus(double a, int i) {
	return (i==0) ? a : rec_mul_plus(a,i-1)*(a+i);
}

//Routine which gives an initial estimate for an ellipse to N points in the array X,Y.
//Author: K.G. Begeman, N: Number of points in X and Y, X: Array with X-coordinates, Y: Array with Y-coordinates.
// P: Estimated ellipse parameters: P(1) = radius, P(2) = inclination (0..90 degrees), P(3) = X0 (centre), P(4) = Y0 (centre), P(5) = position angle of major axis (0..180 degrees) w.r.t. Y axis.
extern int fit_ellipse1(int *n, double *x, double *y, double *p) {
	double	ellips[5];	// ellipse parameters 
	double	matrix[5][5];// the matrix 
	double	vector[5];	// the vector 
	double	xc, yc;		// centre of ellipse 
	int		i, j, k;
	
	//Due to stability problems with ellipses where the origin is far away from the centre of the ellipse, we first have to find an approximate
	for (xc = yc = 0.0, k = 0; k < (*n); k++) {
		xc += x[k];
		yc += y[k];
	}
	xc /= (double) (*n);	// mean x position
	yc /= (double) (*n);	// mean y position
	
	//Next: initialize the matrix to be inverted by invmat and the vector
	for (i = 0; i < 5; i++) {
		for (j = 0; j < 5; j++) matrix[i][j] = 0.0;
		vector[i] = 0.0;
	}
	
	//Then: fill matrix
	for (k = 0; k < (*n); k++) {
		double	xs = x[k] - xc;	// x coord. w.r.t. centre 
		double	ys = y[k] - yc;	// y coord. w.r.t. centre 
		double	xx;
		double	xy;
		double	yy;
		
		xx = xs * xs;	// x * x 
		xy = xs * ys;	// cross product 
		yy = ys * ys;	// y * y 
		matrix[0][0] += xx * xx;
		matrix[0][1] += 2.0 * xx * xy;
		matrix[0][2] += xy * xy;
		matrix[0][3] += xx * xs;
		matrix[0][4] += xy * xs;
		matrix[1][1] += 4.0 * xy * xy;
		matrix[1][2] += 2.0 * xy * yy;
		matrix[1][3] += 2.0 * xy * xs;
		matrix[1][4] += 2.0 * xy * ys;
		matrix[2][2] += yy * yy;
		matrix[2][3] += xy * ys;
		matrix[2][4] += yy * ys;
		matrix[3][3] += xx;
		matrix[3][4] += xy;
		matrix[4][4] += yy;
		vector[0] += xx;
		vector[1] += 2.0 * xy;
		vector[2] += yy;
		vector[3] += xs;
		vector[4] += ys;
	}
	//make the matrix symmetric since this saves a lot of typing
	for(i = 0; i < 5; i++) for (j = 0; j < i; j++) matrix[i][j] = matrix[j][i];
	
	//invert the matrix
	invmat( matrix, 5 );
	//if(invmat( matrix, 5 )) return( 1 ); // cannot invert matrix 
	
	//solve MATRIX * ELLIPS = VECTOR
	for (i = 0; i < 5; i++) {
		ellips[i] = 0.0;	// reset this ellipse parm.
		for (j = 0; j < 5; j++) ellips[i] += matrix[i][j] * vector[j];
	}
	//NOTE: The ellipse equation taken is AA.x^2 + 2.BB.x.y + CC.y^2 + DD.x + EE.y = 1,
	//Where AA..EE were now solved for from which now the ellipse-parameters are derived
	{
		double	aa = ellips[0];
		double	bb = ellips[1];
		double	cc = ellips[2];
		double	dd = ellips[3];
		double	ee = ellips[4];
		double	pa, pp;
		double	cospa, sinpa, sinpp;
		double	s1, s2, s3, y1, y2, y3;
		double	x0, y0;
		double	ab, al, r;
		
		pp = atan( 2.0 * bb / ( aa - cc ) );	// estimate of position angle 
		pa = 0.5 * pp;				// p.a. of an (UNDETERMINED) axis 
		cospa = cos( pa );			// cosine 
		sinpp = sin( pp );			// sine of double angle 
		sinpa = sin( pa );			// sine 
		al = 2.0 * bb / sinpp / ( aa + cc );	// auxiliary 
		r = sqrt( ( 1.0 + al ) / ( 1.0 - al ) );	// axial ratio (OR ITS RECIPROCAL)
		s1 = bb * ee - cc * dd;			// three other auxiliaries 
		s2 = bb * dd - aa * ee;
		s3 = aa * cc - bb * bb;
		x0 = s1 / s3;				// X-centre of ellipse
		y0 = s2 / s3;				// Y-centre of ellipse
		y1 = sinpa * sinpa + r * r * cospa * cospa;
		y2 = x0 * y0 * ( r * r - 1.0 ) * sinpp;
		y3 = y0 * y0 * ( cospa * cospa + r * r * sinpa * sinpa );
		ab = sqrt( y1 * ( x0 * x0 + 1.0 / aa ) + y2 + y3 ); //length of (yet undetermined) axis (A or B)
		pa = pa * 45.0 / atan( 1.0 );		// convert to degrees 
		
		//determination which axis is the long axis
		if (r < 1.0) {	// the other is 
			ab /= r;	// this one is the major axis 
			pa -= 90.0;	// so change position angle 
		} 
		else r = 1.0 / r; // the right one is, so change axial ratio 
		if (pa < 0.0) pa += 180.0;	// position angle in range 0.....180
		p[0] = ab;				// radius 
		p[1] = acos( r ) * 45.0 / atan( 1.0 );	// inclination assuming projected circle
		p[2] = x0 + xc;	// new x-position of centre
		p[3] = y0 + yc;	// new y-position of centre
		p[4] = pa;		// position angle major axis 
	}
	return 0;
}

//Fits an ellipse to a set of X and Y positions. 
//Author: K.G. Begeman, Returns number of iterations on success, else, -1: No free parameters, -2: Exceede iteration limit (50), -3: Diagonal of matrix has zeroes, -4: Matrix could not be inverted, E: Contains the errors in the fitted parameters, M: Mask for free (1) or fixed (0) parameters
// N: Number of positions, X: Array with X coordinates (in units), Y: Array with Y coordinates (in units), 
// P contains: P(1) = radius (in units), P(2) = inclination (degrees), P(3) = X centre of ellipse (units), P(4) = Y centre of ellipse (units), P(5) = Position angle (degrees).
extern int fit_ellipse2(int *n, double *x, double *y, double *p, double *e, int *m) {
	double chi;		// red. chi-squared 
	double labda;	// mixing parameter
	double q;		// red. chi-squared 
	double rl[5];	// vector 
	double s[5][5], s1[5][5];	// matrices
	double mix_fac = 10.0; //mixing * factor
	double mix_start = 0.01; //start mixing parameter
	double lab_max = 1.0E+10; // max. mixing parameter
	double lab_min = 1.0E-10; // min. mixing parameter
	double tol = 0.00001; //tolerance
	int h = 0;		// iteration counter
	int max_iter = 50; //max. number of iterations
	int i;			// counter
	int ip[5];		// permutation array
	int nfree = 0;	// number of free parameters
	int r = 0;		// return value 
	
	labda = mix_start * mix_fac;	// start value
	for (i = 0; i < 5; i++) if (m[i]) ip[nfree++] = i; // fit this parameter
	if (nfree == 0 || nfree >= (*n)) errorstop("number of free parameters is wrong!");
	do {
		if (++h > max_iter) r = -2; break; // too many iterations
		chi = inimat( s, rl, x, y, (*n), p, e, ip, nfree );
		if (labda > lab_min) labda /= mix_fac;	// new labda
		r = inivec( s, s1, rl, labda, &q, p, e, x, y, (*n), ip, nfree );
		//if (r) break;				// error from inivec 
		while (q >= chi) {			// interpolation loop 
			if (labda > lab_max) break;	// leave loop 
			labda *= mix_fac;				// new labda 
			r = inivec( s, s1, rl, labda, &q, p, e, x, y, (*n), ip, nfree );
			if (r) break;				// error from inivec
		}
		if (labda <= lab_max) for (i = 0; i < 5; i++) p[i] = e[i];
		if (fabs( chi - q ) / q < tol || labda > lab_max) {
			labda = 0.0;				// for Taylor solution 
			chi = inimat( s, rl, x, y, (*n), p, e, ip, nfree );
			r = inivec( s, s1, rl, labda, &q, p, e, x, y, (*n), ip, nfree );
			if (!r) {
				r = h;				// number of iterations
				for (i = 0; i < 5; i++) {
					p[i] = e[i];			// the parameters
					e[i] = 0.0;			// reset errors
				}
				q = sqrt( q / (double) ( (*n) - nfree ) );
				for (i = 0; i < nfree; i++) e[ip[i]] = q * sqrt( s1[i][i] / s[i][i] );
			}
		}
	} while (!r);	// until error or finished 
	return r;
}

/*extern void get_tune_range(char *txtfilename, double *qx_min, double *qx_max, double *qz_min, double *qz_max, double *qx_tot_min, double *qx_tot_max, double *qz_tot_min, double *qz_tot_max) 
{
	int n, nblines;
	double e_tot, qx, qz, qx_tot, qz_tot, temp, qx_min_temp, qz_min_temp, qx_max_temp, qz_max_temp, qx_tot_min_temp, qz_tot_min_temp, qx_tot_max_temp, qz_tot_max_temp;
	FILE *rfile = NULL;
	
	nblines = get_nb_lines_file(txtfilename);
	rfile = fopen(txtfilename, "r");
	if(rfile==NULL) errorstop("cannot open rfile");
	fscanf(rfile, "%le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le", 
	&e_tot, &qx_min_temp, &qz_min_temp, &qx_tot_min_temp, &qz_tot_min_temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp);
	newline(rfile);
	qx_max_temp = qx_min_temp;
	qz_max_temp = qz_min_temp;
	qx_tot_max_temp = qx_tot_min_temp;
	qz_tot_max_temp = qz_tot_min_temp;
	for(n=0;n<nblines-2;n++) {
		fscanf(rfile, "%le  %le  %le  %le  %le", &e_tot, &qx, &qz, &qx_tot, &qz_tot);
		printf("%le  %le  %le  %le  %le\n", e_tot, qx, qz, qx_tot, qz_tot);
		
		fscanf(rfile, "%le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le  %le", 
		&e_tot, &qx, &qz, &qx_tot, &qz_tot, &temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp, &temp);
		//fscanf(rfile, "%le  %le  %le  %le  %le  %le  %le", &ekin_ev, &qx, &qz, &ptot, &ptot2, &qx2, &qz2);
		if(qx<qx_min_temp) qx_min_temp = qx;
		else if(qx>qx_max_temp) qx_max_temp = qx;
		if(qz<qz_min_temp) qz_min_temp = qz;
		else if(qz>qz_max_temp) qz_min_temp = qz;
		if(qx_tot<qx_tot_min_temp) qx_tot_min_temp = qx_tot;
		else if(qx_tot>qx_tot_max_temp) qx_tot_max_temp = qx_tot;
		if(qz_tot<qz_tot_min_temp) qz_tot_min_temp = qz_tot;
		else if(qz_tot>qz_tot_max_temp) qz_tot_min_temp = qz_tot;
	}
	fclose(rfile);
	*qx_min = floor(qx_min_temp);
	*qx_max = floor(qx_max_temp)+1;
	*qz_min = floor(qz_min_temp);
	*qz_max = floor(qz_max_temp)+1;
	*qx_tot_min = floor(qx_tot_min_temp);
	*qx_tot_max = floor(qx_tot_max_temp)+1;
	*qz_tot_min = floor(qz_tot_min_temp);
	*qz_tot_max = floor(qz_tot_max_temp)+1;
}//*/

extern void get_betamin_file(char *txtfilename, double *betamin) {
	int n, nblines;
	double s, bx, ax, bz, bmin=1.0e18;//, az;
	FILE *rfile = NULL;
	
	nblines = get_nb_lines_file(txtfilename);
	rfile = fopen(txtfilename, "r");
	if(rfile==NULL) errorstop("cannot open rfile");
	for(n=0;n<nblines-1;n++) {
		//fscanf(rfile, "%le	%le	%le	%le	%le", &s, &bx, &ax, &bz, &az);
		fscanf(rfile, "%le	%le	%le	%le", &s, &bx, &ax, &bz);
		if(bmin > bx || bmin > bz) bmin = MIN(bx, bz);
		newline(rfile);
	}
	*betamin = bmin;
	//printf("betamax = %lf\n", bmax);
	fclose(rfile);
}

// compute x, x', z, z' w/ respect to the closed orbit from the particle parameters 
extern void comp_phase_space_coord(double *x, double *xprime, double *z, double *zprime, double test_x, double test_z, double test_ux, double test_uy, double test_uz, double x_ref, double xprime_ref, double z_ref, double zprime_ref) {
	double php_test;
	 
	*xprime = atan_ratio(test_ux, test_uy) - xprime_ref;
	//*x = xpart[n] - reference->x;
	*x = (test_x - x_ref)*(cos(xprime_ref) + sin(xprime_ref)*tan(*xprime));
	php_test = sqrt(test_ux*test_ux + test_uy*test_uy);
	*zprime = atan_ratio(test_uz, php_test) - zprime_ref;
	//z = zpart[n] - reference->z;
	*z = (test_z - z_ref)*(cos(zprime_ref) + sin(zprime_ref)*tan(*zprime));
}

extern double compute_av_radius_from_trackout_1cell(char *trackout, int doyouprintf) {
	int i, nblines;
	double s, x, y, z, bx, by, bz, ux, uy, uz, th, r, rtot=0, s0=0;
	FILE *rfile = NULL;
	
	nblines = get_nb_lines_file(trackout);
	
	rfile = fopen(trackout, "r");
	if(rfile == NULL) errorstop("!!!ERROR in compute_av_radius_from_trackout_1cell: cannot open inputfile!!!");
	
	for(i=0;i<nblines-1;i++) {
		fscanf(rfile, "%le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le", &s, &x, &y, &z, &bx, &by, &bz, &ux, &uy, &uz, &r, &th);
		//fscanf(rfile, "%le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le", &s, &x, &y, &z, &bx, &by, &bz, &ux, &uy, &uz, &brho, &t, &r);
		//printf("r=%le, s=%le\n", r, s);
		rtot += r*(s-s0); 
		newline(rfile);
		s0 = s;
	}
	fclose(rfile);
	rtot = rtot/s;
	//rtot=rtot/nblines;
	if(doyouprintf==YES) printf("average radius %le\n", rtot);
	return rtot;
}

extern void compute_av_min_max_radius_from_trackout_1cell(char *trackout, double *r_av, double *rmin, double *rmax, int doyouprintf) {
	int i, nblines = get_nb_lines_file(trackout);
	double s, x, y, z, bx, by, bz, ux, uy, uz, th, r, s0=0;
	FILE *rfile = NULL;
	*r_av = 0;
	*rmin = 1.e9;
	*rmax = 0;
	
	rfile = fopen(trackout, "r");
	if(rfile == NULL) errorstop("!!!ERROR in compute_av_radius_from_trackout_1cell: cannot open inputfile!!!");
	
	for(i=0;i<nblines-1;i++) {
		fscanf(rfile, "%le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le", &s, &x, &y, &z, &bx, &by, &bz, &ux, &uy, &uz, &r, &th);
		//fscanf(rfile, "%le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le \t %le", &s, &x, &y, &z, &bx, &by, &bz, &ux, &uy, &uz, &brho, &t, &r);
		//printf("r=%le, s=%le\n", r, s);
		*rmin = MIN(r, *rmin);
		*rmax = MAX(r, *rmax);
		*r_av += r*(s-s0); 
		newline(rfile);
		s0 = s;
	}
	fclose(rfile);
	*r_av = *r_av/s;
	if(doyouprintf==YES) printf("radius (min, max, avg) = (%le, %le, %le)\n", *rmin, *rmax, *r_av);
}

extern double compute_s_latt(struct Particle *part, struct Lattice *latt) {
	struct Particle test_part;
	test_part = *part;
	test_part.s = 0;
	part_cross_latt(&test_part, latt, NULL, NULL);
	return test_part.s;
}

extern void compute_sxy_latt(struct Particle *part, struct Lattice *latt, double *s, double *x, double *y) {
	struct Particle test_part;
	test_part = *part;
	test_part.s = 0;
	part_cross_latt(&test_part, latt, NULL, NULL);
	*s = test_part.s;
	*x = test_part.x;
	*y = test_part.y;
}

// ************************************************************************************ //
////////////////  field measurements  //////////////////////////
// ************************************************************************************ //

// Integration of Bz along a straight line in a cell
extern void int_bz_liney_cell(double *intbdl, double *intbdlabs, double x, double ymin, double ymax, int nstep, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int)) {
	int i;
	double ystep, y, z, bprobe[4];
	
	//ystep = (ymax - ymin)/nstep; 
	ystep = comp_step(ymin, ymax, nstep, NO);
	*intbdl = 0;		//int{bz.dl}
	*intbdlabs = 0;		//int{|bz|.dl}
	z = 0;				// allways in the midplane
	
	for(i = 0; i < nstep + 1; i++) {
		y = ymin + i*ystep;
		if(get_bfield(x, y, z, &bprobe[1], &bprobe[2], &bprobe[3], cell, add_contribution_comp) != ALIVE) errorstop("int_bz_liney_cell: get_bfield != ALIVE\n");
		*intbdl += bprobe[3]*ystep;
		*intbdlabs += fabs(bprobe[3])*ystep;
	}
}

// Integration of Bz along a radius in a cell
extern void int_bz_radius_cell(double *intbdl, double *intbdlabs, double r, double thmin, double thmax, int nstep, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int)) {
	int i;
	double thstep, th, z, bprobe[4], x, y;
	
	//thstep = (thmax - thmin)/nstep; 
	thstep = comp_step(thmin, thmax, nstep, NO);
	*intbdl = 0;		//int{bz.dl}
	*intbdlabs = 0;		//int{|bz|.dl}
	z = 0;				// allways in the midplane
	
	for(i = 0; i < nstep + 1; i++) {
		th = thmin + i*thstep;
		x = r*cos(th);
		y = r*sin(th);
		if(get_bfield(x, y, z, &bprobe[1], &bprobe[2], &bprobe[3], cell, add_contribution_comp) != ALIVE) errorstop("int_bz_radius_cell: get_bfield != ALIVE\n");
		*intbdl += bprobe[3]*r*thstep;
		*intbdlabs += fabs(bprobe[3])*r*thstep;
	}
}

// Integration of Bz along a radius in a cell, and min and max value of Bz
extern void int_bz_max_min_radius_cell(double *intbdl, double *intbdlabs, double *bmax, double *bmin, double r, double thmin, double thmax, int nstep, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int)) {
	int i;
	double thstep, th, z, bprobe[4], x, y;
	
	*bmin = 1.e9;
	*bmax = -1.e9;
	thstep = comp_step(thmin, thmax, nstep, NO);
	*intbdl = 0;		//int{bz.dl}
	*intbdlabs = 0;		//int{|bz|.dl}
	z = 0;				// always in the midplane
	
	for(i = 0; i < nstep + 1; i++) {
		th = thmin + i*thstep;
		x = r*cos(th);
		y = r*sin(th);
		if(get_bfield(x, y, z, &bprobe[1], &bprobe[2], &bprobe[3], cell, add_contribution_comp) != ALIVE) errorstop("int_bz_radius_cell: get_bfield != ALIVE\n");
		*intbdl += bprobe[3]*r*thstep;
		*intbdlabs += fabs(bprobe[3])*r*thstep;
		if(*bmin>bprobe[3]) *bmin = bprobe[3];
		if(*bmax<bprobe[3]) *bmax = bprobe[3];
	}
}

extern double comp_k_value_local(double r, double deltar, double bdeltar, double b) {
	return r*(bdeltar-b)/(b*deltar);
}

extern double comp_k_value_local_2ndorder(double r, double b0, double deltar, double bdeltar, double b) {
	return r*(bdeltar-b)/(b0*2.*deltar);
}

extern void k_loc_cell2(char *outfilename, double thmin, double thmax, int nstep_th, double rmin, double rmax, int nstep_r, double deltar, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int)) {
	int i;
	double rstep, k_cell, k_d, k_f, k_f_cent, k_d_cent, r, intbdl, intbdlabs, bmin, bmax, intbdl_dr, intbdlabs_dr, bmin_dr, bmax_dr;
	FILE *wfile;
	
	//calculation of BL
	rstep = comp_step(rmin, rmax, nstep_r, NO);
	//printf("rstep = %le\n",rstep);
	wfile = fopen(outfilename,"w");
	fprintf(wfile, "r, k_cell, k_f, k_d, k_f_cent, k_d_cent, intbdl, intbdl_abs, bmin, bmax, intbdl_dr, intbdl_abs_dr, bmin_dr, bmax_dr\n");
	
	for(i = 0; i < nstep_r + 1; i++) {
		r = rmin + i*rstep;
		int_bz_max_min_radius_cell(&(intbdl), &(intbdlabs), &bmax, &bmin, r, thmin, thmax, nstep_th, cell, add_contribution_comp);
		int_bz_max_min_radius_cell(&(intbdl_dr), &(intbdlabs_dr), &bmax_dr, &bmin_dr, r+deltar, thmin, thmax, nstep_th, cell, add_contribution_comp);
		k_cell = comp_k_value_local(r, deltar, intbdl_dr, intbdl);
		k_d = comp_k_value_local(r, deltar, (intbdlabs_dr+intbdl_dr)/2., (intbdlabs+intbdl)/2.); //positive part of the integral (D magnet)
		k_f = comp_k_value_local(r, deltar, (intbdlabs_dr-intbdl_dr)/2., (intbdlabs-intbdl)/2.); //negative part of the integral (F magnet)
		if (bmin<0 && bmin_dr<0) k_f_cent = comp_k_value_local(r, deltar, bmin_dr, bmin); 
		else k_f_cent = 0;
		if (bmax>0 && bmax_dr>0) k_d_cent = comp_k_value_local(r, deltar, bmax_dr, bmax); 
		else k_d_cent = 0;
		fprintf(wfile, "%lf	%le	%le	%le	%le	%le	%le	%le	%le	%le	%le	%le	%le	%le\n", r, k_cell, k_f, k_d, k_f_cent, k_d_cent, intbdl, intbdlabs, bmin, bmax, intbdl_dr, intbdlabs_dr, bmin_dr, bmax_dr);
	}
	fclose(wfile);
}

extern void compute_local_k_difference(char *text_write, char *case_name, double k_target) {
	char field_name[300];
	int i, nblines;
	double rstep;// = (4.1472-3.583945)/499;
	double r,rtemp, bth,bop,dif, k_loc, bop_temp;
	
	
	sprintf(field_name, "%s_field.dat", case_name);
	FILE *rfile = NULL;
	FILE *wfile;
	
	nblines = get_nb_lines_file(field_name);
	
	wfile = fopen(text_write, "w");
	rfile = fopen(field_name, "r");
	if(rfile==NULL) errorstop("cannot open rfile");
	fscanf(rfile, "%lf %lf %lf %lf", &r, &bth, &bop, &dif);
	newline(rfile);
	rtemp = r;
	bop_temp = bop;
	rstep = r-rtemp;
	for(i=0;i<nblines;i++) {
		fscanf(rfile, "%lf %lf %lf %lf", &r, &bth, &bop, &dif);
		newline(rfile);
		rstep = r-rtemp;
		k_loc = comp_k_value_local(r, rstep, bop, bop_temp);
		fprintf(wfile, "%lf %lf %lf %lf	%lf\n", r, bth, bop, dif, (k_loc-k_target)/k_target);
		bop_temp = bop;
		rtemp = r;
		
	}
	fclose(rfile);
	fclose(wfile);
}

extern void compute_k_value_heatmap(char *textfile, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int), double r0, double rmax, int nbr, double th0, double thmax, int nbth, double z0, double deltar, double spi_angle_deg) {
	int i,j, flag;
	double x_1,y_1,x_2,y_2,bx1,by1,bz1,bx2,by2,bz2,r1,r2,th,th2,rstep,thstep,k_loc;
	FILE *wfile;
	
	rstep = comp_step(r0, rmax, nbr, NO);
	thstep = comp_step(th0, thmax, nbth, NO);
	wfile=fopen(textfile, "w");
	
	printf("rstep=%le[m], thstep=%le[deg]\n",rstep,thstep*180./PI);
	
	for(i=0;i<nbth;i++) {
		th = th0 + i*thstep;
		for(j=0;j<nbr;j++) {
			r1 = r0 + j*rstep;
			x_1 = r1*cos(th);
			y_1 = r1*sin(th);
			//printf("r=%le,th=%le, x1,y1=%le,%le\n",r1,th, x_1,y_1);
			flag = NO;
			if(get_bfield(x_1, y_1, z0, &bx1, &by1, &bz1, cell, add_contribution_comp)!=ALIVE) {
				flag = YES;
				//errorstop("field not alive\n");
				bx1 = 0.;
				by1 = 0.;
				bz1 = 0.;
			}
			r2 = r1 + deltar;
			th2 = th + tan(spi_angle_deg*PI/180.)*log(r2/r1);
			x_2 = r2*cos(th2);
			y_2 = r2*sin(th2);
			//printf("x2,y2=%le,%le\n", x_2,y_2);
			if(get_bfield(x_2, y_2, z0, &bx2, &by2, &bz2, cell, add_contribution_comp)!=ALIVE) {
				flag = YES;
				//errorstop("field not alive\n");
				bx2 = 0.;
				by2 = 0.;
				bz2 = 0.;
			}
			if(fabs(bz2)<5.e-3 || fabs(bz1)<5.e-3) flag = YES;
			if(flag==NO) k_loc = comp_k_value_local(r1, deltar, bz2, bz1);
			else k_loc = 0;
			fprintf(wfile,"%le\t%le\t%le\n", y_1, x_1, k_loc);
		}
		fprintf(wfile,"\n"); // to build file to plot easyplot3dmap
	}
	fclose(wfile);
}

extern void print_get_bfield_across_cell_radius(char *fileout, double r, double thmax_deg, int nbsteps, double z, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int)) {
	int i;
	double x, y, bx, by, bz;
	double br,bth, th, thstep;
	FILE *wfile;
	wfile = fopen(fileout,"a");
	fprintf(wfile, "r [m], theta [deg], z [m], Br [T], Btheta, Bz\n");
	thstep = comp_step(0, thmax_deg*PI/180., nbsteps, NO);
	
	for(i = 0; i < nbsteps; i++) {
		th = i*thstep;
		x = r*cos(th);
		y = r*sin(th);
		if(get_bfield(x, y, z, &bx, &by, &bz, cell, add_contribution_comp)!=ALIVE) errorstop("get_bfield not ALIVE");
		br = bx*cos(th) + by*sin(th);
		bth = by*cos(th) - bx*sin(th);
		fprintf(wfile, "%le	%le	%le	%le	%le	%le\n", r, th*180./PI, z, br, bth, bz);
		//fprintf(wfile, "%le	%le	%le	%le	%le	%le\n", r, th*180./PI-22.5, z, br, bth, bz);
		//fprintf(wfile, "%le	%le	%le	%le	%le	%le\n", r, th*180./PI, z, bx, by, bz);
	}
	fclose(wfile);
}

extern void print_get_bfield_straight_line(char *fileout, double x, double ymax, int nbsteps, double z, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int)) {
	int i;
	double y, bx, by, bz;
	double ystep;
	FILE *wfile;
	wfile = fopen(fileout,"a");
	ystep = comp_step(0, ymax, nbsteps, NO);
	
	for(i = 0; i < nbsteps; i++) {
		y = i*ystep;
		if(get_bfield(x, y, z, &bx, &by, &bz, cell, add_contribution_comp)!=ALIVE) errorstop("get_bfield not ALIVE");
		fprintf(wfile, "%le	%le	%le	%le	%le	%le\n", x, y, z, bx, by, bz);
		//fprintf(wfile, "%le	%le	%le	%le	%le	%le\n", r, th*180./PI, z, bx, by, bz);
	}
	fclose(wfile);
}

extern void print_get_bfield_across_cell_radius_difference(char *fileout, double r, double thmax_deg, int nbsteps, double z, struct Cell *cell1, void(*add_contribution_comp1)(double,double,double,double*,double*,double*,struct Cell*,int), struct Cell *cell2, void(*add_contribution_comp2)(double,double,double,double*,double*,double*,struct Cell*,int), int flip)
{
	int i;
	double x, y, bx1,by1,bz1,bx2,by2,bz2, br1, br2, bth1, bth2;
	double th, thstep;
	FILE *wfile;
	wfile = fopen(fileout,"a");
	thstep = comp_step(0, thmax_deg*PI/180., nbsteps, NO);
	
	for(i = 0; i < nbsteps; i++) {
		th = i*thstep;
		x = r*cos(th);
		y = r*sin(th);
		if(get_bfield(x, y, z, &bx1, &by1, &bz1, cell1, add_contribution_comp1)!=ALIVE) errorstop("get_bfield 1 not ALIVE");
		br1 = bx1*cos(th) + by1*sin(th);
		bth1 = by1*cos(th) - bx1*sin(th);
		if(get_bfield(x, y, z, &bx2, &by2, &bz2, cell2, add_contribution_comp2)!=ALIVE) errorstop("get_bfield 2 not ALIVE");
		br2 = bx2*cos(th) + by2*sin(th);
		bth2 = by2*cos(th) - bx2*sin(th);
		if(flip==NO) fprintf(wfile, "%le	%le	%le	%le	%le	%le\n", r, th*180./PI, z, br1-br2, bth1-bth2, bz1-bz2);
		else fprintf(wfile, "%le	%le	%le	%le	%le	%le\n", r, th*180./PI, z, br1+br2, bth1+bth2, bz1+bz2);
		//fprintf(wfile, "%le	%le	%le	%le	%le	%le\n", r, th*180./PI, z, bx, by, bz);
	}
	fclose(wfile);
}

extern void print_get_bfield_straight_line_difference(char *fileout, double x, double ymax, int nbsteps, double z, struct Cell *cell1, void(*add_contribution_comp1)(double,double,double,double*,double*,double*,struct Cell*,int), struct Cell *cell2, void(*add_contribution_comp2)(double,double,double,double*,double*,double*,struct Cell*,int), int flip)
{
	int i;
	double y, bx1,by1,bz1,bx2,by2,bz2;
	double ystep;
	FILE *wfile;
	wfile = fopen(fileout,"a");
	ystep = comp_step(0, ymax, nbsteps, NO);
	
	for(i = 0; i < nbsteps; i++) {
		y = i*ystep;
		if(get_bfield(x, y, z, &bx1, &by1, &bz1, cell1, add_contribution_comp1)!=ALIVE) errorstop("get_bfield 1 not ALIVE");
		if(get_bfield(x, y, z, &bx2, &by2, &bz2, cell2, add_contribution_comp2)!=ALIVE) errorstop("get_bfield 2 not ALIVE");
		if(flip==NO) fprintf(wfile, "%le	%le	%le	%le	%le	%le\n", x, y, z, bx1-bx2, by1-by2, bz1-bz2);
		else fprintf(wfile, "%le	%le	%le	%le	%le	%le\n", x, y, z, bx1+bx2, by1+by2, bz1+bz2);
		//fprintf(wfile, "%le	%le	%le	%le	%le	%le\n", r, th*180./PI, z, bx, by, bz);
	}
	fclose(wfile);
}

// ************************************************************************************ //
////////////////  compute field maps  //////////////////////////
// ************************************************************************************ //

extern void compute_fieldmap(char *filename, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int),
	double r0, double rmax, int nbr, double th0, double thmax, int nbth, double z0, double zmax, int nbz)
{
	int i,j,k, circ=YES;
	double x,y,z,bx,by,bz,br,bth,r,th, rstep,thstep,zstep;
	
	FILE *wfile;

	wfile = fopen(filename,"w");
	//fprintf(wfile,"%i %i %i\n",nbr,nbth,nbz);
	//fprintf(wfile,"(%i, %i, %i) nodes\n",nbr,nbth,nbz);
	
	//if(nbz>1) zstep = (zmax-z0)/(nbz-1);
	//else zstep = 0.;
	zstep = comp_step(z0, zmax, nbz, NO);
	//if(nbr>1) rstep = (rmax-r0)/(nbr-1);
	//else rstep = 0.;
	rstep = comp_step(r0, rmax, nbr, NO);
	//if(nbth>1) thstep = (thmax-th0)/(nbth-1);
	//else thstep = 0.;
	thstep = comp_step(th0, thmax, nbth, NO);
	fprintf(wfile,"cylindrical grid with steps (%le [m], %le [deg], %le [m])\n", rstep,thstep*180./PI,zstep);
	fprintf(wfile,"from (%le, %le, %le) to (%le, %le, %le)\n",r0, th0, z0, rmax, thmax*180./PI, zmax);
	fprintf(wfile, "r [m], theta [deg], z [m], Br [T], Btheta, Bz\n");
	
	printf("rstep=%le, thstep=%le, zstep = %le\n", rstep,thstep,zstep);
	
	for(i=0;i<nbz;i++) {
		z = z0 + i*zstep;
		for(j=0;j<nbr;j++) {
			r = r0 + j*rstep;
			for(k=0;k<nbth;k++) {
				th = k*thstep;
				if(circ == YES) {
					x = r*cos(th);
					y = r*sin(th);
				}
				else {
					x = r;
					y = th;
				}
				//printf("%le, %le, %le\n", x, y, z);
				if(get_bfield(x, y, z, &bx, &by, &bz, cell, add_contribution_comp)!=ALIVE) errorstop("bfield not alive");
				//printf("%lf, %lf, %lf	%le, %le, %le\n", x, y, z, bx, by, bz);
				
				//x = r*cos(th-thmax/2.);
				//y = r*sin(th-thmax/2.);
				//fprintf(wfile,"%lf	%lf	%lf	%lf	%lf	%le	%le	%le\n", x, y, z, r, th*180./PI, bx, by, bz);
				//fprintf(wfile,"%lf	%lf	%lf	%lf	%lf	%lf	%lf	%lf\n", x, y, z, r, th, bx, by, bz);
				//fprintf(wfile,"%lf	%lf	%lf	%lf	%lf	%lf\n", x*100, z*100, y*100, bx*10000, bz*10000, by*10000);
				br = bx*cos(th) + by*sin(th);
				bth = by*cos(th) - bx*sin(th);
				//fprintf(wfile,"%lf	%lf	%lf	%lf	%lf	%lf\n", r, th*180./PI, z, br, bth, bz);
				fprintf(wfile,"%lf	%lf	%lf	%lf	%lf	%lf\n", r, th*180./PI-22.5, z, br, bth, bz);
				//fprintf(wfile,"%lf	%lf	%lf	%lf	%lf	%lf\n", r, th*180./PI, z, bx, by, bz);
			}
		}
	}
	fclose(wfile);
}

extern void compute_map(char *filename, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int), double unitlength, double bscale,
	int loop_order, int line_order, int header_skip, double rstart, double rend, int nbr, double rshift, double thstart, double thend, int nbth, double thshift, double zstart, double zend, int nbz, double zshift)
{
	int i,i1,i2,i3,n1,n2,n3,ir,ith,iz;
	double x,y,z,bx,by,bz,r,th, rstep,thstep,zstep,coord[4],btemp[4];
	
	FILE *wfile;
	wfile = fopen(filename,"w");
	fprintf(wfile,"%i     %i     %i\n",nbr,nbth,nbz);
	for(i=0;i<header_skip-1;i++) fprintf(wfile,"\n"); //jump header_skip -1 lines of header

	//if(nbz>1) zstep = (zend-zstart)/(nbz-1);
	//else zstep = 0.;
	zstep = comp_step(zstart, zend, nbz-1, NO);
	//if(nbr>1) rstep = (rend-rstart)/(nbr-1);
	//else rstep = 0.;
	rstep = comp_step(rstart, rend, nbr-1, NO);
	//if(nbth>1) thstep = (thend-thstart)/(nbth-1);
	//else thstep = 0.;
	thstep = comp_step(thstart, thend, nbth-1, NO);
	
	if(loop_order/100%10 == 1) n1=nbr;
	else if(loop_order/100%10 == 2) n1=nbth;
	else n1 = nbz;
	if(loop_order/10%10 == 1) n2=nbr;
	else if(loop_order/10%10 == 2) n2=nbth;
	else n2 = nbz;
	if(loop_order%10 == 1) n3=nbr;
	else if(loop_order%10 == 2) n3=nbth;
	else n3 = nbz;
	
	for(i1 = 0; i1 < n1; i1++) {
		if(loop_order/100%10 == 1) ir=i1;
		else if(loop_order/100%10 == 2) ith=i1;
		else iz = i1;
		for(i2 = 0; i2 < n2; i2++) {
			if(loop_order/10%10 == 1) ir=i2;
			else if(loop_order/10%10 == 2) ith=i2;
			else iz = i2;
			for(i3 = 0; i3 < n3; i3++) {
				if(loop_order%10 == 1) ir=i3;
				else if(loop_order%10 == 2) ith=i3;
				else iz = i3;
				r = rstart + ir*rstep;
				th = thstart + ith*thstep;
				z = zstart + iz*zstep;
				x = r*cos(th);
				y = r*sin(th);
				//printf("r=%lf, th=%le, z=%le\n",r,th,z);
				if(get_bfield(x, y, z, &bx, &by, &bz, cell, add_contribution_comp)==ALIVE) {
					x = (r+rshift)*cos(th+thshift);
					y = (r+rshift)*sin(th+thshift);
					z += zshift;
					if(line_order/100%10 == 1) {
						coord[1] = x;
						btemp[1] = bx;
					}
					else if(line_order/100%10 == 2) {
						coord[1] = y;
						btemp[1] = by;
					}
					else {
						coord[1] = z;
						btemp[1] = bz;
					}
					if(line_order/10%10 == 1) {
						coord[2] = x;
						btemp[2] = bx;
					}
					else if(line_order/10%10 == 2) {
						coord[2] = y;
						btemp[2] = by;
					}
					else {
						coord[2] = z;
						btemp[2] = bz;
					}
					if(line_order%10 == 1) {
						coord[3] = x;
						btemp[3] = bx;
					}
					else if(line_order%10 == 2) {
						coord[3] = y;
						btemp[3] = by;
					}
					else {
						coord[3] = z;
						btemp[3] = bz;
					}
					fprintf(wfile,"%lf	%lf	%lf	%lf	%lf	%lf\n", coord[1]*unitlength, coord[2]*unitlength, coord[3]*unitlength, btemp[1]/bscale, btemp[2]/bscale, btemp[3]/bscale);
				}
				else errorstop("bfield not alive");
			}
		}
	}
	fclose(wfile);
}

extern void compute_map_polar(char *filename, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int),
	double rstart, double rend, int nbr, double rshift, double thstart, double thend, int nbth, double thshift, double zstart, double zend, int nbz, double zshift)
{
	int ir,ith,iz;
	double x,y,z,bx,by,bz,r,th, br,bth, rstep,thstep,zstep;
	
	FILE *wfile;
	wfile = fopen(filename,"w");
	fprintf(wfile, "%i %i %i\n", nbr, nbth, nbz);
	fprintf(wfile,"%i steps in r, from %le to %le (unit: m)\n",nbr-1, rstart+rshift, rend+rshift);
	fprintf(wfile,"%i steps in theta, from %le to %le (unit: deg)\n",nbth-1, thstart+thshift, thend+thshift);
	fprintf(wfile,"%i steps in z, from %le to %le (unit: m)\n",nbz-1, zstart+zshift, zend+zshift);
	fprintf(wfile, "magnetic field unit: T\n");
	fprintf(wfile, "line order: r (horizontal radius), theta (azimuthal angle), z (vertical), B_r, B_theta, B_z\n");
	fprintf(wfile, "loop iteration order: z, theta, r\n\n");

	zstep = comp_step(zstart, zend, nbz, NO);
	rstep = comp_step(rstart, rend, nbr, NO);
	thstep = comp_step(thstart, thend, nbth, NO);
	
	for(ir = 0; ir < nbr; ir++) {
		for(ith = 0; ith < nbth; ith++) {
			for(iz = 0; iz < nbz; iz++) {
				r = rstart + ir*rstep;
				th = thstart + ith*thstep;
				z = zstart + iz*zstep;
				x = r*cos(th);
				y = r*sin(th);
				printf("r=%lf, th=%le, z=%le\n",r,th*180/PI,z);
				if(get_bfield(x, y, z, &bx, &by, &bz, cell, add_contribution_comp)==ALIVE) {
					br = bx*cos(th) + by*sin(th);
					bth = -br*sin(th) + by*cos(th);
					r += rshift;
					th += thshift;
					th *= 180./(PI);
					z += zshift;
					fprintf(wfile,"%lf	%lf	%lf	%le	%le	%le\n", r, th, z, br, bth, bz);
				}
				else errorstop("bfield not alive");
			}
		}
	}
	fclose(wfile);
}

extern void compute_str_map(char *filename, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int), double unitlength, double bscale,
	int loop_order, int line_order, int header_skip, double xstart, double xend, int nbx, double ystart, double yend, int nby, double zstart, double zend, int nbz)
{
	int i,i1,i2,i3,n1,n2,n3,ix,iy,iz;
	double x,y,z,bx,by,bz, xstep,ystep,zstep,coord[4],btemp[4];
	
	FILE *wfile;
	wfile = fopen(filename,"w");
	fprintf(wfile,"%i     %i     %i\n",nbx,nby,nbz);
	for(i=0;i<header_skip-1;i++) fprintf(wfile,"\n"); //jump header_skip -1 lines of header
	
	//if(nbz>1) zstep = (zend-zstart)/(nbz-1);
	//else zstep = 0.;
	zstep = comp_step(zstart, zend, nbz, NO);
	//if(nbr>1) rstep = (rend-rstart)/(nbr-1);
	//else rstep = 0.;
	xstep = comp_step(xstart, xend, nbx, NO);
	//if(nbth>1) thstep = (thend-thstart)/(nbth-1);
	//else thstep = 0.;
	ystep = comp_step(ystart, yend, nby, NO);
	
	fprintf(wfile,"(%i, %i, %i) nodes\n",nbx,nbz,nby);
	fprintf(wfile,"from (%le, %le, %le) to (%le, %le, %le)\n",xstart, zstart, ystart, xend, zend, yend);
	fprintf(wfile,"cartesian grid with step (%le [m], %le [m], %le [m])\n", xstep,zstep,ystep);
	fprintf(wfile, "x (hor) [m], y (vert) [m], z (long) [m], Bx [T], By, Bz\n");
	
	if(loop_order/100%10 == 1) n1=nbx;
	else if(loop_order/100%10 == 2) n1=nby;
	else n1 = nbz;
	if(loop_order/10%10 == 1) n2=nbx;
	else if(loop_order/10%10 == 2) n2=nby;
	else n2 = nbz;
	if(loop_order%10 == 1) n3=nbx;
	else if(loop_order%10 == 2) n3=nby;
	else n3 = nbz;
	
	for(i1 = 0; i1 < n1; i1++) {
		if(loop_order/100%10 == 1) ix=i1;
		else if(loop_order/100%10 == 2) iy=i1;
		else iz = i1;
		for(i2 = 0; i2 < n2; i2++) {
			if(loop_order/10%10 == 1) ix=i2;
			else if(loop_order/10%10 == 2) iy=i2;
			else iz = i2;
			for(i3 = 0; i3 < n3; i3++) {
				if(loop_order%10 == 1) ix=i3;
				else if(loop_order%10 == 2) iy=i3;
				else iz = i3;
				x = xstart + ix*xstep;
				y = ystart + iy*ystep;
				z = zstart + iz*zstep;
				//printf("(x,y,z)=(%lf,%lf,%lf)\n",x,y,z);
				//printf("r=%lf, th=%le, z=%le\n",r,th,z);
				if(get_bfield(x, y, z, &bx, &by, &bz, cell, add_contribution_comp)==ALIVE) {
					if(line_order/100%10 == 1) {
						coord[1] = x;
						btemp[1] = bx;
					}
					else if(line_order/100%10 == 2) {
						coord[1] = y;
						btemp[1] = by;
					}
					else {
						coord[1] = z;
						btemp[1] = bz;
					}
					if(line_order/10%10 == 1) {
						coord[2] = x;
						btemp[2] = bx;
					}
					else if(line_order/10%10 == 2) {
						coord[2] = y;
						btemp[2] = by;
					}
					else {
						coord[2] = z;
						btemp[2] = bz;
					}
					if(line_order%10 == 1) {
						coord[3] = x;
						btemp[3] = bx;
					}
					else if(line_order%10 == 2) {
						coord[3] = y;
						btemp[3] = by;
					}
					else {
						coord[3] = z;
						btemp[3] = bz;
					}
					fprintf(wfile,"%lf	%lf	%lf	%lf	%lf	%lf\n", coord[1]*unitlength, coord[2]*unitlength, coord[3]*unitlength, btemp[1]/bscale, btemp[2]/bscale, btemp[3]/bscale);
				}
				else errorstop("bfield not alive");
			}
		}
	}
	fclose(wfile);
}

// ************************************************************************************ //
////////////////  Maxwell Tests  ///////////////////////////////
// ************************************************************************************ //

extern void test_field_maxwell(double x, double y, double z, double dx, double dy, double dz, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int)) {
	double bx, by, bz, bxpdx, bxpdy, bxpdz, bypdy, bypdx, bypdz, bzpdz, bzpdx, bzpdy;
	 
	get_bfield(x, y, z, &bx, &by, &bz, cell,add_contribution_comp);
	get_bfield(x+dx, y, z, &bxpdx, &bypdx, &bzpdx, cell,add_contribution_comp);
	get_bfield(x, y+dy, z, &bxpdy, &bypdy, &bzpdy, cell,add_contribution_comp);
	get_bfield(x, y, z+dz, &bxpdz, &bypdz, &bzpdz, cell,add_contribution_comp);
	
	printf("TEST IF FIELD SATISFIES DivB = 0\n");
	printf("divB = %le\n", (bxpdx - bx)/dx+(bypdy - by)/dy+(bzpdz - bz)/dz);
	printf("TEST IF FIELD SATISFIES RotB = 0\n");
	printf("dBzdx - dBxdz = %le, while dBzdx = %le\n", (bzpdx - bz)/dx - (bxpdz - bx)/dz, (bzpdx - bz)/dx);
	printf("dBzdy - dBydz = %le, while dBzdy = %le\n", (bzpdy - bz)/dy - (bypdz - by)/dz, (bzpdy - bz)/dy);
	printf("dBxdy - dBydx = %le, while dBxdy = %le\n", (bxpdy - bx)/dy - (bypdx - by)/dx, (bxpdy - bx)/dy);
}

extern void test_field_maxwell2(double x, double y, double z, double dx, double dy, double dz, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int)) {
	double bx, by, bz, bxpdx, bxpdy, bxpdz, bypdy, bypdx, bypdz, bzpdz, bzpdx, bzpdy, bxmdx, bxmdy, bxmdz, bymdy, bymdx, bymdz, bzmdz, bzmdx, bzmdy;
	 
	get_bfield(x, y, z, &bx, &by, &bz, cell,add_contribution_comp);
	get_bfield(x+dx, y, z, &bxpdx, &bypdx, &bzpdx, cell,add_contribution_comp);
	get_bfield(x, y+dy, z, &bxpdy, &bypdy, &bzpdy, cell,add_contribution_comp);
	get_bfield(x, y, z+dz, &bxpdz, &bypdz, &bzpdz, cell,add_contribution_comp);
	get_bfield(x-dx, y, z, &bxmdx, &bymdx, &bzmdx, cell,add_contribution_comp);
	get_bfield(x, y-dy, z, &bxmdy, &bymdy, &bzmdy, cell,add_contribution_comp);
	get_bfield(x, y, z-dz, &bxmdz, &bymdz, &bzmdz, cell,add_contribution_comp);
	
	printf("TEST IF FIELD SATISFIES DivB = 0\n");
	printf("divB = %le\n", (bxpdx - bx)/dx+(bypdy - by)/dy+(bzpdz - bz)/dz);
	printf("TEST 2 IF FIELD SATISFIES DivB = 0\n");
	printf("divB = %le\n", (bxpdx - bxmdx)/(2*dx) + (bypdy - bymdy)/(2*dy) + (bzpdz - bzmdz)/(2*dz));
	printf("TEST IF FIELD SATISFIES RotB = 0\n");
	printf("dBzdx - dBxdz = %le, while dBzdx = %le\n", (bzpdx - bz)/dx - (bxpdz - bx)/dz, (bzpdx - bz)/dx);
	printf("dBzdy - dBydz = %le, while dBzdy = %le\n", (bzpdy - bz)/dy - (bypdz - by)/dz, (bzpdy - bz)/dy);
	printf("dBxdy - dBydx = %le, while dBxdy = %le\n", (bxpdy - bx)/dy - (bypdx - by)/dx, (bxpdy - bx)/dy);
	printf("TEST 2 IF FIELD SATISFIES RotB = 0\n");
	printf("dBzdx - dBxdz = %le, while dBzdx = %le\n", (bzpdx - bzmdx)/(2*dx) - (bxpdz - bxmdz)/(2*dz), (bzpdx - bzmdx)/(2*dx));
	printf("dBzdy - dBydz = %le, while dBzdy = %le\n", (bzpdy - bzmdy)/(2*dy) - (bypdz - bymdz)/(2*dz), (bzpdy - bzmdy)/(2*dy));
	printf("dBxdy - dBydx = %le, while dBxdy = %le\n", (bxpdy - bxmdy)/(2*dy) - (bypdx - bymdx)/(2*dx), (bxpdy - bxmdy)/(2*dy));
}

extern int maxwell_test(double x, double y, double z, double dx, double dy, double dz, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int),
	double *divb, double *curlbx, double *curlby, double *curlbz, int doyouglob)//, double *dbzdx, double *dbxdz, double *dbzdy, double *dbydz, double *dbxdy, double *dbydx)
{
	double bx, by, bz, bxpdx, bxpdy, bxpdz, bypdy, bypdx, bypdz, bzpdz, bzpdx, bzpdy, dglob_to_loc_x, dglob_to_loc_y;
	double bxmdx, bxmdy, bxmdz, bymdy, bymdx, bymdz, bzmdz, bzmdx, bzmdy;
	double dbxdx,dbydy,dbzdz,dbzdx,dbxdz,dbzdy,dbydz,dbxdy,dbydx;
	
	if(get_bfield(x, y, z, &bx, &by, &bz, cell,add_contribution_comp)!=ALIVE) return FALSE;
	//printf("bx=%le, by=%le, bz=%le\n",bx, by, bz);
	dglob_to_loc_x = dx;
	dglob_to_loc_y = 0.;
	if(doyouglob==YES) fwk_vect_globtoloc(&dglob_to_loc_x, &dglob_to_loc_y, &(cell->framework));
	if(get_bfield(x+dglob_to_loc_x, y+dglob_to_loc_y, z, &bxpdx, &bypdx, &bzpdx, cell, add_contribution_comp)!=ALIVE) return FALSE;
	if(get_bfield(x-dglob_to_loc_x, y-dglob_to_loc_y, z, &bxmdx, &bymdx, &bzmdx, cell, add_contribution_comp)!=ALIVE) return FALSE;
	//printf("bxpdx=%le, bypdx=%le, bzpdx=%le\n",bxpdx, bypdx, bzpdx);
	dglob_to_loc_x = 0;
	dglob_to_loc_y = dy;
	if(doyouglob==YES) fwk_vect_globtoloc(&dglob_to_loc_x, &dglob_to_loc_y, &(cell->framework));
	if(get_bfield(x+dglob_to_loc_x, y+dglob_to_loc_y, z, &bxpdy, &bypdy, &bzpdy, cell, add_contribution_comp)!=ALIVE) return FALSE;
	if(get_bfield(x-dglob_to_loc_x, y-dglob_to_loc_y, z, &bxmdy, &bymdy, &bzmdy, cell, add_contribution_comp)!=ALIVE) return FALSE;
	//printf("bxpdy=%le, bypdy=%le, bzpdy=%le\n",bxpdy, bypdy, bzpdy);
	//printf("bxmdy=%le, bymdy=%le, bzmdy=%le\n",bxmdy, bymdy, bzmdy);
	if(get_bfield(x, y, z+dz, &bxpdz, &bypdz, &bzpdz, cell, add_contribution_comp)!=ALIVE) return FALSE;
	if(get_bfield(x, y, z-dz, &bxmdz, &bymdz, &bzmdz, cell, add_contribution_comp)!=ALIVE) return FALSE;
	//printf("bxpdz=%le, bypdz=%le, bzpdz=%le\n",bxpdz, bypdz, bzpdz);
	//printf("bxmdz=%le, bymdz=%le, bzmdz=%le\n",bxmdz, bymdz, bzmdz);
	
	//*divb = (bxpdx-bx)/dx + (bypdy-by)/dy + (bzpdz-bz)/dz;
	//*curlbx = (bzpdx - bz)/dx - (bxpdz - bx)/dz;
	//*curlby = (bzpdy - bz)/dy - (bypdz - by)/dz;
	//*curlbz = (bxpdy - bx)/dy - (bypdx - by)/dx;
	//dbxdx = (bxpdx-bx)/dx;
	//dbydy = (bypdy-by)/dy;
	//dbzdz = (bzpdz-bz)/dz;
	dbxdx = (bxpdx-bxmdx)/(2*dx); //second order cancelled
	dbydy = (bypdy-bymdy)/(2*dy);
	dbzdz = (bzpdz-bzmdz)/(2*dz);
	*divb = dbxdx + dbydy + dbzdz;
	//printf("%.9e + %.9e + %.9e = %.9e\n", dbxdx, dbydy, dbzdz, *divb);
	//dbzdx = (bzpdx - bz)/dx;
	//dbxdz = (bxpdz - bx)/dz;
	dbzdx = (bzpdx - bzmdx)/(2*dx);
	dbxdz = (bxpdz - bxmdz)/(2*dz);
	*curlbx = dbzdx - dbxdz;
	//printf("%.9e - %.9e = %.9e\n", dbzdx, dbxdz, *curlbx);
	//dbzdy = (bzpdy - bz)/dy;
	//dbydz = (bypdz - by)/dz;
	dbzdy = (bzpdy - bzmdy)/(2*dy);
	dbydz = (bypdz - bymdz)/(2*dz);
	*curlby = dbzdy - dbydz;
	//printf("%.9e - %.9e = %.9e\n", dbzdy, dbydz, *curlby);
	//dbxdy = (bxpdy - bx)/dy;
	//dbydx = (bypdx - by)/dx;
	dbxdy = (bxpdy - bxmdy)/(2*dy);
	dbydx = (bypdx - bymdx)/(2*dx);
	*curlbz = dbxdy - dbydx;
	//printf("%.9e - %.9e = %.9e\n", dbxdy, dbydx, *curlbz);
	return TRUE;
}

extern void maxwell_test_txtfile(char *textfile, double x, double y, double z, double dx, double dy, double dz, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int)) {
	double divb, curlbx, curlby, curlbz;//, dbzdx, dbxdz, dbzdy, dbydz, dbxdy, dbydx;
	double r, th;
	//double r=sqrt(x*x+y*y),th=atan_ratio(y, x);
	FILE *wfile;
	
	convert_cart_to_polar(x, y, &r, &th);
	wfile = fopen(textfile, "a");
	if(maxwell_test(x, y, z, dx, dy, dz, cell, add_contribution_comp, &divb, &curlbx, &curlby, &curlbz,NO)!=TRUE) {
		divb = 0;
		curlbx = 0;
		curlby = 0;
		curlbz = 0;
	}
	//, &dbzdx, &dbxdz, &dbzdy, &dbydz, &dbxdy, &dbydx);
	//fprintf(wfile, "%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",r,th,z, divb, curlbx, dbzdx, dbxdz, curlby, dbydz, dbzdy, curlbz, dbydx, dbxdy); 
	if(cell->boun.thmax != 0) fprintf(wfile, "%le\t%le\t%le\t%le\t%le\t%le\t%le\n",r,th,z, divb, curlbx, curlby, curlbz); 
	else fprintf(wfile, "%le\t%le\t%le\t%le\t%le\t%le\t%le\n",x,y,z, divb, curlbx, curlby, curlbz); 
	fclose(wfile);
}

extern double maxwell_test_max(double x, double y, double z, double dx, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int), int doyouglob) {
	double divb=0, curlbx=0, curlby=0, curlbz=0, outmax=0.0;
	
	if(maxwell_test(x, y, z, dx, dx, dx, cell, add_contribution_comp, &divb, &curlbx, &curlby, &curlbz, doyouglob)!=TRUE) {
		divb = 0;
		curlbx = 0;
		curlby = 0;
		curlbz = 0;
	}
	printf("div,curlx,y,z=(%le,%le,%le,%le)\n",divb, curlbx, curlby, curlbz);
	outmax = MAX(outmax,fabs(divb));
	outmax = MAX(outmax,fabs(curlbx));
	outmax = MAX(outmax,fabs(curlby));
	outmax = MAX(outmax,fabs(curlbz));
	
	return outmax;
}

extern double maxwell_test_across_cell_max(double r, double z, double dx, int th_step, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int)) {
	int i;
	//double divb, curlbx, curlby, curlbz;//, dbzdx, dbxdz, dbzdy, dbydz, dbxdy, dbydx;
	double th, stepth,x,y, test_max, outmax=0.0;
		
	stepth = cell->boun.thmax/th_step;
	
	for(i=0;i<th_step;i++) {
		th = i*stepth;
		x = r*cos(th);
		y = r*sin(th);
		test_max = maxwell_test_max(x, y, z, dx, cell, add_contribution_comp,NO);
		outmax = MAX(outmax,test_max);
	}
	return outmax;
}

extern void maxwell_test_heatmap(char *extension, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int),
	double r0, double rmax, int nbr, double th0, double thmax, int nbth, double z0, double zmax, int nbz, int doyoucirc, double dx, double dy, double dz, int doyouglob)
{
	char div_text[500], curlx_text[500], curly_text[500], curlz_text[500];
	int i,j,k;
	double x,y,z,r,th, rstep,thstep,zstep, w_coor, divb, curlbx,curlby,curlbz;
	FILE *file_div, *file_curlx, *file_curly, *file_curlz;
	sprintf(div_text, "%s_div.dat", extension);
	sprintf(curlx_text, "%s_curlx.dat", extension);
	sprintf(curly_text, "%s_curly.dat", extension);
	sprintf(curlz_text, "%s_curlz.dat", extension);
	file_div   = fopen(div_text, "w");
	file_curlx = fopen(curlx_text, "w");
	file_curly = fopen(curly_text, "w");
	file_curlz = fopen(curlz_text, "w");
	
	if(nbr <= 1 && nbz <= 1) errorstop("map not possible, only 1 dimension is scanned!");
	if(nbr != 1 && nbz != 1 && nbth != 1) errorstop("map not possible, 3 dimensions scanned");
	//if(nbth <= 1) errorstop("map not possible, longitudinal dimension not scanned");

	if(nbz!=1) zstep = comp_step(z0, zmax, nbz, NO);
	else zstep = 1;
	if(nbr!=1) rstep = comp_step(r0, rmax, nbr, NO);
	else rstep = 1;
	if(nbth!=1) thstep = comp_step(th0, thmax, nbth, NO);
	else thstep = 1;

	if(doyoucirc==YES) printf("rstep=%le[m], thstep=%le[deg], zstep=%le[m]\n",rstep,thstep*180./PI,zstep);
	else printf("xstep=%le[m], ystep=%le[m], zstep=%le[m]\n",rstep,thstep,zstep);

	for(j=0;j<nbr;j++) {
		r = r0 + j*rstep;
		//printf("r = %le\n", r);
		for(i=0;i<nbz;i++) {
			z = z0 + i*zstep;
			//printf("z=%le\n",z);
			for(k=0;k<nbth;k++) {
				th = th0 + k*thstep;
				//printf("th = %le\n",th*180./PI);
				//th = thmax - k*thstep;
				if(doyoucirc==YES) {
					x = r*cos(th);
					y = r*sin(th);
				}
				else {
					x = r;
					y = th;
				}
				//printf("(%le,%le,%le)\n", r,th*180/PI,z);
				if(maxwell_test(x, y, z, dx, dy, dz, cell, add_contribution_comp, &divb, &curlbx, &curlby, &curlbz, doyouglob)!=TRUE) errorstop("maxwell test not true!");
				//printf("div=%le, curl=(%le,%le,%le)\n\n\n",divb, curlbx,curlby,curlbz);
				if(nbz==1) w_coor = x;
				else {
					w_coor = z;
					if(doyoucirc==YES) y = th*180./PI;
				}
				//printf("(%lf, %lf, %lf)\n",x,y,z);
				fprintf(file_div,"%le\t%le\t%le\n", y, w_coor, divb);
				fprintf(file_curlx,"%le\t%le\t%le\n", y, w_coor, curlbx);
				fprintf(file_curly,"%le\t%le\t%le\n", y, w_coor, curlby);
				fprintf(file_curlz,"%le\t%le\t%le\n", y, w_coor, curlbz);
			}
			fprintf(file_div,"\n"); // to build file to plot easyplot3dmap
			fprintf(file_curlx,"\n"); // to build file to plot easyplot3dmap
			fprintf(file_curly,"\n"); // to build file to plot easyplot3dmap
			fprintf(file_curlz,"\n"); // to build file to plot easyplot3dmap
		}
	}
	fclose(file_div);
	fclose(file_curlx);
	fclose(file_curly);
	fclose(file_curlz);
}


