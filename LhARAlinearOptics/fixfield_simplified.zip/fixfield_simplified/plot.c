/*
 *  plot.c
 *  Fixfield
 *
 *  Copyright 2009 Kyoto University. All rights reserved.
 *
 */

#include "plot.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

extern FILE *gnuplot_start(void)
{
	//return popen("/Applications/gnuplot.app/gnuplot.command -persist","w");
	//return popen("/usr/local/bin/gnuplot -persist","w");
	//return popen("/opt/local/bin/gnuplot -persist","w");
	//return popen("gnuplot -persist","w");
	return popen("/opt/local/bin/gnuplot -persist","w");
}

extern void gnuplot_set(FILE *gp, char *xlabel, char *ylabel, char *y2label, char *cblabel, char *zlabel, char *xrange, char *yrange, char *y2range, char *zrange, char *setoption)
{
	fprintf(gp," set lmargin 15\n");
	//fprintf(gp,"set bmargin 5\n");
	fprintf(gp," set xlabel '%s' offset 0,-1 font 'Helvetica,25.' \n", xlabel);
	fprintf(gp," set ylabel '%s' offset -3,0 font 'Helvetica,25.'\n", ylabel);
	fprintf(gp," set zlabel '%s' offset -3,0 font 'Helvetica,25.'\n", zlabel);
	fprintf(gp," set tics font 'Helvetica,25.'\n");
	fprintf(gp, " set key font 'Helvetica,20.'\n");

	if(xlabel != NULL) fprintf(gp," set xlabel '%s' offset 0,-1 font 'Helvetica,25.' \n", xlabel);
	if(ylabel != NULL) fprintf(gp," set ylabel '%s' offset -5,0 font 'Helvetica,25.'\n", ylabel);
	if(cblabel != NULL) fprintf(gp," set cblabel '%s' offset 3,0 font 'Helvetica,25.'\n",cblabel);
	if(zlabel != NULL) fprintf(gp," set zlabel '%s' offset -3,0 font 'Helvetica,25.'\n", zlabel);
		if(y2label != NULL) {
		fprintf(gp," set y2label \"%s\" offset 3,0 font 'Helvetica,25.'\n", y2label);
		fprintf(gp," set ytics nomirror\n set mxtics 5\nset mytics 5\nset my2tics 5\n");
		fprintf(gp," set rmargin 15\n");
		//fprintf(gp," set tics offset 0.3,0 font 'Helvetica,25.'\n");
	}
	else {
		fprintf(gp," set mxtics 5\nset mytics 5\n");
		fprintf(gp," set rmargin 5\n");
	}
	if(xrange != NULL) fprintf(gp," set xrange %s \n", xrange);
	if(yrange != NULL) fprintf(gp," set yrange %s \n", yrange);
	if(zrange != NULL) fprintf(gp," set zrange %s \n", zrange);
	if(y2range != NULL) fprintf(gp," set y2range %s \n", y2range);
	if(setoption != NULL) fprintf(gp," set %s \n", setoption);
}

extern void gnuplot2d_plot(FILE *gp, char *txtfilename, char *xcolumn, char *ycolumn, char *with, char *title, int left, int start, int end)
{
	char result[500], s3[100];
	
	if(start==YES) sprintf(result, "plot '%s' using %s:%s with %s", txtfilename, xcolumn, ycolumn, with);
	else if(start==NO) sprintf(result, " '%s' using %s:%s with %s", txtfilename, xcolumn, ycolumn, with);
	else errorstop("start flag wrong!\n");
	if(title==NULL) sprintf(s3, " notitle");
	else sprintf(s3, " title '%s'", title);
	strcat(result, s3);
	//if(left==YES) strcat(result, " axis x1y1");
	//else if(left==NO) strcat(result, " axis x1y2");
	//else errorstop("left flag wrong!\n");
	if(left==NO) strcat(result, " axis x1y2");
	if(end==YES) strcat(result, "\n");
	else if(end==NO) strcat(result, ",");
	else errorstop("end flag wrong!\n");
	fprintf(gp,"%s", result);
}

extern void gnuplot_palette(FILE *gp, double dens_min, double dens_max)
{
	double scale = dens_max-dens_min;
	fprintf(gp,"set palette defined (%lf 'blue', %lf 'cyan', %lf 'green', %lf 'yellow', %lf 'red')\n", dens_min, dens_min+scale/4., dens_min+2.*scale/4., dens_min+3.*scale/4., dens_max);//,dens_max/3., dens_max/2.,dens_max);

	//fprintf(gp,"set palette defined (0 'white', 6 'yellow', 12 'orange', 18 'red')\n");//,dens_max/3., dens_max/2.,dens_max);
	//fprintf(gp,"set palette rgbformulae 33,13,10\n");
	//fprintf(gp,"set palette rgbformulae 22,13,-31\n");
//	if(dens_max>0) {
//		if(dens_min<0 && fabs(dens_min)>scale/100) {//
//			if(fabs(dens_min)<scale/5. || dens_max<scale/5.) {
//				fprintf(gp,"set palette defined (%le 'blue', 0 'white', %le 'red')\n", -scale, scale);
//				fprintf(gp, " set cbrange [%le:%le]\n", -scale, scale);
//				//printf("palette defined (%le 'blue', 0 'white', %le 'red')\n", -scale, scale);
//			}
//			else {
//				fprintf(gp,"set palette defined (%le 'blue', 0 'white', %le 'red')\n", dens_min, dens_max);
//				fprintf(gp, " set cbrange [%le:%le]\n", dens_min, dens_max);
//				//printf("palette defined (%le 'blue', 0 'white', %le 'red')\n", dens_min, dens_max);
//			}
//		}
//		else {
//			fprintf(gp,"set palette defined (0 'white', %le 'cyan', %le 'green', %le 'yellow', %le 'orange', %le 'red')\n", scale/5., scale*2/5., scale*3/5.,scale*4/5, scale);
//			fprintf(gp, " set cbrange [0:%le]\n", dens_max);
//			//printf("palette defined (0 'white', %le 'cyan', %le 'green', %le 'yellow', %le 'orange', %le 'red')\n", scale/5., scale*2/5., scale*3/5.,scale*4/5, scale);
//		}
//	}
//	else {
//		fprintf(gp,"set palette defined (%le 'red', %le 'orange', %le 'yellow', %le 'green', %le 'cyan', 0 'white')\n", scale, scale*4/5., scale*3/5.,scale*2/5, scale/5);
//		fprintf(gp, " set cbrange [%le:0]\n", dens_min);
//		//printf("palette defined (%le 'red', %le 'orange', %le 'yellow', %le 'green', %le 'cyan', 0 'white')\n", scale, scale*4/5., scale*3/5.,scale*2/5, scale/5);
//	}
	
	//fprintf(gp,"set palette defined (0 'white', %le 'blue', %le 'cyan', %le 'green', %le 'yellow', %le 'orange', %le 'red')\n", scale/6., scale*2/6., scale*3/6.,scale*4/6, scale*5/6, scale);
	//fprintf(gp,"set palette defined (0 'white', 5 'blue', %i 'cyan', %i 'green', %i 'yellow', %i 'orange', %i 'red')\n"
	//if(dens_max>100) fprintf(gp,"set palette defined (0 'white', 5 'blue', %i 'cyan', %i 'green', %i 'yellow', %i 'orange', %i 'red')\n", dens_max/5, dens_max*2/5, dens_max*3/5, dens_max*4/5, dens_max);
	//else if(dens_max>10) fprintf(gp,"set palette defined (0 'white', %i 'blue', %i 'cyan', %i 'green', %i 'yellow', %i 'orange', %i 'red')\n", (dens_max/25+1), dens_max/5, dens_max*2/5, dens_max*3/5, dens_max*4/5, dens_max);
	//else if(dens_max>5) fprintf(gp,"set palette defined (0 'white', 1 'blue', %le 'cyan', %le 'green', %le 'yellow', %le 'orange', %i 'red')\n", (double) (dens_max/5.0), (double) (dens_max*2.0/5.0), (double) (dens_max*3.0/5.0), (double) (dens_max*4.0/5.0), dens_max);
	//else fprintf(gp,"set palette defined (0 'white', 1 'blue', 2 'green', 3 'yellow', 4 'orange', 5 'red')\n");
	//if(dens_max>5) fprintf(gp, " set cbrange [0:%i]\n", dens_max);
	//else fprintf(gp, " set cbrange [0:5]\n");
	//fprintf(gp, " set cbrange [%le:%le]\n", dens_min, dens_max);
}

extern void gnuplot3d_plot(FILE *gp, char *txtfilename, char *xcolumn, char *ycolumn, char *zcolumn, char *with, char *title, int start, int end)
{
	char result[500], s3[100];
	
	if(start==YES) sprintf(result, "splot '%s' using %s:%s:%s with %s", txtfilename, xcolumn, ycolumn, zcolumn, with);
	else if(start==NO) sprintf(result, " '%s' using %s:%s:%s with %s", txtfilename, xcolumn, ycolumn, zcolumn, with);
	else errorstop("start flag wrong!\n");
	if(title==NULL) sprintf(s3, " notitle");
	else sprintf(s3, " title '%s'", title);
	strcat(result, s3);
	if(end==YES) strcat(result, "\n");
	else if(end==NO) strcat(result, ",");
	else errorstop("end flag wrong!\n");
	fprintf(gp,"%s", result);
}

extern void gnuplot_postscript(FILE *gp, char *psfilename)
{
	fprintf(gp," set terminal postscript eps enhanced color\nset output '%s.eps' \n", psfilename);
}

extern void gnuplot_terminal(FILE *gp)
{
	fprintf(gp," set terminal aqua\n");
	//fprintf(gp," set terminal x11\n");
}

extern void gnuplot_histo(FILE *gp, double xmin, double xmax, double nb_bin)
{
	fprintf(gp,"min = %lf\n", xmin);
	fprintf(gp,"max = %lf\n", xmax);
	fprintf(gp,"n = %lf\n", nb_bin);
	fprintf(gp,"width = (max-min)/n\n");
	fprintf(gp,"hist(x,width)=width*(floor((x-min)/width)+0.5) + min;");
	fprintf(gp,"set style fill solid 1.0\n");
	
}

extern void gnuplot_end(FILE *gp, char *psfilename)
{
	pclose(gp);
	if(psfilename != NULL) {
		char shell_write[500], name_eps[500];//, name_pdf[500];
		FILE *shell_read;
		sprintf(name_eps,"%s.eps", psfilename);
		//fix_boundingbox(name_eps, YES);
		sprintf(shell_write,"ps2pdf -dEPSCrop %s.eps %s.pdf", psfilename, psfilename);
		shell_read = popen(shell_write,"r");
		pclose(shell_read);
		remove(name_eps);
	}
}

extern void easyplot(char *txtfilename, char *xcolumn, char *ycolumn, char *with, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename, xcolumn, ycolumn, with, NULL, YES, YES, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename, xcolumn, ycolumn, with, NULL, YES, YES, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot2(char *txtfilename1, char *txtfilename2, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *with1, char *with2, char *title1, char *title2, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	if(title1==NULL && title2==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot3(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *with1, char *with2, char *with3, char *title1, char *title2, char *title3, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	if(title1==NULL && title2==NULL && title3==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, YES, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, YES, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot4(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *xcolumn4, char *ycolumn4, char *with1, char *with2, char *with3, char *with4, char *title1, char *title2, char *title3, char *title4, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	if(title1==NULL && title2==NULL && title3==NULL && title4==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename4, xcolumn4, ycolumn4, with4, title4, YES, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename4, xcolumn4, ycolumn4, with4, title4, YES, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot5(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *xcolumn4, char *ycolumn4, char *xcolumn5, char *ycolumn5, char *with1, char *with2, char *with3, char *with4, char *with5, char *title1, char *title2, char *title3, char *title4, char *title5, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	if(title1==NULL && title2==NULL && title3==NULL && title4==NULL && title5==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename4, xcolumn4, ycolumn4, with4, title4, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename5, xcolumn5, ycolumn5, with5, title5, YES, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename4, xcolumn4, ycolumn4, with4, title4, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename5, xcolumn5, ycolumn5, with5, title5, YES, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot6(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *txtfilename6, 
	char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *xcolumn4, char *ycolumn4, char *xcolumn5, char *ycolumn5, char *xcolumn6, char *ycolumn6, 
	char *with1, char *with2, char *with3, char *with4, char *with5, char *with6, 
	char *title1, char *title2, char *title3, char *title4, char *title5, char *title6, 
	char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	if(title1==NULL && title2==NULL && title3==NULL && title4==NULL && title5==NULL && title6==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename4, xcolumn4, ycolumn4, with4, title4, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename5, xcolumn5, ycolumn5, with5, title5, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename6, xcolumn6, ycolumn6, with6, title6, YES, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename4, xcolumn4, ycolumn4, with4, title4, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename5, xcolumn5, ycolumn5, with5, title5, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename6, xcolumn6, ycolumn6, with6, title6, YES, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot8(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *txtfilename6,  char *txtfilename7, char *txtfilename8,
	char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *xcolumn4, char *ycolumn4, char *xcolumn5, char *ycolumn5, char *xcolumn6, char *ycolumn6, char *xcolumn7, char *ycolumn7, char *xcolumn8, char *ycolumn8, 
	char *with1, char *with2, char *with3, char *with4, char *with5, char *with6,  char *with7, char *with8,
	char *title1, char *title2, char *title3, char *title4, char *title5, char *title6, char *title7, char *title8, 
	char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	if(title1==NULL && title2==NULL && title3==NULL && title4==NULL && title5==NULL && title6==NULL && title7==NULL && title8==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename4, xcolumn4, ycolumn4, with4, title4, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename5, xcolumn5, ycolumn5, with5, title5, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename6, xcolumn6, ycolumn6, with6, title6, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename7, xcolumn7, ycolumn7, with7, title7, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename8, xcolumn8, ycolumn8, with8, title8, YES, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename4, xcolumn4, ycolumn4, with4, title4, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename5, xcolumn5, ycolumn5, with5, title5, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename6, xcolumn6, ycolumn6, with6, title6, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename7, xcolumn7, ycolumn7, with7, title7, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename8, xcolumn8, ycolumn8, with8, title8, YES, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot11(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *txtfilename6,  char *txtfilename7, char *txtfilename8, char *txtfilename9, char *txtfilename10, char *txtfilename11,
	char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *xcolumn4, char *ycolumn4, char *xcolumn5, char *ycolumn5, char *xcolumn6, char *ycolumn6, char *xcolumn7, char *ycolumn7, char *xcolumn8, char *ycolumn8, char *xcolumn9, char *ycolumn9, char *xcolumn10, char *ycolumn10, char *xcolumn11, char *ycolumn11,
	char *with1, char *with2, char *with3, char *with4, char *with5, char *with6,  char *with7, char *with8, char *with9, char *with10, char *with11,
	char *title1, char *title2, char *title3, char *title4, char *title5, char *title6, char *title7, char *title8, char *title9, char *title10, char *title11,
	char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	if(title1==NULL && title2==NULL && title3==NULL && title4==NULL && title5==NULL && title6==NULL && title7==NULL && title8==NULL && title9==NULL && title10==NULL && title11==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename1,  xcolumn1,  ycolumn1,  with1,  title1,  YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2,  xcolumn2,  ycolumn2,  with2,  title2,  YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename3,  xcolumn3,  ycolumn3,  with3,  title3,  YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename4,  xcolumn4,  ycolumn4,  with4,  title4,  YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename5,  xcolumn5,  ycolumn5,  with5,  title5,  YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename6,  xcolumn6,  ycolumn6,  with6,  title6,  YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename7,  xcolumn7,  ycolumn7,  with7,  title7,  YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename8,  xcolumn8,  ycolumn8,  with8,  title8,  YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename9,  xcolumn9,  ycolumn9,  with9,  title9,  YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename10, xcolumn10, ycolumn10, with10, title10, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename11, xcolumn11, ycolumn11, with11, title11, YES, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename1,  xcolumn1,  ycolumn1,  with1,  title1,  YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2,  xcolumn2,  ycolumn2,  with2,  title2,  YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename3,  xcolumn3,  ycolumn3,  with3,  title3,  YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename4,  xcolumn4,  ycolumn4,  with4,  title4,  YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename5,  xcolumn5,  ycolumn5,  with5,  title5,  YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename6,  xcolumn6,  ycolumn6,  with6,  title6,  YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename7,  xcolumn7,  ycolumn7,  with7,  title7,  YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename8,  xcolumn8,  ycolumn8,  with8,  title8,  YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename9,  xcolumn9,  ycolumn9,  with9,  title9,  YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename10, xcolumn10, ycolumn10, with10, title10, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename11, xcolumn11, ycolumn11, with11, title11, YES, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot3dmap(char *txtfilename, char *xlabel, char *ylabel, char *cblabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_min, double dens_max)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, cblabel, NULL, xrange, yrange, NULL, NULL, setoption);
	fprintf(gp,"set pm3d map\n");
	gnuplot_palette(gp, dens_min, dens_max);
	fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		fprintf(gp,"splot '%s'\n", txtfilename);
	}
	gnuplot_terminal(gp);	
	fprintf(gp,"splot '%s'\n", txtfilename);
	gnuplot_end(gp, psfilename);
}

extern void easyplot3dmap_withlegend(char *txtfilename, char *xlabel, char *ylabel, char *cblabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_min, double dens_max, char *legend)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, cblabel, NULL, xrange, yrange, NULL, NULL, setoption);
	fprintf(gp,"set pm3d map\n");
	gnuplot_palette(gp, dens_min, dens_max);
	//fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		fprintf(gp,"splot '%s' title '%s'\n", txtfilename, legend);
	}
	gnuplot_terminal(gp);	
	fprintf(gp,"splot '%s' title '%s'\n", txtfilename, legend);
	gnuplot_end(gp, psfilename);
}

extern void easyplot3dmap_gen(char *txtfilename, char *xcolumn, char *ycolumn, char *ccolumn, char *xlabel, char *ylabel, char *cblabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_min, double dens_max)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, cblabel, NULL, xrange, yrange, NULL, NULL, setoption);
	fprintf(gp,"set pm3d map\n");
	gnuplot_palette(gp, dens_min, dens_max);
	fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		fprintf(gp,"splot '%s' using %s:%s:%s\n", txtfilename, xcolumn, ycolumn, ccolumn);
	}
	gnuplot_terminal(gp);	
	fprintf(gp,"splot '%s' using %s:%s:%s\n", txtfilename, xcolumn, ycolumn, ccolumn);
	gnuplot_end(gp, psfilename);
}

extern void easyplot3dmap_plusfile(char *txtfile_2d, char *xcolumn_2d, char *ycolumn_2d, char *with_2d, char *txtfilename, char *xlabel, char *ylabel, char *cblabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_min, double dens_max)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, cblabel, NULL, xrange, yrange, NULL, NULL, setoption);
	fprintf(gp,"set pm3d map\n");
	gnuplot_palette(gp, dens_min, dens_max);
	fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		fprintf(gp,"set parametric\n");
		gnuplot3d_plot(gp, txtfilename, "1", "2", "3", "pm3d", NULL, YES, NO);
		gnuplot3d_plot(gp, txtfile_2d, xcolumn_2d, ycolumn_2d, "(0.0)", with_2d, NULL, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot3d_plot(gp, txtfilename, "1", "2", "3", "pm3d", NULL, YES, NO);
	gnuplot3d_plot(gp, txtfile_2d, xcolumn_2d, ycolumn_2d, "(0.0)", with_2d, NULL, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot3dmap_plus2files(char *txtfile_2d, char *xcolumn_2d, char *ycolumn_2d, char *with_2d, char *txtfile_2d2, char *xcolumn_2d2, char *ycolumn_2d2, char *with_2d2, char *txtfilename, char *xlabel, char *ylabel, char *cblabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_min, double dens_max)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, cblabel, NULL, xrange, yrange, NULL, NULL, setoption);
	fprintf(gp,"set pm3d map\n");
	gnuplot_palette(gp, dens_min, dens_max);
	fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		fprintf(gp,"set parametric\n");
		gnuplot3d_plot(gp, txtfilename, "1", "2", "3", "pm3d", NULL, YES, NO);
		gnuplot3d_plot(gp, txtfile_2d, xcolumn_2d, ycolumn_2d, "(0.0)", with_2d, NULL, NO, NO);
		gnuplot3d_plot(gp, txtfile_2d2, xcolumn_2d2, ycolumn_2d2, "(0.0)", with_2d2, NULL, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot3d_plot(gp, txtfilename, "1", "2", "3", "pm3d", NULL, YES, NO);
	gnuplot3d_plot(gp, txtfile_2d, xcolumn_2d, ycolumn_2d, "(0.0)", with_2d, NULL, NO, NO);
	gnuplot3d_plot(gp, txtfile_2d2, xcolumn_2d2, ycolumn_2d2, "(0.0)", with_2d2, NULL, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot3d(char *txtfilename, char *xcolumn, char *ycolumn, char *zcolumn, char *with, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, zlabel, xrange, yrange, NULL, zrange, setoption);
	fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot3d_plot(gp, txtfilename, xcolumn, ycolumn, zcolumn, with, NULL, YES, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot3d_plot(gp, txtfilename, xcolumn, ycolumn, zcolumn, with, NULL, YES, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot2_3d(char *txtfilename1, char *txtfilename2, char *xcolumn1, char *ycolumn1, char *zcolumn1, char *xcolumn2, char *ycolumn2, char *zcolumn2, char *with1, char *with2, char *title1, char *title2, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, zlabel, xrange, yrange, NULL, zrange, setoption);
	if(title1==NULL && title2==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, title1, YES, NO);
		gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, title2, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, title1, YES, NO);
	gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, title2, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot3_3d(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *xcolumn1, char *ycolumn1, char *zcolumn1, char *xcolumn2, char *ycolumn2, char *zcolumn2, char *xcolumn3, char *ycolumn3, char *zcolumn3, 
	char *with1, char *with2, char *with3, char *title1, char *title2, char *title3, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, zlabel, xrange, yrange, NULL, zrange, setoption);
	if(title1==NULL && title2==NULL && title3==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, title1, YES, NO);
		gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, title2, NO, NO);
		gnuplot3d_plot(gp, txtfilename3, xcolumn3, ycolumn3, zcolumn3, with3, title3, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, title1, YES, NO);
	gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, title2, NO, NO);
	gnuplot3d_plot(gp, txtfilename3, xcolumn3, ycolumn3, zcolumn3, with3, title3, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot4_3d(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *xcolumn1, char *ycolumn1, char *zcolumn1, char *xcolumn2, char *ycolumn2, char *zcolumn2, char *xcolumn3, char *ycolumn3, char *zcolumn3, char *xcolumn4, char *ycolumn4, char *zcolumn4, 
	char *with1, char *with2, char *with3, char *with4, char *title1, char *title2, char *title3, char *title4, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, zlabel, xrange, yrange, NULL, zrange, setoption);
	if(title1==NULL && title2==NULL && title3==NULL && title4==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, title1, YES, NO);
		gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, title2, NO, NO);
		gnuplot3d_plot(gp, txtfilename3, xcolumn3, ycolumn3, zcolumn3, with3, title3, NO, NO);
		gnuplot3d_plot(gp, txtfilename4, xcolumn4, ycolumn4, zcolumn4, with4, title4, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, title1, YES, NO);
	gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, title2, NO, NO);
	gnuplot3d_plot(gp, txtfilename3, xcolumn3, ycolumn3, zcolumn3, with3, title3, NO, NO);
	gnuplot3d_plot(gp, txtfilename4, xcolumn4, ycolumn4, zcolumn4, with4, title4, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot5_3d(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *xcolumn1, char *ycolumn1, char *zcolumn1, char *xcolumn2, char *ycolumn2, char *zcolumn2, char *xcolumn3, char *ycolumn3, char *zcolumn3, char *xcolumn4, char *ycolumn4, char *zcolumn4, char *xcolumn5, char *ycolumn5, char *zcolumn5, 
	char *with1, char *with2, char *with3, char *with4, char *with5, char *title1, char *title2, char *title3, char *title4, char *title5, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, zlabel, xrange, yrange, NULL, zrange, setoption);
	if(title1==NULL && title2==NULL && title3==NULL && title4==NULL && title5==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, title1, YES, NO);
		gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, title2, NO, NO);
		gnuplot3d_plot(gp, txtfilename3, xcolumn3, ycolumn3, zcolumn3, with3, title3, NO, NO);
		gnuplot3d_plot(gp, txtfilename4, xcolumn4, ycolumn4, zcolumn4, with4, title4, NO, NO);
		gnuplot3d_plot(gp, txtfilename5, xcolumn5, ycolumn5, zcolumn5, with5, title5, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, title1, YES, NO);
	gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, title2, NO, NO);
	gnuplot3d_plot(gp, txtfilename3, xcolumn3, ycolumn3, zcolumn3, with3, title3, NO, NO);
	gnuplot3d_plot(gp, txtfilename4, xcolumn4, ycolumn4, zcolumn4, with4, title4, NO, NO);
	gnuplot3d_plot(gp, txtfilename5, xcolumn5, ycolumn5, zcolumn5, with5, title5, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot6_3d(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *txtfilename6, char *xcolumn1, char *ycolumn1, char *zcolumn1, char *xcolumn2, char *ycolumn2, char *zcolumn2, char *xcolumn3, char *ycolumn3, char *zcolumn3, char *xcolumn4, char *ycolumn4, char *zcolumn4, char *xcolumn5, char *ycolumn5, char *zcolumn5, char *xcolumn6, char *ycolumn6, char *zcolumn6, 
	char *with1, char *with2, char *with3, char *with4, char *with5, char *with6, char *title1, char *title2, char *title3, char *title4, char *title5, char *title6, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, zlabel, xrange, yrange, NULL, zrange, setoption);
	if(title1==NULL && title2==NULL && title3==NULL && title4==NULL && title5==NULL && title6==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, title1, YES, NO);
		gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, title2, NO, NO);
		gnuplot3d_plot(gp, txtfilename3, xcolumn3, ycolumn3, zcolumn3, with3, title3, NO, NO);
		gnuplot3d_plot(gp, txtfilename4, xcolumn4, ycolumn4, zcolumn4, with4, title4, NO, NO);
		gnuplot3d_plot(gp, txtfilename5, xcolumn5, ycolumn5, zcolumn5, with5, title5, NO, NO);
		gnuplot3d_plot(gp, txtfilename6, xcolumn6, ycolumn6, zcolumn6, with6, title6, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, title1, YES, NO);
	gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, title2, NO, NO);
	gnuplot3d_plot(gp, txtfilename3, xcolumn3, ycolumn3, zcolumn3, with3, title3, NO, NO);
	gnuplot3d_plot(gp, txtfilename4, xcolumn4, ycolumn4, zcolumn4, with4, title4, NO, NO);
	gnuplot3d_plot(gp, txtfilename5, xcolumn5, ycolumn5, zcolumn5, with5, title5, NO, NO);
	gnuplot3d_plot(gp, txtfilename6, xcolumn6, ycolumn6, zcolumn6, with6, title6, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot7_3d(double x0, double z0, char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *txtfilename5, char *txtfilename6, char *txtfilename7, char *xcolumn1, char *ycolumn1, char *zcolumn1, char *xcolumn2, char *ycolumn2, char *zcolumn2, char *xcolumn3, char *ycolumn3, char *zcolumn3, char *xcolumn4, char *ycolumn4, char *zcolumn4, char *xcolumn5, char *ycolumn5, char *zcolumn5, char *xcolumn6, char *ycolumn6, char *zcolumn6, char *xcolumn7, char *ycolumn7, char *zcolumn7, 
	char *with1, char *with2, char *with3, char *with4, char *with5, char *with6, char *with7, char *title1, char *title2, char *title3, char *title4, char *title5, char *title6, char *title7, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption)
{
	char x0_label[50], z0_label[50];
	sprintf(x0_label, "(%le)", x0);
	sprintf(z0_label, "(%le)", z0);
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, zlabel, xrange, yrange, NULL, zrange, setoption);
	if(title1==NULL && title2==NULL && title3==NULL && title4==NULL && title5==NULL && title6==NULL  && title7==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, title1, YES, NO);
		gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, z0_label, with1, NULL, NO, NO);
		gnuplot3d_plot(gp, txtfilename1, x0_label, ycolumn1, zcolumn1, with1, NULL, NO, NO);
		
		gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, title2, NO, NO);
		gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, z0_label, with2, NULL, NO, NO);
		gnuplot3d_plot(gp, txtfilename2, x0_label, ycolumn2, zcolumn2, with2, NULL, NO, NO);
		
		gnuplot3d_plot(gp, txtfilename3, xcolumn3, ycolumn3, zcolumn3, with3, title3, NO, NO);
		gnuplot3d_plot(gp, txtfilename3, xcolumn3, ycolumn3, z0_label, with3, NULL, NO, NO);
		gnuplot3d_plot(gp, txtfilename3, x0_label, ycolumn3, zcolumn3, with3, NULL, NO, NO);
		
		gnuplot3d_plot(gp, txtfilename4, xcolumn4, ycolumn4, zcolumn4, with4, title4, NO, NO);
		gnuplot3d_plot(gp, txtfilename4, xcolumn4, ycolumn4, z0_label, with4, NULL, NO, NO);
		gnuplot3d_plot(gp, txtfilename4, x0_label, ycolumn4, zcolumn4, with4, NULL, NO, NO);
		
		gnuplot3d_plot(gp, txtfilename5, xcolumn5, ycolumn5, zcolumn5, with5, title5, NO, NO);
		gnuplot3d_plot(gp, txtfilename5, xcolumn5, ycolumn5, z0_label, with5, NULL, NO, NO);
		gnuplot3d_plot(gp, txtfilename5, x0_label, ycolumn5, zcolumn5, with5, NULL, NO, NO);

		gnuplot3d_plot(gp, txtfilename6, xcolumn6, ycolumn6, zcolumn6, with6, title6, NO, NO);
		gnuplot3d_plot(gp, txtfilename6, xcolumn6, ycolumn6, z0_label, with6, NULL, NO, NO);
		gnuplot3d_plot(gp, txtfilename6, x0_label, ycolumn6, zcolumn6, with6, NULL, NO, NO);

		gnuplot3d_plot(gp, txtfilename7, xcolumn7, ycolumn7, zcolumn7, with7, title7, NO, NO);
		gnuplot3d_plot(gp, txtfilename7, xcolumn7, ycolumn7, z0_label, with7, NULL, NO, NO);
		gnuplot3d_plot(gp, txtfilename7, x0_label, ycolumn7, zcolumn7, with7, NULL, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, title1, YES, NO);
	gnuplot3d_plot(gp, txtfilename1, xcolumn1, ycolumn1, z0_label, with1, NULL, NO, NO);
	gnuplot3d_plot(gp, txtfilename1, x0_label, ycolumn1, zcolumn1, with1, NULL, NO, NO);
	
	gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, title2, NO, NO);
	gnuplot3d_plot(gp, txtfilename2, xcolumn2, ycolumn2, z0_label, with2, NULL, NO, NO);
	gnuplot3d_plot(gp, txtfilename2, x0_label, ycolumn2, zcolumn2, with2, NULL, NO, NO);
	
	gnuplot3d_plot(gp, txtfilename3, xcolumn3, ycolumn3, zcolumn3, with3, title3, NO, NO);
	gnuplot3d_plot(gp, txtfilename3, xcolumn3, ycolumn3, z0_label, with3, NULL, NO, NO);
	gnuplot3d_plot(gp, txtfilename3, x0_label, ycolumn3, zcolumn3, with3, NULL, NO, NO);
	
	gnuplot3d_plot(gp, txtfilename4, xcolumn4, ycolumn4, zcolumn4, with4, title4, NO, NO);
	gnuplot3d_plot(gp, txtfilename4, xcolumn4, ycolumn4, z0_label, with4, NULL, NO, NO);
	gnuplot3d_plot(gp, txtfilename4, x0_label, ycolumn4, zcolumn4, with4, NULL, NO, NO);
	
	gnuplot3d_plot(gp, txtfilename5, xcolumn5, ycolumn5, zcolumn5, with5, title5, NO, NO);
	gnuplot3d_plot(gp, txtfilename5, xcolumn5, ycolumn5, z0_label, with5, NULL, NO, NO);
	gnuplot3d_plot(gp, txtfilename5, x0_label, ycolumn5, zcolumn5, with5, NULL, NO, NO);

	gnuplot3d_plot(gp, txtfilename6, xcolumn6, ycolumn6, zcolumn6, with6, title6, NO, NO);
	gnuplot3d_plot(gp, txtfilename6, xcolumn6, ycolumn6, z0_label, with6, NULL, NO, NO);
	gnuplot3d_plot(gp, txtfilename6, x0_label, ycolumn6, zcolumn6, with6, NULL, NO, NO);

	gnuplot3d_plot(gp, txtfilename7, xcolumn7, ycolumn7, zcolumn7, with7, title7, NO, NO);
	gnuplot3d_plot(gp, txtfilename7, xcolumn7, ycolumn7, z0_label, with7, NULL, NO, NO);
	gnuplot3d_plot(gp, txtfilename7, x0_label, ycolumn7, zcolumn7, with7, NULL, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot2_left_right(char *txtfilename1, char *txtfilename2, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *with1, char *with2, char *xlabel, char *ylabel, char *y2label, char *xrange, char *yrange, char *y2range, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, y2label, NULL, NULL, xrange, yrange, y2range, NULL, setoption);
	//gnuplot_set(gp, xlabel, ylabel, y2label, cblabel, zlabel, xrange, yrange, y2range, zrange, setoption)
	fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		//gnuplot2d_plot(gp, txtfilename, xcolumn, ycolumn, with, title, left, start, end)
		gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, NULL, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, NULL, NO, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, NULL, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, NULL, NO, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot3_left_right(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *with1, char *with2, char *with3, char *title1, char *title2, char *title3, char *xlabel, char *ylabel, char *y2label, char *xrange, char *yrange, char *y2range, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	
	gnuplot_set(gp, xlabel, ylabel, y2label, NULL, NULL, xrange, yrange, y2range, NULL, setoption);
	//gnuplot_set(gp, xlabel, ylabel, y2label, cblabel, zlabel, xrange, yrange, y2range, zrange, setoption)
	//fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		//gnuplot2d_plot(gp, txtfilename, xcolumn, ycolumn, with, title, left, start, end)
		gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, NO, NO, NO);
		gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, NO, NO, NO);
	gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void easyplot4_left_right(char *txtfilename1, char *txtfilename2, char *txtfilename3, char *txtfilename4, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *xcolumn4, char *ycolumn4, char *with1, char *with2, char *with3, char *with4, char *title1, char *title2, char *title3, char *title4, char *xlabel, char *ylabel, char *y2label, char *xrange, char *yrange, char *y2range, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, y2label, NULL, NULL, xrange, yrange, y2range, NULL, setoption);
	//gnuplot_set(gp, xlabel, ylabel, y2label, cblabel, zlabel, xrange, yrange, y2range, zrange, setoption)
	fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		//gnuplot2d_plot(gp, txtfilename, xcolumn, ycolumn, with, title, left, start, end)
		gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, NO, NO, NO);
		gnuplot2d_plot(gp, txtfilename4, xcolumn4, ycolumn4, with4, title4, NO, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename1, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2, xcolumn2, ycolumn2, with2, title2, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename3, xcolumn3, ycolumn3, with3, title3, NO, NO, NO);
	gnuplot2d_plot(gp, txtfilename4, xcolumn4, ycolumn4, with4, title4, NO, NO, YES);
	gnuplot_end(gp, psfilename);
}

	// ************************************************************************************ //
	//							    "plot beta & disp functions								//
	// ************************************************************************************ //

extern void easyplot_beta_disp(char *txtfilename1, char *txtfilename3, char *txt_filename_efb, char *xcolumn1, char *ycolumn1, char *xcolumn2, char *ycolumn2, char *xcolumn3, char *ycolumn3, char *with1, char *with2, char *with3, char *xlabel, char *ylabel, char *y2label, char *xrange, char *yrange, char *y2range, char *psfilename, char *setoption, double efb_scale, int title)
{
	double bmin;
	FILE *gp;
	
	get_betamin_file(txtfilename1, &bmin);
	bmin = floor(bmin);
	printf("bmin = %lf\n", bmin);
	//gp=popen("/Applications/gnuplot.app/gnuplot.command -persist","w");
	//gp=popen("/usr/local/bin/gnuplot -persist","w");
	gp=popen("/opt/local/bin/gnuplot -persist","w");
	//gp=popen("gnuplot -persist","w");
	fprintf(gp,"set lmargin 15\n");
	fprintf(gp,"set bmargin 5\n");
	fprintf(gp,"set rmargin 15\n");
	if(xrange != NULL) fprintf(gp," set xrange %s \n", xrange);
	if(yrange != NULL) fprintf(gp," set yrange %s \n", yrange);
	if(y2range != NULL) fprintf(gp," set y2range %s \n", y2range);
	fprintf(gp," set xlabel \"%s\" offset 0,-1 font 'Helvetica,25.' \n", xlabel);
	fprintf(gp," set ylabel \"%s\" offset -3,0 font 'Helvetica,25.'\n", ylabel);
	fprintf(gp," set y2label \"%s\" offset 3,0 font 'Helvetica,25.'\n", y2label);
	fprintf(gp,"set ytics nomirror\n set mxtics 5\nset mytics 5\nset my2tics 5\n");
	if(setoption != NULL) fprintf(gp," set %s \n", setoption);
	fprintf(gp," set tics offset 0.3,0 font 'Helvetica,25.'\n"); 
	//fprintf(gp,"unset key\n");
	if(title == NO) fprintf(gp,"unset key\n");
	else if(title == TL) fprintf(gp, "set key top left\n");
	else if(title == BL) fprintf(gp, "set key bottom left\n");
	else if(title == BR) fprintf(gp, "set key bottom right\n");
	else if(title == TR) fprintf(gp, "set key top right\n");
	else if(title == CR) fprintf(gp, "set key center right\n");
	else if(title == CL) fprintf(gp, "set key center left\n");
	if(psfilename != NULL) {
		fprintf(gp," set terminal postscript eps enhanced color\n");
		fprintf(gp," set output '%s.eps' \n", psfilename);
		//fprintf(gp,"plot '%s' using %s:%s with %s axis x1y1, '%s' using %s:%s with %s axis x1y1, '%s' using %s:%s with %s axis x1y2\n", txtfilename1, xcolumn1, ycolumn1, with1, txtfilename1, xcolumn2, ycolumn2, with2, txtfilename3, xcolumn3, ycolumn3, with3);
		if(title==NO)fprintf(gp,"plot '%s' using 1:($2*%lf) with lines lt 1 lc 0 lw 1 axis x1y1, '%s' using %s:%s with %s axis x1y1, '%s' using %s:%s with %s axis x1y1, '%s' using %s:%s with %s axis x1y2\n", txt_filename_efb, efb_scale, txtfilename1, xcolumn1, ycolumn1, with1, txtfilename1, xcolumn2, ycolumn2, with2, txtfilename3, xcolumn3, ycolumn3, with3);
		//else fprintf(gp,"plot '%s' using 1:($2*%lf) with lines lt 1 lc 0 lw 1 axis x1y1 title '', '%s' using %s:%s with %s axis x1y1 title ' {/Symbol b}_x', '%s' using %s:%s with %s axis x1y1 title ' {/Symbol b}_z', '%s' using %s:%s with %s axis x1y2 title ' {/Symbol h}'\n", txt_filename_efb, efb_scale, txtfilename1, xcolumn1, ycolumn1, with1, txtfilename1, xcolumn2, ycolumn2, with2, txtfilename3, xcolumn3, ycolumn3, with3);
		else fprintf(gp,"plot '%s' using 1:($2*%lf+%lf) with lines lt 1 lc 0 lw 1 axis x1y1 title '', '%s' using %s:%s with %s axis x1y1 title ' {/Symbol b}_x', '%s' using %s:%s with %s axis x1y1 title ' {/Symbol b}_z', '%s' using %s:%s with %s axis x1y2 title ' {/Symbol h}_x'\n", txt_filename_efb, efb_scale, bmin, txtfilename1, xcolumn1, ycolumn1, with1, txtfilename1, xcolumn2, ycolumn2, with2, txtfilename3, xcolumn3, ycolumn3, with3);
		fprintf(gp," set terminal aqua\n");
		//fprintf(gp," set terminal x11\n");
	}
	fprintf(gp,"plot '%s' using 1:($2*%lf+%lf) with lines lt 1 lc 0 lw 1 axis x1y1, '%s' using %s:%s with %s axis x1y1, '%s' using %s:%s with %s axis x1y1, '%s' using %s:%s with %s axis x1y2\n", txt_filename_efb, efb_scale, bmin, txtfilename1, xcolumn1, ycolumn1, with1, txtfilename1, xcolumn2, ycolumn2, with2, txtfilename3, xcolumn3, ycolumn3, with3);
	//fprintf(gp,"plot '%s' using %s:%s with %s axis x1y1, '%s' using %s:%s with %s axis x1y1, '%s' using %s:%s with %s axis x1y2\n", txtfilename1, xcolumn1, ycolumn1, with1, txtfilename1, xcolumn2, ycolumn2, with2, txtfilename3, xcolumn3, ycolumn3, with3);
	//fprintf(gp,"plot 'data/efb_betafunc.dat' using ($1):($2*2) with lines lt 1 lc 0 lw 1 axis x1y1, '%s' using %s:%s with %s axis x1y1, '%s' using %s:%s with %s axis x1y1, '%s' using %s:%s with %s axis x1y2\n", txtfilename1, xcolumn1, ycolumn1, with1, txtfilename1, xcolumn2, ycolumn2, with2, txtfilename3, xcolumn3, ycolumn3, with3);
	gnuplot_end(gp, psfilename);
	//pclose(gp);
	//if(psfilename != NULL) fix_boundingbox(psfilename, YES);
}


extern void write_efb_txtfile(char *filename, struct Particle *reference, struct Lattice *latt)
{
	int i,j,m, flag_en, flag_ex, flag_spi=0, mmax=20;
	double efb_ymax, x, y, th_comp_en, th_comp_ex, th_comp_old, s_en, s_ex, spi_angle, newx, x_cell, y_cell, x_0, y_0;
	struct Particle test_part, test_part2;
	struct Lattice tempo_latt;
	FILE *wfile;
	wfile = fopen(filename, "a");
	
	copy_latt(&tempo_latt, latt);
	test_part = *reference;
	test_part.s = 0;
	efb_ymax = 1;
	
	for(i = 0; i < latt->nbcell; i++) {
		if(test_cell_map(&(latt->cell[i])) == YES ||
			strcmp(latt->cell[i].keyword, "drift") == 0 || strcmp(latt->cell[i].keyword, "rf-thingap") == 0 || strcmp(latt->cell[i].keyword, "collimator") == 0) continue;
		set_up_instru(&tempo_latt.cell[i], CUP, &tempo_latt.cell[i].boun.thmax, &tempo_latt.cell[i].boun.ymax);
		//tempo_latt.cell[i].instrutype = CUP;
		for(j = 0; j < latt->cell[i].nbcomp; j++) { 
			// flag_spi: 1=spiral, 3=straight tilted, 4=tilted sector, 5=tilted sector taylor, 6=rectangle vffa
			if(strcmp(latt->cell[i].keyword, "ffag-spi-lin") == 0 || 
				strcmp(latt->cell[i].keyword, "ffag-spi-he") == 0 ||
				strcmp(latt->cell[i].keyword, "ffag-spi-enge") == 0 ||
				strcmp(latt->cell[i].keyword, "ffag-spi-fullenge") == 0 ||
				strcmp(latt->cell[i].keyword, "polyn-spi-enge") == 0) flag_spi = 1; 
			else if(strcmp(latt->cell[i].keyword, "ffag-sti-lin") == 0 || 
				strcmp(latt->cell[i].keyword, "ffag-sti-he") == 0 ||
				strcmp(latt->cell[i].keyword, "ffag-sti-enge") == 0) flag_spi = 3;
			else if(strcmp(latt->cell[i].keyword, "vffa-rect-lin") == 0 || 
				strcmp(latt->cell[i].keyword, "vffa-rect-he") == 0 ||
				strcmp(latt->cell[i].keyword, "vffa-rect-enge") == 0 ||
				strcmp(latt->cell[i].keyword, "vffa-rect-enge-add") == 0 ||
				strcmp(latt->cell[i].keyword, "vffa-rect-atan") == 0) flag_spi = 6;
			if(flag_spi==5) spi_angle = latt->cell[i].mpara[j][2];
			else if(flag_spi==6) {
				convert_polar_to_cart(latt->cell[i].mpara[j][1], latt->cell[i].mpara[j][0], &x_0, &y_0);
				//x_0 = latt->cell[i].mpara[j][1]*cos(latt->cell[i].mpara[j][0]);
				//y_0 = latt->cell[i].mpara[j][1]*sin(latt->cell[i].mpara[j][0]);
				spi_angle = latt->cell[i].mpara[j][0] + latt->cell[i].mpara[j][5];
			}
			else if(flag_spi>0) spi_angle = latt->cell[i].mpara[j][4];
			else spi_angle = 0.;
			if(latt->cell[i].boun.thmax!=0) {
				//track particle to the pole to get s:
				if(flag_spi < 2) th_comp_en = latt->cell[i].mpara[j][0] + latt->cell[i].efben[j][0] + tan(spi_angle)*log(test_part.x/latt->cell[i].mpara[j][1]); //spiral angle
				else if(flag_spi == 6) th_comp_en = latt->cell[i].mpara[j][0] + atan_ratio(latt->cell[i].efben[j][0]*cos(latt->cell[i].mpara[j][5]),latt->cell[i].mpara[j][1]);
				else errorstop("flag_spi not 0, 1 or 6\n");
				//else th_comp_en = latt->cell[i].mpara[j][0] + latt->cell[i].efben[j][0] - asin(latt->cell[i].mpara[j][1]*sin(spi_angle)/test_part.x) + spi_angle; //tilted sector
				for(m=0;m<mmax;m++) {
					th_comp_old = th_comp_en;
					test_part2 = test_part;
					tempo_latt.cell[i].instru[0].thmax = th_comp_en;
					part_cross_cell(&test_part2, &(tempo_latt.cell[i]),NULL,NULL);
					if(flag_spi < 2) th_comp_en = latt->cell[i].mpara[j][0] + latt->cell[i].efben[j][0] + tan(spi_angle)*log(test_part2.x/latt->cell[i].mpara[j][1]);
					else if(flag_spi == 6) {
						newx = (test_part2.y-y_0)*sin(spi_angle) + (test_part2.x-x_0)*cos(spi_angle);
						y_cell = y_0 + latt->cell[i].efben[j][0]*cos(spi_angle) + newx*sin(spi_angle);
						x_cell = x_0 - latt->cell[i].efben[j][0]*sin(spi_angle) + newx*cos(spi_angle);
						th_comp_en = atan_ratio(y_cell, x_cell);
					}
					else th_comp_en = latt->cell[i].mpara[j][0] + latt->cell[i].efben[j][0] - asin(latt->cell[i].mpara[j][1]*sin(spi_angle)/test_part2.x) + spi_angle;
					if(fabs(th_comp_en-th_comp_old)<1.e-4) break;
					if(m==mmax-1) errorstop("in write_efb_txtfile, th_comp_en not found");
				}
				if(th_comp_en>0 && th_comp_en<latt->cell[i].boun.thmax) {
					flag_en = 1;
					s_en = test_part2.s;
				}
				else {
					flag_en = 0;
					s_en = test_part.s;
				}
				if(flag_spi < 2) th_comp_ex = latt->cell[i].mpara[j][0] + latt->cell[i].efbex[j][0] + tan(spi_angle)*log(test_part.x/latt->cell[i].mpara[j][1]);
				else if(flag_spi == 6) th_comp_en = latt->cell[i].mpara[j][0] + atan_ratio(latt->cell[i].efbex[j][0]*cos(latt->cell[i].mpara[j][5]),latt->cell[i].mpara[j][1]);
				else th_comp_ex = latt->cell[i].mpara[j][0] + latt->cell[i].efbex[j][0] - asin(latt->cell[i].mpara[j][1]*sin(spi_angle)/test_part.x) + spi_angle;
				for(m=0;m<mmax;m++) {
					th_comp_old = th_comp_ex;
					test_part2 = test_part; 
					tempo_latt.cell[i].instru[0].thmax = th_comp_ex;
					part_cross_cell(&test_part2, &(tempo_latt.cell[i]),NULL,NULL);
					if(flag_spi < 2) th_comp_ex = latt->cell[i].mpara[j][0] + latt->cell[i].efbex[j][0] + tan(spi_angle)*log(test_part2.x/latt->cell[i].mpara[j][1]);
					else if(flag_spi == 6) {
						newx = (test_part2.y-y_0)*sin(spi_angle) + (test_part2.x-x_0)*cos(spi_angle);
						y_cell = y_0 + latt->cell[i].efbex[j][0]*cos(spi_angle) + newx*sin(spi_angle);
						x_cell = x_0 - latt->cell[i].efbex[j][0]*sin(spi_angle) + newx*cos(spi_angle);
						th_comp_ex = atan_ratio(y_cell, x_cell);
					}
					else th_comp_ex = latt->cell[i].mpara[j][0] + latt->cell[i].efbex[j][0] - asin(latt->cell[i].mpara[j][1]*sin(spi_angle)/test_part2.x) + spi_angle;
					if(fabs(th_comp_ex-th_comp_old)<1.e-4) break;
					if(m==mmax-1) errorstop("in write_efb_txtfile, th_comp_ex not found");
				}
				s_ex = test_part2.s;
				if(th_comp_ex>0 && th_comp_ex<latt->cell[i].boun.thmax) flag_ex = 1;
				else flag_ex = 0;
			}
			else if(latt->cell[i].boun.ymax!=0) {
				th_comp_en = latt->cell[i].mpara[j][0] + latt->cell[i].efben[j][0] + tan(spi_angle)*(test_part.x-latt->cell[i].mpara[j][1]);
				for(m=0;m<mmax;m++) {
					th_comp_old = th_comp_en;
					test_part2 = test_part;
					tempo_latt.cell[i].instru[0].ymax = th_comp_en;
					part_cross_cell(&test_part2, &(tempo_latt.cell[i]),NULL,NULL);
					th_comp_en = latt->cell[i].mpara[j][0] + latt->cell[i].efben[j][0] + tan(spi_angle)*(test_part.x-latt->cell[i].mpara[j][1]);
					if(fabs(th_comp_en-th_comp_old)<1.e-4) break;
					if(m==mmax-1) errorstop("in write_efb_txtfile, y_comp_en not found");
				}
				if(th_comp_en>0 && th_comp_en<latt->cell[i].boun.ymax) {
					flag_en = 1;
					s_en = test_part2.s;
				}
				else {
					flag_en = 0;
					s_en = test_part.s;
				}
				th_comp_ex = latt->cell[i].mpara[j][0] + latt->cell[i].efbex[j][0] + tan(spi_angle)*(test_part.x-latt->cell[i].mpara[j][1]);
				for(m=0;m<mmax;m++) {
					th_comp_old = th_comp_ex;
					test_part2 = test_part; 
					tempo_latt.cell[i].instru[0].ymax = th_comp_ex;
					part_cross_cell(&test_part2, &(tempo_latt.cell[i]),NULL,NULL);
					th_comp_ex = latt->cell[i].mpara[j][0] + latt->cell[i].efbex[j][0] + tan(spi_angle)*(test_part.x-latt->cell[i].mpara[j][1]);
					if(fabs(th_comp_ex-th_comp_old)<1.e-4) break;
					if(m==mmax-1) errorstop("in write_efb_txtfile, y_comp_ex not found");
				}
				s_ex = test_part2.s;
				if(th_comp_ex>0 && th_comp_ex<latt->cell[i].boun.ymax) flag_ex = 1;
				else flag_ex = 0;
			}
			//printf("thcomp_en,ex = %lf, %lf, flag %i %i\n", th_comp_en, th_comp_ex, flag_en, flag_ex);
			
			if(flag_en+flag_ex>0) {
				x = s_en;
				y = 0;
				fprintf(wfile, "%le  %le\n",x,y);
				y = efb_ymax;
				fprintf(wfile, "%le  %le\n",x,y);
				x = s_ex;
				fprintf(wfile, "%le  %le\n",x,y);
				y = 0;
				fprintf(wfile, "%le  %le\n",x,y);
				x = s_en;
				fprintf(wfile, "%le  %le\n",x,y);
				fprintf(wfile, "\n");
			}
		}
		if(latt->cell[i].boun.thmax!=0) tempo_latt.cell[i].instru[0].thmax = latt->cell[i].boun.thmax;
		else if(latt->cell[i].boun.ymax!=0) tempo_latt.cell[i].instru[0].ymax = latt->cell[i].boun.ymax;
		else errorstop("strange in write_efb_txtfile");
		test_part = *reference;
		part_cross_latt(&test_part, &tempo_latt, NULL, NULL); //calculate s0
		tempo_latt.cell[i].instrutype = NO;
	}
	fclose(wfile);
	free(tempo_latt.cell);
}

// Plot Twiss parameter gamma from beta file (needs to generate first).
extern void plot_twiss_gamma(char *filename, char *with1, char *with2, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	easyplot2(filename, filename, "1", "((1+$3**2)/$2)", "1", "((1+$5**2)/$4)", with1, with2, "{/Symbol g}_x", "{/Symbol g}_z", xlabel, ylabel, xrange, yrange, psfilename, setoption);
	
	
	//FILE *gp;
	//
	////gp=popen("/usr/local/bin/gnuplot -persist","w");
	//gp=popen("/opt/local/bin/gnuplot -persist","w");
	////gp=popen("gnuplot -persist","w");
	//fprintf(gp," set tics font 'Helvetica,30.'\n");
	//fprintf(gp,"set bmargin 5\n");
	//fprintf(gp,"set rmargin 12\n");
	//if(xrange != NULL) fprintf(gp," set xrange %s \n", xrange);
	//if(yrange != NULL) fprintf(gp," set yrange %s \n", yrange);
	//fprintf(gp," set xlabel '%s' offset 0,-1 font 'Helvetica,30.' \n", xlabel);
	//fprintf(gp," set ylabel '%s' offset -3,0 font 'Helvetica,30.'\n", ylabel);
	//fprintf(gp,"set mxtics 5\nset mytics 5\n");
	//if(xrange != NULL) fprintf(gp," set xrange %s \n", xrange);
	//if(yrange != NULL) fprintf(gp," set yrange %s \n", yrange);
	//if(setoption != NULL) fprintf(gp," set %s \n", setoption);
	//fprintf(gp,"unset key\n");
	//if(psfilename != NULL) {
	//	fprintf(gp," set terminal postscript eps enhanced color \n");
	//	fprintf(gp," set output '%s.eps' \n", psfilename);
	//	fprintf(gp,"plot '%s' using 1:((1+$3**2)/$2) with %s, '%s' using 1:((1+$5**2)/$4) with %s\n", filename, with1, filename, with2);
	//	fprintf(gp," set terminal aqua\n");
	//	//fprintf(gp," set terminal x11\n");
	//}
	//fprintf(gp,"plot '%s' using 1:(1/$2*(1+$3**2)) with %s, '%s' using 1:(1/$4*(1+$5**2)) with %s\n", filename, with1, filename, with2);
	//gnuplot_end(gp, psfilename);
	////pclose(gp);
	////if(psfilename != NULL) fix_boundingbox(psfilename, YES);
}

// Plot Twiss parameter gamma from beta file (needs to generate first).
extern void plot_twiss_gamma_w_efb(char *filename, char *file_efb, double efb_scale, char *with1, char *with2, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp;
	
	//gp=popen("/usr/local/bin/gnuplot -persist","w");
	gp=popen("/opt/local/bin/gnuplot -persist","w");
	//gp=popen("gnuplot -persist","w");
	fprintf(gp," set tics font 'Helvetica,30.'\n");
	fprintf(gp,"set bmargin 5\n");
	fprintf(gp,"set rmargin 12\n");
	if(xrange != NULL) fprintf(gp," set xrange %s \n", xrange);
	if(yrange != NULL) fprintf(gp," set yrange %s \n", yrange);
	fprintf(gp," set xlabel '%s' offset 0,-1 font 'Helvetica,30.' \n", xlabel);
	fprintf(gp," set ylabel '%s' offset -3,0 font 'Helvetica,30.'\n", ylabel);
	fprintf(gp,"set mxtics 5\nset mytics 5\n");
	if(xrange != NULL) fprintf(gp," set xrange %s \n", xrange);
	if(yrange != NULL) fprintf(gp," set yrange %s \n", yrange);
	if(setoption != NULL) fprintf(gp," set %s \n", setoption);
	fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		fprintf(gp," set terminal postscript eps enhanced color \n");
		fprintf(gp," set output '%s.eps' \n", psfilename);
		fprintf(gp,"plot '%s' using 1:(1/$2*(1+$3**2)) with %s, '%s' using 1:(1/$4*(1+$5**2)) with %s, '%s' using 1:($2*%lf) with lines lt 1 lc 0 lw 1\n", filename, with1, filename, with2, file_efb, efb_scale);
		fprintf(gp," set terminal aqua\n");
		//fprintf(gp," set terminal x11\n");
	}
	fprintf(gp,"plot '%s' using 1:(1/$2*(1+$3**2)) with %s, '%s' using 1:(1/$4*(1+$5**2)) with %s, '%s' using 1:($2*%lf) with lines lt 1 lc 0 lw 1\n", filename, with1, filename, with2, file_efb, efb_scale);
	//fprintf(gp,"plot '%s' using 1:(1/$2*(1+$3**2)) with %s, '%s' using 1:(1/$4*(1+$5**2)) with %s\n", filename, with1, filename, with2);
	gnuplot_end(gp, psfilename);
	//pclose(gp);
	//if(psfilename != NULL) fix_boundingbox(psfilename, YES);
}

	// ************************************************************************************ //
	//							     "plot histogram" functions								//
	// ************************************************************************************ //

extern void plot_one_histogram(char *txtfilename, double xmin, double xmax, double nb_bin, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	gnuplot_histo(gp, xmin, xmax, nb_bin);
	fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'red'", NULL, YES, YES, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'red'", NULL, YES, YES, YES);
	gnuplot_end(gp, psfilename);
}

extern void plot_two_histogram(char *txtfilename, char *title1, char *txtfilename2, char *title2, double xmin, double xmax, double nb_bin, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	gnuplot_histo(gp, xmin, xmax, nb_bin);
	if(title1 == NULL && title2 == NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'blue''", title1, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'red'", title2, YES, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'blue''", title1, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'red'", title2, YES, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void plot_three_histogram(char *txtfilename, char *title1, char *txtfilename2, char *title2, char *txtfilename3, char *title3, double xmin, double xmax, double nb_bin, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	gnuplot_histo(gp, xmin, xmax, nb_bin);
	if(title1 == NULL && title2 == NULL && title3 == NULL) fprintf(gp,"unset key\n");
	//fprintf(gp,"set offset graph 0.05,0.05,0.05,0.0\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'blue''", title1, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'red'", title2, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename3, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'forest-green'", title3, YES, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'blue''", title1, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'red'", title2, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename3, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'forest-green'", title3, YES, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void plot_four_histogram(char *txtfilename, char *title1, char *txtfilename2, char *title2, char *txtfilename3, char *title3, char *txtfilename4, char *title4, double xmin, double xmax, double nb_bin, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	gnuplot_histo(gp, xmin, xmax, nb_bin);
	if(title1 == NULL && title2 == NULL && title3 == NULL && title4 == NULL) fprintf(gp,"unset key\n");
	//fprintf(gp,"set offset graph 0.05,0.05,0.05,0.0\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'blue''", title1, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'red'", title2, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename3, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'forest-green'", title3, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename4, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'orange'", title4, YES, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'blue''", title1, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'red'", title2, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename3, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'forest-green'", title3, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename4, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'orange'", title4, YES, NO, YES);
	gnuplot_end(gp, psfilename);
}

extern void plot_five_histogram(char *txtfilename, char *title1, char *txtfilename2, char *title2, char *txtfilename3, char *title3, char *txtfilename4, char *title4, char *txtfilename5, char *title5, double xmin, double xmax, double nb_bin, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	gnuplot_histo(gp, xmin, xmax, nb_bin);
	if(title1 == NULL && title2 == NULL && title3 == NULL && title4 == NULL && title5 == NULL) fprintf(gp,"unset key\n");
	//fprintf(gp,"set offset graph 0.05,0.05,0.05,0.0\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot2d_plot(gp, txtfilename, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'blue''", title1, YES, YES, NO);
		gnuplot2d_plot(gp, txtfilename2, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'red'", title2, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename3, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'forest-green'", title3, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename4, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'orange'", title4, YES, NO, NO);
		gnuplot2d_plot(gp, txtfilename5, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'magenta'", title5, YES, NO, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'blue''", title1, YES, YES, NO);
	gnuplot2d_plot(gp, txtfilename2, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'red'", title2, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename3, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'forest-green'", title3, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename4, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'orange'", title4, YES, NO, NO);
	gnuplot2d_plot(gp, txtfilename5, "(hist($1,width))", "(1.0) smooth freq", "boxes lc rgb 'magenta'", title5, YES, NO, YES);
	gnuplot_end(gp, psfilename);

}

	// ************************************************************************************ //
	//							    "plot trajectory" functions								//
	// ************************************************************************************ //

extern void plot_traj(struct Lattice *latt, char *trackout, char *aspectfile, char *xcolumn_out, char *ycolumn_out, char *xcolumn_asp, char *ycolumn_asp, char *with_out, char *with_asp, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	aspectview(aspectfile, latt);
	easyplot2(trackout, aspectfile, xcolumn_out, ycolumn_out, xcolumn_asp, ycolumn_asp, with_out, with_asp, NULL, NULL, xlabel, ylabel, xrange,yrange, psfilename, setoption);
	//aspect_fringe_view("data/aspect_en.dat", "data/aspect_ex.dat", latt);
	//easyplot4(trackout, aspectfile, "data/aspect_en.dat", "data/aspect_ex.dat", xcolumn_out, ycolumn_out, xcolumn_asp, ycolumn_asp, "2", "1", "2", "1", with_out, with_asp, "lines dt 2 lc 2 lw 2", "lines dt 2 lc 3 lw 2", NULL, NULL, NULL, NULL, xlabel, ylabel, xrange,yrange, psfilename, setoption);
}

extern void auto_plot_traj(struct Lattice *latt, char *trackout, char *aspectfile, char *psfilename, char *setoption)
{
	char xrange[100], yrange[100], xcol[30], ycol[30];
	
	aspectview(aspectfile, latt);
	int xcol_nb = para_clm_trackout("y");
	int ycol_nb = para_clm_trackout("x");
	sprintf(xcol, "%i", xcol_nb);
	sprintf(ycol, "%i", ycol_nb);
	find_range_column_2files(xrange, trackout, xcol_nb, NB_CLMS_TRACKOUT, aspectfile, 2, 2, YES, NO);
	find_range_column_2files(yrange, trackout, ycol_nb, NB_CLMS_TRACKOUT, aspectfile, 1, 2, YES, NO);
	easyplot2(trackout, aspectfile, xcol, ycol, "2", "1", "lines lc 7 lw 2", "lines lt 1 lc 0 lw 2", NULL, NULL, "y [m]", "x [m]", xrange, yrange, psfilename, setoption);
	
	//plot_traj(latt, trackout, aspectfile, xcol, ycol, "2", "1", "lines lc 7 lw 2", "lines lt 1 lc 0 lw 2", "y [m]", "x [m]", xrange, yrange, psfilename, setoption);
}

//to be revamped!!
extern void plot_traj_3d(char *trackout1, char *trackout2, char *trackout3, struct Lattice *latt, double xmin, double zmin, char *title1, char *title2, char *title3, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption)
{
	int i, lc_tck1=7, lc_tck2=7, lc_tck3=7;
	FILE *gp;
	
	for(i=0;i<latt->nbcell;i++) aspect_rect_vffa3d("data/aspect3d.dat", &(latt->cell[i]), NO);
	
	gp=popen("gnuplot -persist","w");
	fprintf(gp," set tics font 'helvetica,25.'\n");
	fprintf(gp,"set lmargin 15\n");
	fprintf(gp,"set bmargin 25\n");
	fprintf(gp,"set rmargin 5\n");
	fprintf(gp," set xtics offset -0.5,-1\n");
	fprintf(gp," set ytics offset 2,-0.5\n");
	fprintf(gp," set xlabel '%s' offset 0,-2 font 'helvetica,25.' \n", xlabel);
	fprintf(gp," set ylabel '%s' offset 6,0 font 'helvetica,25.'\n", ylabel);
	fprintf(gp," set zlabel '%s' offset -6,0 font 'helvetica,25.'\n", zlabel);
	if(xrange != NULL) fprintf(gp," set xrange %s \n", xrange);
	if(yrange != NULL) fprintf(gp," set yrange %s \n", yrange);
	if(zrange != NULL) fprintf(gp," set zrange %s \n", zrange);
	if(title1==NULL && title2==NULL && title3==NULL) fprintf(gp,"unset key\n");
	
	//fprintf(gp, "set dgrid3d 50,50\n");
	//fprintf(gp, "set hidden3d\n");
	//fprintf(gp, "set view 60, 60\n");
	if(setoption != NULL) fprintf(gp," set %s \n", setoption);
	//fprintf(gp," set terminal postscript color\n");
	fprintf(gp," set terminal postscript eps enhanced color \n");
	fprintf(gp," set output '%s' \n", psfilename);
	if(title1==NULL) fprintf(gp,"splot '%s' using 2:3:4 with lines lc %i lw 3 notitle, ", trackout1, lc_tck1);
	else fprintf(gp,"splot '%s' using 2:3:4 with lines lc %i lw 3 title '%s', ", trackout1, lc_tck1, title1);
	if(title2==NULL) fprintf(gp,"'%s' using 2:3:4 with lines lc %i lw 3 notitle, ", trackout2, lc_tck2);
	else fprintf(gp,"'%s' using 2:3:4 with lines lc %i lw 3 title '%s', ", trackout2, lc_tck2, title2);
	if(title3==NULL) fprintf(gp,"'%s' using 2:3:4 with lines lc %i lw 3 notitle, ", trackout3, lc_tck3);
	else fprintf(gp,"'%s' using 2:3:4 with lines lc %i lw 3 title '%s', ", trackout3, lc_tck3, title3);
	fprintf(gp,"'data/aspect3d.dat' using 1:2:3 with lines lt 1 lc 0 lw 1.5 notitle, ");
	fprintf(gp,"'data/aspect3d.dat' using (%lf):2:3 with lines lt 1 lc 0 lw 0.5 dt 2 notitle, ", xmin);
	fprintf(gp,"'data/aspect3d.dat' using 1:2:(%lf) with lines lt 1 lc 0 lw 0.5 dt 2 notitle, ", zmin);
	
	fprintf(gp,"'%s' using (%lf):3:4 with lines lc %i lw 1 dt 2  notitle, ", trackout1, xmin, lc_tck1);
	fprintf(gp,"'%s' using 2:3:(%lf) with lines lc %i lw 1 dt 2  notitle, ", trackout1, zmin, lc_tck1);
	
	fprintf(gp,"'%s' using (%lf):3:4 with lines lc %i lw 1 dt 2  notitle, ", trackout2, xmin, lc_tck2);
	fprintf(gp,"'%s' using 2:3:(%lf) with lines lc %i lw 1 dt 2  notitle, ", trackout2, zmin, lc_tck2);
	
	fprintf(gp,"'%s' using (%lf):3:4 with lines lc %i lw 1 dt 2  notitle, ", trackout3, xmin, lc_tck3);
	fprintf(gp,"'%s' using 2:3:(%lf) with lines lc %i lw 1 dt 2  notitle\n", trackout3, zmin, lc_tck3);
	
	//fprintf(gp," set output\n");
	//fprintf(gp," set terminal x11\n");
	//fprintf(gp,"splot '%s' using %s:%s:%s with %s, '%s' using %s:%s:%s with %s, '%s' using %s:%s:%s with %s, '%s' using %s:%s:%s with %s, '%s' using %s:%s:%s with %s, '%s' using %s:%s:%s with %s\n", 
	//txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, txtfilename3, xcolumn3, ycolumn3, zcolumn3, with3, txtfilename4, xcolumn4, ycolumn4, zcolumn4, with4, txtfilename5, xcolumn5, ycolumn5, zcolumn5, with5,  txtfilename6, xcolumn6, ycolumn6, zcolumn6, with6);
	
	pclose(gp);
	//if(psfilename != NULL) fix_boundingbox(psfilename, YES);
}

//to be revamped!!
extern void plot_traj_3d_5mom(char *trackout1, char *trackout2, char *trackout3, char *trackout4, char *trackout5, struct Lattice *latt, double xmin, double zmin, 
	char *title1, char *title2, char *title3, char *title4, char *title5, char *xlabel, char *ylabel, char *zlabel, char *xrange, char *yrange, char *zrange, char *psfilename, char *setoption)
{
	int i, lc_tck1=7, lc_tck2=7, lc_tck3=7, lc_tck4=7, lc_tck5=7;
	FILE *gp;
	
	emptyfile("data/aspect3d.dat");
	for(i=0;i<latt->nbcell;i++) aspect_rect_vffa3d("data/aspect3d.dat", &(latt->cell[i]), NO);
	
	gp=popen("gnuplot -persist","w");
	fprintf(gp," set tics font 'helvetica,25.'\n");
	fprintf(gp,"set lmargin 15\n");
	fprintf(gp,"set bmargin 25\n");
	fprintf(gp,"set rmargin 5\n");
	fprintf(gp," set xtics offset -0.5,-1\n");
	fprintf(gp," set ytics offset 2,-0.5\n");
	fprintf(gp," set xlabel '%s' offset 0,-2 font 'helvetica,25.' \n", xlabel);
	fprintf(gp," set ylabel '%s' offset 6,0 font 'helvetica,25.'\n", ylabel);
	fprintf(gp," set zlabel '%s' offset -6,0 font 'helvetica,25.'\n", zlabel);
	if(xrange != NULL) fprintf(gp," set xrange %s \n", xrange);
	if(yrange != NULL) fprintf(gp," set yrange %s \n", yrange);
	if(zrange != NULL) fprintf(gp," set zrange %s \n", zrange);
	if(title1==NULL && title2==NULL && title3==NULL) fprintf(gp,"unset key\n");
	
	//fprintf(gp, "set dgrid3d 50,50\n");
	//fprintf(gp, "set hidden3d\n");
	//fprintf(gp, "set view 60, 60\n");
	if(setoption != NULL) fprintf(gp," set %s \n", setoption);
	//fprintf(gp," set terminal postscript color\n");
	fprintf(gp," set terminal postscript eps enhanced color \n");
	fprintf(gp," set output '%s' \n", psfilename);
	if(title1==NULL) fprintf(gp,"splot '%s' using 2:3:4 with lines lc %i lw 3 notitle, ", trackout1, lc_tck1);
	else fprintf(gp,"splot '%s' using 2:3:4 with lines lc %i lw 3 title '%s', ", trackout1, lc_tck1, title1);
	if(title2==NULL) fprintf(gp,"'%s' using 2:3:4 with lines lc %i lw 3 notitle, ", trackout2, lc_tck2);
	else fprintf(gp,"'%s' using 2:3:4 with lines lc %i lw 3 title '%s', ", trackout2, lc_tck2, title2);
	if(title3==NULL) fprintf(gp,"'%s' using 2:3:4 with lines lc %i lw 3 notitle, ", trackout3, lc_tck3);
	else fprintf(gp,"'%s' using 2:3:4 with lines lc %i lw 3 title '%s', ", trackout3, lc_tck3, title3);
	if(title4==NULL) fprintf(gp,"'%s' using 2:3:4 with lines lc %i lw 3 notitle, ", trackout4, lc_tck4);
	else fprintf(gp,"'%s' using 2:3:4 with lines lc %i lw 3 title '%s', ", trackout4, lc_tck4, title4);
	if(title5==NULL) fprintf(gp,"'%s' using 2:3:4 with lines lc %i lw 3 notitle, ", trackout5, lc_tck5);
	else fprintf(gp,"'%s' using 2:3:4 with lines lc %i lw 3 title '%s', ", trackout5, lc_tck5, title5);
	fprintf(gp,"'data/aspect3d.dat' using 1:2:3 with lines lt 1 lc 0 lw 1.5 notitle, ");
	fprintf(gp,"'data/aspect3d.dat' using (%lf):2:3 with lines lt 1 lc 0 lw 0.5 dt 2 notitle, ", xmin);
	fprintf(gp,"'data/aspect3d.dat' using 1:2:(%lf) with lines lt 1 lc 0 lw 0.5 dt 2 notitle, ", zmin);
	
	fprintf(gp,"'%s' using (%lf):3:4 with lines lc %i lw 1 dt 2  notitle, ", trackout1, xmin, lc_tck1);
	fprintf(gp,"'%s' using 2:3:(%lf) with lines lc %i lw 1 dt 2  notitle, ", trackout1, zmin, lc_tck1);
	
	fprintf(gp,"'%s' using (%lf):3:4 with lines lc %i lw 1 dt 2  notitle, ", trackout2, xmin, lc_tck2);
	fprintf(gp,"'%s' using 2:3:(%lf) with lines lc %i lw 1 dt 2  notitle, ", trackout2, zmin, lc_tck2);
	
	fprintf(gp,"'%s' using (%lf):3:4 with lines lc %i lw 1 dt 2  notitle, ", trackout3, xmin, lc_tck3);
	fprintf(gp,"'%s' using 2:3:(%lf) with lines lc %i lw 1 dt 2  notitle\n", trackout3, zmin, lc_tck3);
	
	fprintf(gp,"'%s' using (%lf):3:4 with lines lc %i lw 1 dt 2  notitle, ", trackout4, xmin, lc_tck4);
	fprintf(gp,"'%s' using 2:3:(%lf) with lines lc %i lw 1 dt 2  notitle\n", trackout4, zmin, lc_tck4);
	
	fprintf(gp,"'%s' using (%lf):3:4 with lines lc %i lw 1 dt 2  notitle, ", trackout5, xmin, lc_tck5);
	fprintf(gp,"'%s' using 2:3:(%lf) with lines lc %i lw 1 dt 2  notitle\n", trackout5, zmin, lc_tck5);
	
	//fprintf(gp," set output\n");
	//fprintf(gp," set terminal x11\n");
	//fprintf(gp,"splot '%s' using %s:%s:%s with %s, '%s' using %s:%s:%s with %s, '%s' using %s:%s:%s with %s, '%s' using %s:%s:%s with %s, '%s' using %s:%s:%s with %s, '%s' using %s:%s:%s with %s\n", 
	//txtfilename1, xcolumn1, ycolumn1, zcolumn1, with1, txtfilename2, xcolumn2, ycolumn2, zcolumn2, with2, txtfilename3, xcolumn3, ycolumn3, zcolumn3, with3, txtfilename4, xcolumn4, ycolumn4, zcolumn4, with4, txtfilename5, xcolumn5, ycolumn5, zcolumn5, with5,  txtfilename6, xcolumn6, ycolumn6, zcolumn6, with6);
	
	pclose(gp);
	//if(psfilename != NULL) fix_boundingbox(psfilename, YES);
}

extern void aspectview(char *filename, struct Lattice *latt)
{
	int i, j;
	struct Lattice tempo_latt;
	
	//copy a Lattice, with cell[] stored at a diffent memory address, 
	//!!!and DO NOT FORGET to free the allocated memory before exiting aspectview!!!
	copy_latt(&tempo_latt, latt);
	emptyfile(filename);
	for(i = 0; i < tempo_latt.periodicity; i++) {
		for(j = 0; j < tempo_latt.nbcell ;j++) {
			if (strcmp(tempo_latt.cell[j].keyword, "ffag-r-he") == 0 || 
				strcmp(tempo_latt.cell[j].keyword, "ffag-r-lin") == 0 || 
				strcmp(tempo_latt.cell[j].keyword, "ffag-r-enge") == 0) aspect_radial(filename, &(tempo_latt.cell[j]));
			else if (strcmp(tempo_latt.cell[j].keyword, "ffag-spi-he") == 0 || 
					strcmp(tempo_latt.cell[j].keyword, "ffag-spi-lin") == 0 || 
					strcmp(tempo_latt.cell[j].keyword, "ffag-spi-enge") == 0 ||
					strcmp(tempo_latt.cell[j].keyword, "ffag-spi-fullenge") == 0) aspect_spiral(filename, &(tempo_latt.cell[j]));
			else if (strcmp(tempo_latt.cell[j].keyword, "ffag-s-lin") == 0 || 
					strcmp(tempo_latt.cell[j].keyword, "ffag-s-he") == 0 || 
					strcmp(tempo_latt.cell[j].keyword, "ffag-s-enge") == 0) aspect_straight(filename, &(tempo_latt.cell[j]));
			else if (strcmp(tempo_latt.cell[j].keyword, "ffag-sti-lin") == 0 || 
					strcmp(tempo_latt.cell[j].keyword, "ffag-sti-he") == 0 || 
					strcmp(tempo_latt.cell[j].keyword, "ffag-sti-enge") == 0) aspect_straighttilt(filename, &(tempo_latt.cell[j]));
			else if (strcmp(tempo_latt.cell[j].keyword, "realbend") == 0) aspect_realbend(filename, &(tempo_latt.cell[j]));
			else if (strcmp(tempo_latt.cell[j].keyword, "purebend-he") == 0 || 
					strcmp(tempo_latt.cell[j].keyword, "purebend-lin") == 0 || 
					strcmp(tempo_latt.cell[j].keyword, "purebend-enge") == 0) aspect_purebend(filename, &(tempo_latt.cell[j]));
			else if (test_cell_map(&(tempo_latt.cell[j])) == YES) aspect_boun(filename, &(tempo_latt.cell[j]));
			else if (strcmp(tempo_latt.cell[j].keyword, "quad-lin") == 0 || 
					strcmp(tempo_latt.cell[j].keyword, "quad-he") == 0 || 
					strcmp(tempo_latt.cell[j].keyword, "quad-enge") == 0) aspect_straight(filename, &(tempo_latt.cell[j]));
			else if(strcmp(latt->cell[i].keyword, "vffa-rect-enge") == 0 ||
					strcmp(latt->cell[i].keyword, "vffa-rect-enge-add") == 0 ||
					strcmp(latt->cell[i].keyword, "vffa-rect-enge-bx") == 0 ||
					strcmp(latt->cell[i].keyword, "vffa-rect-enge-separ") == 0 ||
					strcmp(latt->cell[i].keyword, "vffa-rect-str-enge") == 0 ||
					strcmp(latt->cell[i].keyword, "vffa-rect-str-lin") == 0 ||
					strcmp(latt->cell[i].keyword, "vffa-rect-lin") == 0 ||
					strcmp(latt->cell[i].keyword, "vffa-rect-str-he") == 0 ||
					strcmp(latt->cell[i].keyword, "vffa-rect-he") == 0 ||
					strcmp(latt->cell[i].keyword, "vffa-rect-atan-str") == 0 ||
					strcmp(latt->cell[i].keyword, "vffa-rect-atan") == 0) aspect_rect_vffa(filename, &(tempo_latt.cell[j]));
			else if(strcmp(tempo_latt.cell[j].keyword, "vffa-sect-lin") == 0 || 
					strcmp(tempo_latt.cell[j].keyword, "vffa-sect-enge") == 0) aspect_sect_vffa(filename, &(tempo_latt.cell[j]));
		}
		//move framework
		latt_move_exit_to_entrance(&tempo_latt);
	}
	//free allocated memory
	free(tempo_latt.cell);
}

static void change_coord_vffa_sect(double *x, double *y, double r, double th, int comp_nb, struct Cell *cell)
{
	int sign_rho;
	double rc, thc, rho, xm, ym;
	
	thc = cell->mpara[comp_nb][0]; //[rad]
	rc = cell->mpara[comp_nb][1];
	rho = cell->mpara[comp_nb][5];
	sign_rho = sign(cell->mpara[comp_nb][5]);
	
	xm = r*cos(th); //rho, ffbe
	ym = r*sin(th);
	*x = (xm*sign_rho+rc-rho)*cos(thc) - ym*sin(thc);
	*y = (xm*sign_rho+rc-rho)*sin(thc) + ym*cos(thc);
	fwk_pt_loctoglob(x, y, &(cell->framework));
}

static void aspect_sect_vffa(char *filename, struct Cell *cell)
{
	int i, j, n;
	double rho, conv_lim, x, y, ffbe, ffbs, rmin, rmax, th, z_0, zwerr;
	FILE *wfile;
	n = 20;
	
	wfile = fopen(filename, "a");
	for(j = 0; j < cell->nbcomp; j++) {
		if(cell->mpara[j][0]>0-TINYLENGTH && cell->mpara[j][0]<cell->boun.thmax+TINYLENGTH) {
			rho = fabs(cell->mpara[j][5]);
			conv_lim = cell->mpara[j][6]; //convergence limit [m]
			if(conv_lim<TINYLENGTH) errorstop("convergence limit <=0, have you initialized it?");
			z_0 = cell->mpara[j][3];
			ffbe = cell->efben[j][0]; //[rad]
			ffbs = cell->efbex[j][0]; //[rad]
			rmin = MAX(0,rho-conv_lim);
			rmax = rho+conv_lim;
			
			change_coord_vffa_sect(&x, &y, rho, ffbe, j, cell);
			fprintf(wfile, "%le  %le\n",x,y);
			for(i=0;i<n+1;i++) { //rmax, ffbe->ffbs
				th = ffbe + i*(ffbs-ffbe)/n;
				change_coord_vffa_sect(&x, &y, rmax, th, j, cell);
				if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				fprintf(wfile, "%le  %le\n",x,y);
			}
			fprintf(wfile, "%le  %le\n",x,y);
			for(i=0;i<n+1;i++) { //rho, ffbs->ffbe
				th = ffbs + i*(ffbe-ffbs)/n;
				change_coord_vffa_sect(&x, &y, rho, th, j, cell);
				if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				fprintf(wfile, "%le  %le\n",x,y);
			}
			change_coord_vffa_sect(&x, &y, rmin, ffbe, j, cell);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fprintf(wfile, "%le  %le\n",x,y);
			if(rmin>TINYLENGTH) { //rmin, ffbe->ffbs
				for(i=1;i<n+1;i++) {
					th = ffbe + i*(ffbs-ffbe)/n;
					change_coord_vffa_sect(&x, &y, rmin, th, j, cell);
					if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
					fprintf(wfile, "%le  %le\n",x,y);
				}
			}
			change_coord_vffa_sect(&x, &y, rho, ffbs, j, cell);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fprintf(wfile, "%le  %le\n",x,y);
			fprintf(wfile, "\n\n");
		}
	}
	fclose(wfile);
}

static void aspect_rect_vffa(char *filename, struct Cell *cell)
{
	int j, doyouplotcomp=YES, doyoulimitcomp=NO;
	double x, y, x_0, y_0, z_0, ffbe, ffbs, lambda_e, angle, zwerr;//, lambda_s;
	FILE *wfile;
	
	
	wfile = fopen(filename, "a");
	for(j = 0; j < cell->nbcomp; j++) {
		if(doyoulimitcomp==YES) {
			if(cell->boun.thmax!=0) {
				if(cell->mpara[j][0]>0-TINYLENGTH && cell->mpara[j][0]<cell->boun.thmax+TINYLENGTH) doyouplotcomp = YES;
				else doyouplotcomp = NO;
			}
			else {
				if(cell->mpara[j][0] > 0-TINYLENGTH && cell->mpara[j][0] < cell->boun.ymax+TINYLENGTH) doyouplotcomp = YES;
				else doyouplotcomp = NO;
			}
		}
		//printf("comp %i, doyouplot=%i, YES=%i\n", j, doyouplotcomp, YES);
		if(doyouplotcomp==YES) {
			if(cell->boun.thmax!=0) {
				x_0 = cell->mpara[j][1]*cos(cell->mpara[j][0]);
				y_0 = cell->mpara[j][1]*sin(cell->mpara[j][0]);
			}
			else {
				x_0 = cell->mpara[j][1];
				y_0 = cell->mpara[j][0];
			}
			z_0 = cell->mpara[j][3];
			ffbe = cell->efben[j][0];
			ffbs = cell->efbex[j][0];
			//lambda_e = cell->efben[j][1];
			//lambda_s = cell->efbex[j][1];
			lambda_e = cell->mpara[j][6];
			angle = cell->mpara[j][5];
			if(cell->boun.thmax!=0) angle +=cell->mpara[j][0];
			
			x = x_0 - ffbs*sin(angle) + lambda_e*cos(angle);
			y = y_0 + ffbs*cos(angle) + lambda_e*sin(angle);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = x_0 - ffbe*sin(angle) + lambda_e*cos(angle);
			y = y_0 + ffbe*cos(angle) + lambda_e*sin(angle);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			
			x = x_0 - ffbe*sin(angle);
			y = y_0 + ffbe*cos(angle);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			
			x = x_0 - ffbs*sin(angle);
			y = y_0 + ffbs*cos(angle);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			
			x = x_0 - ffbe*sin(angle);
			y = y_0 + ffbe*cos(angle);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			
			x = x_0 - ffbe*sin(angle) - lambda_e*cos(angle);
			y = y_0 + ffbe*cos(angle) - lambda_e*sin(angle);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = x_0 - ffbs*sin(angle) - lambda_e*cos(angle);
			y = y_0 + ffbs*cos(angle) - lambda_e*sin(angle);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = x_0 - ffbs*sin(angle) + lambda_e*cos(angle);
			y = y_0 + ffbs*cos(angle) + lambda_e*sin(angle);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, z_0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);//*/
			fprintf(wfile, "\n\n");
		}
	}
	fclose(wfile);
}

static void aspect_rect_vffa3d(char *filename, struct Cell *cell, int doyouerr)
{
	int j, doyouplotcomp=YES;
	double x, y,z, zmin,zmax, x_0, y_0, ffbe, ffbs, lambda_e, angle, xwerr,ywerr,zwerr;//, lambda_s;
	FILE *wfile;
	
	
	wfile = fopen(filename, "a");
	for(j = 0; j < cell->nbcomp; j++) {
		if(cell->boun.thmax!=0) { // plot components only if there are in the cell
			if(cell->mpara[j][0]>0-TINYLENGTH && cell->mpara[j][0]<cell->boun.thmax+TINYLENGTH) doyouplotcomp = YES;
			else doyouplotcomp = NO;
		}
		else {
			if(cell->mpara[j][0] > 0-TINYLENGTH && cell->mpara[j][0] < cell->boun.ymax+TINYLENGTH) doyouplotcomp = YES;
			else doyouplotcomp = NO;
		}
		//printf("comp %i, doyouplot=%i, YES=%i\n", j, doyouplotcomp, YES);
		
		//if(cell->mpara[j][0]>0-TINYLENGTH && cell->mpara[j][0]<cell->boun.thmax+TINYLENGTH) doyouplotcomp = YES;
		//else doyouplotcomp = NO;
		if(doyouplotcomp==YES) {
			if(cell->boun.thmax!=0) {
				convert_polar_to_cart(cell->mpara[j][1], cell->mpara[j][0], &x_0, &y_0);
				//x_0 = cell->mpara[j][1]*cos(cell->mpara[j][0]);
				//y_0 = cell->mpara[j][1]*sin(cell->mpara[j][0]);
			}
			else {
				x_0 = cell->mpara[j][1];
				y_0 = cell->mpara[j][0];
			}
			zmin = cell->collim.zmin;
			zmax = cell->collim.zmax;

			ffbe = cell->efben[j][0];
			ffbs = cell->efbex[j][0];
			//lambda_e = cell->efben[j][1];
			//lambda_s = cell->efbex[j][1];
			lambda_e = cell->mpara[j][6];
			//angle = cell->mpara[j][0]+cell->mpara[j][5];
			angle = cell->mpara[j][5];
			if(cell->boun.thmax!=0) angle +=cell->mpara[j][0];
			
			x = x_0 - ffbs*sin(angle) + lambda_e*cos(angle); //D
			y = y_0 + ffbs*cos(angle) + lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
		
			x = x_0 - ffbe*sin(angle) + lambda_e*cos(angle); //C
			y = y_0 + ffbe*cos(angle) + lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbe*sin(angle); //B
			y = y_0 + ffbe*cos(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbs*sin(angle); //E
			y = y_0 + ffbs*cos(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbe*sin(angle); //B
			y = y_0 + ffbe*cos(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbe*sin(angle) - lambda_e*cos(angle); //A
			y = y_0 + ffbe*cos(angle) - lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
		
			x = x_0 - ffbs*sin(angle) - lambda_e*cos(angle); //F
			y = y_0 + ffbs*cos(angle) - lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
		
			x = x_0 - ffbs*sin(angle) + lambda_e*cos(angle); //D
			y = y_0 + ffbs*cos(angle) + lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbs*sin(angle) + lambda_e*cos(angle); //J
			y = y_0 + ffbs*cos(angle) + lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
		
			x = x_0 - ffbe*sin(angle) + lambda_e*cos(angle); //I
			y = y_0 + ffbe*cos(angle) + lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbe*sin(angle) + lambda_e*cos(angle); //C
			y = y_0 + ffbe*cos(angle) + lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbe*sin(angle) + lambda_e*cos(angle); //I
			y = y_0 + ffbe*cos(angle) + lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbe*sin(angle); //H
			y = y_0 + ffbe*cos(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbe*sin(angle); //B
			y = y_0 + ffbe*cos(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbe*sin(angle); //H
			y = y_0 + ffbe*cos(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbs*sin(angle); //K
			y = y_0 + ffbs*cos(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbs*sin(angle); //E
			y = y_0 + ffbs*cos(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbs*sin(angle); //K
			y = y_0 + ffbs*cos(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbe*sin(angle); //H
			y = y_0 + ffbe*cos(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbe*sin(angle) - lambda_e*cos(angle); //G
			y = y_0 + ffbe*cos(angle) - lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbe*sin(angle) - lambda_e*cos(angle); //A
			y = y_0 + ffbe*cos(angle) - lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbe*sin(angle) - lambda_e*cos(angle); //G
			y = y_0 + ffbe*cos(angle) - lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbs*sin(angle) - lambda_e*cos(angle); //L
			y = y_0 + ffbs*cos(angle) - lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbs*sin(angle) - lambda_e*cos(angle); //F
			y = y_0 + ffbs*cos(angle) - lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmin, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmin;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbs*sin(angle) - lambda_e*cos(angle); //L
			y = y_0 + ffbs*cos(angle) - lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			
			x = x_0 - ffbs*sin(angle) + lambda_e*cos(angle); //J
			y = y_0 + ffbs*cos(angle) + lambda_e*sin(angle);
			if(doyouerr==YES) {
				apply_alierror_comp(cell, j, x, y, zmax, &xwerr, &ywerr, &zwerr, 1); //sign to move the pole from the observatorpoint of view
				x = xwerr;
				y = ywerr;
				z = zwerr;
			}
			else z = zmax;
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le  %le\n",x,y,z);
			fprintf(wfile, "\n\n");
		}
	}
	fclose(wfile);
}

static void aspect_boun(char *filename, struct Cell *cell)
{
	int i, n;
	double x, y, rmin, rmax, th, thmax, thstep;
	FILE *wfile;
	
	n = 50;
	
	rmin = cell->collim.rmin;
	rmax = cell->collim.rmax;
	
	//test = (rmax - 1/n*(rmax-rmin));
	//printf("test = %lf\n", test);
	wfile = fopen(filename, "a");
	
	x = rmin;
	y = 0.;
	fwk_pt_loctoglob(&x, &y, &(cell->framework));
	fprintf(wfile, "%lf  %lf\n",x,y);
	
	if(cell->boun.thmax != 0) {
		thmax = cell->boun.thmax;
		thstep = thmax/n;
		//fprintf(wfile, "0  0\n");
		for(i = 0; i < n+1; i++) {
			th = i*thstep;
			convert_polar_to_cart(rmax, th, &x, &y);
			//x = rmax*cos(th);
			//y = rmax*sin(th);
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		}
		//fprintf(wfile, "0  0\n\n");
		x = rmin*cos(thmax);
		y = rmin*sin(thmax);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%lf  %lf\n",x,y);
		for(i = n; i > -1; i--) {
			th = i*thstep;
			convert_polar_to_cart(rmin, th, &x, &y);
			//x = rmin*cos(th);
			//y = rmin*sin(th);
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		}
	}
	else {
		x = rmax;
		y = 0.;
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %lf\n",x,y);
		x = rmax;
		y = cell->boun.ymax;
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		x = rmin;
		y = cell->boun.ymax;
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		x = rmin;
		y = 0.;
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%lf  %lf\n",x,y);
	}
	fprintf(wfile, "\n\n");
	
	if(cell->instrutype != NO) {
		printf("instrutype != NO\n");
	}
	fclose(wfile);
}

static void aspect_radial(char *filename, struct Cell *cell)
{
	int j;
	double x, y, rmin, rmax, zwerr;
	FILE *wfile;
	
	rmin = cell->collim.rmin;
	rmax = cell->collim.rmax;
	
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		if(cell->mpara[j][0]>0-TINYLENGTH && cell->mpara[j][0]<cell->boun.thmax+TINYLENGTH) {
			x = rmin*cos(cell->mpara[j][0] + cell->efben[j][0]);
			y = rmin*sin(cell->mpara[j][0] + cell->efben[j][0]);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = rmax*cos(cell->mpara[j][0] + cell->efben[j][0]);
			y = rmax*sin(cell->mpara[j][0] + cell->efben[j][0]);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = rmax*cos(cell->mpara[j][0] + cell->efbex[j][0]);
			y = rmax*sin(cell->mpara[j][0] + cell->efbex[j][0]);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = rmin*cos(cell->mpara[j][0] + cell->efbex[j][0]);
			y = rmin*sin(cell->mpara[j][0] + cell->efbex[j][0]);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = rmin*cos(cell->mpara[j][0] + cell->efben[j][0]);
			y = rmin*sin(cell->mpara[j][0] + cell->efben[j][0]);
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			fprintf(wfile, "\n\n");
		}
	}
	
	if(cell->instrutype != NO) {
		printf("instrutype != NO\n");
		//x = (rmin-0.2)*cos(cell->instru[0].thmax);
		//y = (rmin-0.2)*sin(cell->instru[0].thmax);
		//fwk_pt_loctoglob(&x, &y, &(cell->framework));
		//fprintf(wfile, "%le  %le\n",x,y);
		//
		//x = (rmax+0.2)*cos(cell->instru[0].thmax);
		//y = (rmax+0.2)*sin(cell->instru[0].thmax);
		//fwk_pt_loctoglob(&x, &y, &(cell->framework));
		//fprintf(wfile, "%le  %le\n",x,y);
		//fprintf(wfile, "\n\n");
	}
	
	fclose(wfile);
}

static void aspect_straight(char *filename, struct Cell *cell)
{
	int j;
	double x, y, xmin, xmax, zwerr;
	FILE *wfile;
	
	xmin = cell->collim.rmin;
	xmax = cell->collim.rmax;
	
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		if(cell->mpara[j][0]>0 && cell->mpara[j][0]<cell->boun.ymax) {
			x = xmin;
			y = cell->mpara[j][0] + cell->efben[j][0];
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = xmax;
			y = cell->mpara[j][0] + cell->efben[j][0];
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = xmax;
			y = cell->mpara[j][0] + cell->efbex[j][0];
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = xmin;
			y = cell->mpara[j][0] + cell->efbex[j][0];
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = xmin;
			y = cell->mpara[j][0] + cell->efben[j][0];
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			fprintf(wfile, "\n\n");
		}
	}
	
	fclose(wfile);
}

static void aspect_realbend(char *filename, struct Cell *cell)
{
	double x, y, x0, y0, ffbe, ffbs, xm, xp;
	FILE *wfile;
	
	convert_polar_to_cart(cell->mpara[0][0], cell->boun.thmax/2., &x0, &y0);
	//x0 = cell->mpara[0][0]*cos(cell->boun.thmax/2.);
	//y0 = cell->mpara[0][0]*sin(cell->boun.thmax/2.);
	ffbe = y0 + cell->efben[0][0];
	ffbs = y0 + cell->efbex[0][0];
	xm = x0 - cell->mpara[0][1];
	xp = x0 + cell->mpara[0][1];
	
	wfile = fopen(filename, "a");
	
	x = x0+(xm-x0)*cos(-cell->boun.thmax/2.)+(ffbe-y0)*sin(-cell->boun.thmax/2.);
	y = y0-(xm-x0)*sin(-cell->boun.thmax/2.)+(ffbe-y0)*cos(-cell->boun.thmax/2.);
	fwk_pt_loctoglob(&x, &y, &(cell->framework));
	fprintf(wfile, "%le  %le\n",x,y);
		
	x = x0+(xm-x0)*cos(-cell->boun.thmax/2.)+(ffbs-y0)*sin(-cell->boun.thmax/2.);
	y = y0-(xm-x0)*sin(-cell->boun.thmax/2.)+(ffbs-y0)*cos(-cell->boun.thmax/2.);
	fwk_pt_loctoglob(&x, &y, &(cell->framework));
	fprintf(wfile, "%le  %le\n",x,y);
		
	x = x0+(xp-x0)*cos(-cell->boun.thmax/2.)+(ffbs-y0)*sin(-cell->boun.thmax/2.);
	y = y0-(xp-x0)*sin(-cell->boun.thmax/2.)+(ffbs-y0)*cos(-cell->boun.thmax/2.);
	fwk_pt_loctoglob(&x, &y, &(cell->framework));
	fprintf(wfile, "%le  %le\n",x,y);
		
	x = x0+(xp-x0)*cos(-cell->boun.thmax/2.)+(ffbe-y0)*sin(-cell->boun.thmax/2.);
	y = y0-(xp-x0)*sin(-cell->boun.thmax/2.)+(ffbe-y0)*cos(-cell->boun.thmax/2.);
	fwk_pt_loctoglob(&x, &y, &(cell->framework));
	fprintf(wfile, "%le  %le\n",x,y);
		
	x = x0+(xm-x0)*cos(-cell->boun.thmax/2.)+(ffbe-y0)*sin(-cell->boun.thmax/2.);
	y = y0-(xm-x0)*sin(-cell->boun.thmax/2.)+(ffbe-y0)*cos(-cell->boun.thmax/2.);
	fwk_pt_loctoglob(&x, &y, &(cell->framework));
	fprintf(wfile, "%le  %le\n",x,y);
	fprintf(wfile, "\n\n");
	
	/*
	x = 0;
	y = 0;
	fwk_pt_loctoglob(&x, &y, &(cell->framework));
	fprintf(wfile, "%le  %le\n",x,y);
	
	x = cell->collim.rmax;
	y = 0;
	fwk_pt_loctoglob(&x, &y, &(cell->framework));
	fprintf(wfile, "%le  %le\n",x,y);
	
	x = cell->collim.rmax*cos(cell->boun.thmax);
	y = cell->collim.rmax*sin(cell->boun.thmax);
	fwk_pt_loctoglob(&x, &y, &(cell->framework));
	fprintf(wfile, "%le  %le\n",x,y);
	
	x = 0;
	y = 0;
	fwk_pt_loctoglob(&x, &y, &(cell->framework));
	fprintf(wfile, "%le  %le\n",x,y);
	fprintf(wfile, "\n");
	//*/
	fclose(wfile);
}

static void aspect_purebend(char *filename, struct Cell *cell)
{
	int j;
	double x, y, rmin, rmax, rc;
	FILE *wfile;
	
	rmin = cell->collim.rmin;
	rmax = cell->collim.rmax;
	rc = cell->mpara[0][3];
	
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		x = rc*cos(cell->mpara[j][0]) + (rmin-rc)*cos(cell->mpara[j][0] + cell->efben[j][0]);
		y = rc*sin(cell->mpara[j][0]) + (rmin-rc)*sin(cell->mpara[j][0] + cell->efben[j][0]);
		//x = rc*cos(cell->mpara[j][0]);
		//y = rc*sin(cell->mpara[j][0]);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = rc*cos(cell->mpara[j][0]) + (rmax-rc)*cos(cell->mpara[j][0] + cell->efben[j][0]);
		y = rc*sin(cell->mpara[j][0]) + (rmax-rc)*sin(cell->mpara[j][0] + cell->efben[j][0]);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = rc*cos(cell->mpara[j][0]) + (rmax-rc)*cos(cell->mpara[j][0] + cell->efbex[j][0]);
		y = rc*sin(cell->mpara[j][0]) + (rmax-rc)*sin(cell->mpara[j][0] + cell->efbex[j][0]);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = rc*cos(cell->mpara[j][0]) + (rmin-rc)*cos(cell->mpara[j][0] + cell->efbex[j][0]);
		y = rc*sin(cell->mpara[j][0]) + (rmin-rc)*sin(cell->mpara[j][0] + cell->efbex[j][0]);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = rc*cos(cell->mpara[j][0]) + (rmin-rc)*cos(cell->mpara[j][0] + cell->efben[j][0]);
		y = rc*sin(cell->mpara[j][0]) + (rmin-rc)*sin(cell->mpara[j][0] + cell->efben[j][0]);
		//x = rc*cos(cell->mpara[j][0]);
		//y = rc*sin(cell->mpara[j][0]);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		fprintf(wfile, "\n\n");
		/*
		x = 0.;
		y = 0.;
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = rmax;
		y = 0.;
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = rmax*cos(cell->boun.thmax);
		y = rmax*sin(cell->boun.thmax);;
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = 0.;
		y = 0.;
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		fprintf(wfile, "\n");//*/
	}
	
	if(cell->instrutype != NO) {
		printf("instrutype != NO\n");
		//errorstop("don't know what's going on in aspect_purebend");
		//x = (rmin-0.2)*cos(cell->instru[0].thmax);
		//y = (rmin-0.2)*sin(cell->instru[0].thmax);
		//fwk_pt_loctoglob(&x, &y, &(cell->framework));
		//fprintf(wfile, "%le  %le\n",x,y);
		//
		//x = (rmax+0.2)*cos(cell->instru[0].thmax);
		//y = (rmax+0.2)*sin(cell->instru[0].thmax);
		//fwk_pt_loctoglob(&x, &y, &(cell->framework));
		//fprintf(wfile, "%le  %le\n",x,y);
		//fprintf(wfile, "\n\n");
	}
	
	fclose(wfile);
}

static void aspect_spiral(char *filename, struct Cell *cell)
{
	int j, i, n;
	double x, y, rmin, rmax, zwerr;//, xwerr, ywerr;
	//double test;
	FILE *wfile;
	
	n = 20;
	
	rmin = cell->collim.rmin;
	rmax = cell->collim.rmax;
	//test = (rmax - 1/n*(rmax-rmin));
	//printf("test = %lf\n", test);
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		for(i = 0; i < n+1; i++) {
			x = (rmin + i*(rmax-rmin)/n)*cos(cell->mpara[j][0] + cell->efben[j][0] + tan(cell->mpara[j][4])*log((rmin + i*(rmax-rmin)/n)/cell->mpara[j][1]));
			y = (rmin + i*(rmax-rmin)/n)*sin(cell->mpara[j][0] + cell->efben[j][0] + tan(cell->mpara[j][4])*log((rmin + i*(rmax-rmin)/n)/cell->mpara[j][1]));
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		}
		for(i = 0; i < n+1; i++) {
			x = (rmax - i*(rmax-rmin)/n)*cos(cell->mpara[j][0] + cell->efbex[j][0] + tan(cell->mpara[j][4])*log((rmax - i*(rmax-rmin)/n)/cell->mpara[j][1]));
			y = (rmax - i*(rmax-rmin)/n)*sin(cell->mpara[j][0] + cell->efbex[j][0] + tan(cell->mpara[j][4])*log((rmax - i*(rmax-rmin)/n)/cell->mpara[j][1]));
			if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		}
		
		x = rmin*cos(cell->mpara[j][0] + cell->efben[j][0] + tan(cell->mpara[j][4])*log((rmin)/cell->mpara[j][1]));
		y = rmin*sin(cell->mpara[j][0] + cell->efben[j][0] + tan(cell->mpara[j][4])*log((rmin)/cell->mpara[j][1]));
		if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		fprintf(wfile, "\n\n");
	}
	
	if(cell->instrutype != NO) {
		printf("instrutype != NO\n");
	}
	
	fclose(wfile);
}

static void aspect_straighttilt(char *filename, struct Cell *cell)
{
	int j;
	double x, y, xmin, xmax, zwerr;
	FILE *wfile;
	
	xmin = cell->collim.rmin;
	xmax = cell->collim.rmax;
	
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		x = xmin;
		y = cell->mpara[j][0] + cell->efben[j][0] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmin);
		if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = xmax;
		y = cell->mpara[j][0] + cell->efben[j][0] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmax);
		if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = xmax;
		y = cell->mpara[j][0] + cell->efbex[j][0] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmax);
		if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = xmin;
		y = cell->mpara[j][0] + cell->efbex[j][0] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmin);
		if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = xmin;
		y = cell->mpara[j][0] + cell->efben[j][0] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmin);
		if(cell->doyou_err==YES) apply_alierror_comp(cell, j, x, y, 0, &x, &y, &zwerr, 1); //sign to move the pole from the observatorpoint of view
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		fprintf(wfile, "\n\n");
	}
	
	fclose(wfile);
}

extern void aspect_fringe_view(char *filename_en, char *filename_ex, struct Lattice *latt)
{
	int i, j;
	struct Lattice tempo_latt;
	
	//copy a Lattice, with cell[] stored at a diffent memory address, 
	//!!!and DO NOT FORGET to free the allocated memory befor exiting aspectview!!!
	copy_latt(&tempo_latt, latt);
	 
	emptyfile(filename_en);
	emptyfile(filename_ex);
	for(i = 0; i < tempo_latt.periodicity; i++) {
		
		for(j = 0; j < tempo_latt.nbcell ;j++) {
			if (strcmp(tempo_latt.cell[j].keyword, "ffag-r-lin") == 0) {// || 
			//strcmp(tempo_latt.cell[j].keyword, "ffag-r-enge") == 0) {
				aspect_fringe_en_radial(filename_en, &(tempo_latt.cell[j]));
				aspect_fringe_ex_radial(filename_ex, &(tempo_latt.cell[j]));
			}
			else if (strcmp(tempo_latt.cell[j].keyword, "ffag-spi-lin") == 0) {// || 
			//strcmp(tempo_latt.cell[j].keyword, "ffag-spi-enge") == 0) {
				aspect_fringe_en_spiral(filename_en, &(tempo_latt.cell[j]));
				aspect_fringe_ex_spiral(filename_ex, &(tempo_latt.cell[j]));
			}
			else if (strcmp(tempo_latt.cell[j].keyword, "ffag-s-lin") == 0) {// || 
			//strcmp(tempo_latt.cell[j].keyword, "ffag-s-enge") == 0) {
				aspect_fringe_en_straight(filename_en, &(tempo_latt.cell[j]));
				aspect_fringe_ex_straight(filename_ex, &(tempo_latt.cell[j]));
			}
			else if (strcmp(tempo_latt.cell[j].keyword, "ffag-sti-lin") == 0){// || 
			//strcmp(tempo_latt.cell[j].keyword, "ffag-sti-enge") == 0) {
				aspect_fringe_en_straighttilt(filename_en, &(tempo_latt.cell[j]));
				aspect_fringe_ex_straighttilt(filename_ex, &(tempo_latt.cell[j]));
			}
			//else if (strcmp(tempo_latt.cell[j].keyword, "realbend") == 0) aspect_realbend(filename, &(tempo_latt.cell[j]));
			//else if (strcmp(tempo_latt.cell[j].keyword, "purebend-lin") == 0 || 
			//	strcmp(tempo_latt.cell[j].keyword, "purebend-enge") == 0) aspect_purebend(filename, &(tempo_latt.cell[j]));
			else if (strcmp(tempo_latt.cell[j].keyword, "quad-lin") == 0) {// || 
			//strcmp(tempo_latt.cell[j].keyword, "quad-enge") == 0) {
				aspect_fringe_en_straight(filename_en, &(tempo_latt.cell[j]));
				aspect_fringe_ex_straight(filename_ex, &(tempo_latt.cell[j]));
			}
		}
		//move framework
		latt_move_exit_to_entrance(&tempo_latt);
	}
	
	//free allocated memory
	free(tempo_latt.cell);
}

static void aspect_fringe_en_radial(char *filename, struct Cell *cell)
{
	int j;
	double x, y, rmin, rmax;
	FILE *wfile;
	
	rmin = cell->collim.rmin;
	rmax = cell->collim.rmax;
	
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		if(cell->mpara[j][0]>0-TINYLENGTH && cell->mpara[j][0]<cell->boun.thmax+TINYLENGTH) {
			//entrance
			convert_polar_to_cart(rmin, cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1], &x, &y);
			//x = rmin*cos(cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1]);
			//y = rmin*sin(cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1]);
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			convert_polar_to_cart(rmax, cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1], &x, &y);
			//x = rmax*cos(cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1]);
			//y = rmax*sin(cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1]);
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			
			convert_polar_to_cart(rmin, cell->mpara[j][0] + cell->efben[j][0] + cell->efben[j][1], &x, &y);
			//x = rmin*cos(cell->mpara[j][0] + cell->efben[j][0] + cell->efben[j][1]);
			//y = rmin*sin(cell->mpara[j][0] + cell->efben[j][0] + cell->efben[j][1]);
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			convert_polar_to_cart(rmax, cell->mpara[j][0] + cell->efben[j][0] + cell->efben[j][1], &x, &y);
			//x = rmax*cos(cell->mpara[j][0] + cell->efben[j][0] + cell->efben[j][1]);
			//y = rmax*sin(cell->mpara[j][0] + cell->efben[j][0] + cell->efben[j][1]);
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			
			convert_polar_to_cart(rmin, cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1], &x, &y);
			//x = rmin*cos(cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1]);
			//y = rmin*sin(cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1]);
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			fprintf(wfile, "\n\n");
		}
	}
	
	
	fclose(wfile);
}

static void aspect_fringe_ex_radial(char *filename, struct Cell *cell)
{
	int j;
	double x, y, rmin, rmax;
	FILE *wfile;
	
	rmin = cell->collim.rmin;
	rmax = cell->collim.rmax;
	
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		if(cell->mpara[j][0]>0-TINYLENGTH && cell->mpara[j][0]<cell->boun.thmax+TINYLENGTH) {
			//exit
			convert_polar_to_cart(rmax, cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1], &x, &y);
			//x = rmax*cos(cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1]);
			//y = rmax*sin(cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1]);
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			convert_polar_to_cart(rmin, cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1], &x, &y);
			//x = rmin*cos(cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1]);
			//y = rmin*sin(cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1]);
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			
			convert_polar_to_cart(rmax, cell->mpara[j][0] + cell->efbex[j][0] + cell->efbex[j][1], &x, &y);
			//x = rmax*cos(cell->mpara[j][0] + cell->efbex[j][0] + cell->efbex[j][1]);
			//y = rmax*sin(cell->mpara[j][0] + cell->efbex[j][0] + cell->efbex[j][1]);
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			convert_polar_to_cart(rmin, cell->mpara[j][0] + cell->efbex[j][0] + cell->efbex[j][1], &x, &y);
			//x = rmin*cos(cell->mpara[j][0] + cell->efbex[j][0] + cell->efbex[j][1]);
			//y = rmin*sin(cell->mpara[j][0] + cell->efbex[j][0] + cell->efbex[j][1]);
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			convert_polar_to_cart(rmin, cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1], &x, &y);
			//x = rmin*cos(cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1]);
			//y = rmin*sin(cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1]);
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			fprintf(wfile, "\n\n");
		}
	}
	
	
	fclose(wfile);
}

static void aspect_fringe_en_straight(char *filename, struct Cell *cell)
{
	int j;
	double x, y, xmin, xmax;
	FILE *wfile;
	
	xmin = cell->collim.rmin;
	xmax = cell->collim.rmax;
	
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		if(cell->mpara[j][0]>0 && cell->mpara[j][0]<cell->boun.ymax) {
			x = xmin;
			y = cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1];
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = xmax;
			y = cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1];
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = xmax;
			y = cell->mpara[j][0] + cell->efben[j][0] + cell->efben[j][1];
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = xmin;
			y = cell->mpara[j][0] + cell->efben[j][0] + cell->efben[j][1];
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = xmin;
			y = cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1];
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			fprintf(wfile, "\n\n");
		}
	}
	fclose(wfile);
}

static void aspect_fringe_ex_straight(char *filename, struct Cell *cell)
{
	int j;
	double x, y, xmin, xmax;
	FILE *wfile;
	
	xmin = cell->collim.rmin;
	xmax = cell->collim.rmax;
	
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		if(cell->mpara[j][0]>0 && cell->mpara[j][0]<cell->boun.ymax) {
			x = xmin;
			y = cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1];
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = xmax;
			y = cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1];
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = xmax;
			y = cell->mpara[j][0] + cell->efbex[j][0] + cell->efbex[j][1];
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = xmin;
			y = cell->mpara[j][0] + cell->efbex[j][0] + cell->efbex[j][1];
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		
			x = xmin;
			y = cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1];
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
			fprintf(wfile, "\n\n");
		}
	}
	fclose(wfile);
}

static void aspect_fringe_en_spiral(char *filename, struct Cell *cell)
{
	int j, i, n;
	double x, y, rmin, rmax;
	//double test;
	FILE *wfile;
	
	n = 20;
	
	rmin = cell->collim.rmin;
	rmax = cell->collim.rmax;
	//test = (rmax - 1/n*(rmax-rmin));
	//printf("test = %lf\n", test);
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		for(i = 0; i < n+1; i++) {
			x = (rmin + i*(rmax-rmin)/n)*cos(cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1] + tan(cell->mpara[j][4])*log((rmin + i*(rmax-rmin)/n)/cell->mpara[j][1]));
			y = (rmin + i*(rmax-rmin)/n)*sin(cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1] + tan(cell->mpara[j][4])*log((rmin + i*(rmax-rmin)/n)/cell->mpara[j][1]));
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		}
		for(i = 0; i < n+1; i++) {
			x = (rmax - i*(rmax-rmin)/n)*cos(cell->mpara[j][0] + cell->efben[j][0] + cell->efben[j][1] + tan(cell->mpara[j][4])*log((rmax - i*(rmax-rmin)/n)/cell->mpara[j][1]));
			y = (rmax - i*(rmax-rmin)/n)*sin(cell->mpara[j][0] + cell->efben[j][0] + cell->efben[j][1] + tan(cell->mpara[j][4])*log((rmax - i*(rmax-rmin)/n)/cell->mpara[j][1]));
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		}
		
		x = rmin*cos(cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1] + tan(cell->mpara[j][4])*log((rmin)/cell->mpara[j][1]));
		y = rmin*sin(cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1] + tan(cell->mpara[j][4])*log((rmin)/cell->mpara[j][1]));
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		fprintf(wfile, "\n\n");
	}
	
	if(cell->instrutype != NO) {
		printf("instrutype != NO\n");
	}
	
	fclose(wfile);
}

static void aspect_fringe_ex_spiral(char *filename, struct Cell *cell)
{
	int j, i, n;
	double x, y, rmin, rmax;
	//double test;
	FILE *wfile;
	
	n = 20;
	
	rmin = cell->collim.rmin;
	rmax = cell->collim.rmax;
	//test = (rmax - 1/n*(rmax-rmin));
	//printf("test = %lf\n", test);
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		for(i = 0; i < n+1; i++) {
			x = (rmin + i*(rmax-rmin)/n)*cos(cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1] + tan(cell->mpara[j][4])*log((rmin + i*(rmax-rmin)/n)/cell->mpara[j][1]));
			y = (rmin + i*(rmax-rmin)/n)*sin(cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1] + tan(cell->mpara[j][4])*log((rmin + i*(rmax-rmin)/n)/cell->mpara[j][1]));
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		}
		for(i = 0; i < n+1; i++) {
			x = (rmax - i*(rmax-rmin)/n)*cos(cell->mpara[j][0] + cell->efbex[j][0] + cell->efbex[j][1] + tan(cell->mpara[j][4])*log((rmax - i*(rmax-rmin)/n)/cell->mpara[j][1]));
			y = (rmax - i*(rmax-rmin)/n)*sin(cell->mpara[j][0] + cell->efbex[j][0] + cell->efbex[j][1] + tan(cell->mpara[j][4])*log((rmax - i*(rmax-rmin)/n)/cell->mpara[j][1]));
			fwk_pt_loctoglob(&x, &y, &(cell->framework));
			fprintf(wfile, "%le  %le\n",x,y);
		}
		
		x = rmin*cos(cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1] + tan(cell->mpara[j][4])*log((rmin)/cell->mpara[j][1]));
		y = rmin*sin(cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1] + tan(cell->mpara[j][4])*log((rmin)/cell->mpara[j][1]));
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		fprintf(wfile, "\n\n");
	}
	
	if(cell->instrutype != NO) {
		printf("instrutype != NO\n");
	}
	
	fclose(wfile);
}

static void aspect_fringe_en_straighttilt(char *filename, struct Cell *cell)
{
	int j;
	double x, y, xmin, xmax;
	FILE *wfile;
	
	xmin = cell->collim.rmin;
	xmax = cell->collim.rmax;
	
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		x = xmin;
		y = cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmin);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = xmax;
		y = cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmax);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = xmax;
		y = cell->mpara[j][0] + cell->efben[j][0] + cell->efben[j][1] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmax);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = xmin;
		y = cell->mpara[j][0] + cell->efben[j][0] + cell->efben[j][1] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmin);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = xmin;
		y = cell->mpara[j][0] + cell->efben[j][0] - cell->efben[j][1] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmin);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		fprintf(wfile, "\n\n");
	}
	
	fclose(wfile);
}

static void aspect_fringe_ex_straighttilt(char *filename, struct Cell *cell)
{
	int j;
	double x, y, xmin, xmax;
	FILE *wfile;
	
	xmin = cell->collim.rmin;
	xmax = cell->collim.rmax;
	
	wfile = fopen(filename, "a");
	
	for(j = 0; j < cell->nbcomp; j++) {
		x = xmin;
		y = cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmin);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = xmax;
		y = cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmax);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = xmax;
		y = cell->mpara[j][0] + cell->efbex[j][0] + cell->efbex[j][1] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmax);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = xmin;
		y = cell->mpara[j][0] + cell->efbex[j][0] + cell->efbex[j][1] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmin);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		
		x = xmin;
		y = cell->mpara[j][0] + cell->efbex[j][0] - cell->efbex[j][1] - tan(cell->mpara[j][4])*(cell->mpara[j][1]-xmin);
		fwk_pt_loctoglob(&x, &y, &(cell->framework));
		fprintf(wfile, "%le  %le\n",x,y);
		fprintf(wfile, "\n\n");
	}
	
	fclose(wfile);
}

extern void auto_plot_trackout_gen(char *trackout, char *xkeyword, char *ykeyword, double xcol_mult, double xcol_add, double ycol_mult, double ycol_add, char *with, char *xlabel, char *ylabel, char *output, char *option)
{
	char xrange[50], yrange[50], x_gnuplot[50], y_gnuplot[50];
	int xcolumn = para_clm_trackout(xkeyword);
	int ycolumn = para_clm_trackout(ykeyword);
	find_range_column_file(trackout, xrange, xcolumn, NB_CLMS_TRACKOUT, NO, NO);
	find_range_column_file(trackout, yrange, ycolumn, NB_CLMS_TRACKOUT, NO, NO);
	sprintf(x_gnuplot, "($%i*%lf+%lf)", xcolumn, xcol_mult, xcol_add);
	sprintf(y_gnuplot, "($%i*%lf+%lf)", ycolumn, ycol_mult, ycol_add);
	easyplot(trackout, x_gnuplot, y_gnuplot, with, xlabel, ylabel, xrange, yrange, output, option);
}
	// ************************************************************************************ //
	//									plot simple ellipse									//
	// ************************************************************************************ //


extern void gnuplot_fit_general(char *txtfilename, char *xcolumn1, char *ycolumn1, char *fit_function_of_x, char *variables_name, char *init_variables, char *with1, 
				 char *with2, char *xlabel, char *ylabel, char *title1, char *title2, char *xrange, char *yrange, char *psfilename, char *setoption)
{
	char fitname[400];//, name[500];
	sprintf(fitname ,"%s-fit.log", psfilename);
	remove(fitname);
	
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	if(title1==NULL && title2==NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		fprintf(gp,"set fit logfile '%s'\n", fitname);
		fprintf(gp,"f(x) = %s\n", fit_function_of_x);
		fprintf(gp, "%s\n", init_variables);
		fprintf(gp,"fit f(x) '%s' using %s:%s via %s\n", txtfilename, xcolumn1, ycolumn1, variables_name);
		gnuplot2d_plot(gp, txtfilename, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
		if(title2 != NULL) fprintf(gp,"f(x) with %s title '%s'\n", with2, title2);
		else fprintf(gp,"f(x) with %s notitle\n", with2);
	}
	gnuplot_terminal(gp);	
	gnuplot2d_plot(gp, txtfilename, xcolumn1, ycolumn1, with1, title1, YES, YES, NO);
	if(title2 != NULL) fprintf(gp,"f(x) with %s title '%s'\n", with2, title2);
	else fprintf(gp,"f(x) with %s notitle\n", with2);
	gnuplot_end(gp, psfilename);
}

extern void tune_diag(char *textfilename, int supersym, double qxmin, double qxmax, double qzmin, double qzmax, int maxorder_s, int maxorder_ns, int doyounorm, int doyouskew, char *output_name)
{
	int n, m, p, incr, order, i, npts = 4;
	double pmax, xtics, ytics;
	FILE *fill2norm,*fill4norm,*fill6norm,*fill8norm,*fill10norm,*fill1norm,*fill3norm,*fill5norm,*fill7norm, *fill9norm,
	*fill2skew,*fill4skew,*fill6skew,*fill8skew,*fill10skew,*fill1skew,*fill3skew,*fill5skew,*fill7skew, *fill9skew;
	
	fill1norm = fopen("nonstruct_dip_norm","w"); 	fill1skew = fopen("nonstruct_dip_skew","w");
	fill2norm = fopen("struct_dip_norm","w"); 		fill2skew = fopen("struct_dip_skew","w");
	fill3norm = fopen("nonstruct_quad_norm","w"); 	fill3skew = fopen("nonstruct_quad_skew","w");
	fill4norm = fopen("struct_quad_norm","w"); 		fill4skew = fopen("struct_quad_skew","w");
	fill5norm = fopen("nonstruct_sext_norm","w"); 	fill5skew = fopen("nonstruct_sext_skew","w");
	fill6norm = fopen("struct_sext_norm","w"); 		fill6skew = fopen("struct_sext_skew","w");
	fill7norm = fopen("nonstruct_oct_norm","w"); 	fill7skew = fopen("nonstruct_oct_skew","w");
	fill8norm = fopen("struct_oct_norm","w"); 		fill8skew = fopen("struct_oct_skew","w");
	fill9norm = fopen("nonstruct_dec_norm","w"); 	fill9skew = fopen("nonstruct_dec_skew","w");
	fill10norm = fopen("struct_dec_norm","w"); 		fill10skew = fopen("struct_dec_skew","w");
	
	fprintf(fill1norm, "0 0 \n"); fprintf(fill1skew, "0 0 \n"); fprintf(fill2norm, "0 0 \n"); fprintf(fill2skew, "0 0 \n");
	fprintf(fill3norm, "0 0 \n"); fprintf(fill3skew, "0 0 \n"); fprintf(fill4norm, "0 0 \n"); fprintf(fill4skew, "0 0 \n");
	fprintf(fill5norm, "0 0 \n"); fprintf(fill5skew, "0 0 \n"); fprintf(fill6norm, "0 0 \n"); fprintf(fill6skew, "0 0 \n");
	fprintf(fill7norm, "0 0 \n"); fprintf(fill7skew, "0 0 \n"); fprintf(fill8norm, "0 0 \n"); fprintf(fill8skew, "0 0 \n");
	fprintf(fill9norm, "0 0 \n"); fprintf(fill9skew, "0 0 \n"); fprintf(fill10norm, "0 0 \n"); fprintf(fill10skew, "0 0 \n");
	
	pmax = qxmax*maxorder_s;
	if(qzmax > qxmax) pmax = qzmax*maxorder_s;
	pmax = supersym*(1. + floor(pmax/(supersym)));	
	incr = supersym;
	for(n = 0; n <= maxorder_s; n++) {
		for(m = -1*maxorder_s; m <= maxorder_s; m++) {
			for(p = -pmax; p <= pmax; p += incr) {
				order = n + abs(m);
				if(order <= maxorder_s) {
					if(m == 0) {
						if(order == 1) {
							for(i = 0; i < npts; i++) fprintf(fill2norm, "%lf %lf %i %i\n", 1.*p/n, i*(qzmax-qzmin)/(npts - 1) + qzmin, m, n);
							fprintf(fill2norm, "\n");
						}
						if(order == 2) {
							for(i = 0; i < npts; i++) fprintf(fill4norm, "%lf %lf %i %i\n", 1.*p/n, i*(qzmax-qzmin)/(npts - 1) + qzmin, m, n);
							fprintf(fill4norm, "\n");
						}
						if(order == 3) {
							for(i = 0; i < npts; i++) fprintf(fill6norm, "%lf %lf %i %i\n", 1.*p/n, i*(qzmax-qzmin)/(npts - 1) + qzmin, m, n);
							fprintf(fill6norm, "\n");
						}
						if(order == 4) {
							for(i = 0; i < npts; i++) fprintf(fill8norm, "%lf %lf %i %i\n", 1.*p/n, i*(qzmax-qzmin)/(npts - 1) + qzmin, m, n);
							fprintf(fill8norm, "\n");
						}
						if(order == 5) {
							for(i = 0; i < npts; i++) fprintf(fill10norm, "%lf %lf %i %i\n", 1.*p/n, i*(qzmax-qzmin)/(npts - 1) + qzmin, m, n);
							fprintf(fill10norm, "\n");
						}
					}
					else {
						if( (m % 2) == 0) {
							if(order == 1) {
								for(i = 0; i < npts; i++) fprintf(fill2norm, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill2norm, "\n");
							}
							if(order == 2) {
								for(i = 0; i < npts; i++) fprintf(fill4norm, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill4norm, "\n");
							}
							if(order == 3) {
								for(i = 0; i < npts; i++) fprintf(fill6norm, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill6norm, "\n");
							}
							if(order == 4) {
								for(i = 0; i < npts; i++) fprintf(fill8norm, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill8norm, "\n");
							}
							if(order == 5) {
								for(i = 0; i < npts; i++) fprintf(fill10norm, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill10norm, "\n");
							}
						}
						else {
							if(order == 1) {
								for(i = 0; i < npts; i++) fprintf(fill2skew, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill2skew, "\n");
							}
							if(order == 2) {
								for(i = 0; i < npts; i++) fprintf(fill4skew, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill4skew, "\n");
							}
							if(order == 3) {
								for(i = 0; i < npts; i++) fprintf(fill6skew, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill6skew, "\n");
							}
							if(order == 4) {
								for(i = 0; i < npts; i++) fprintf(fill8skew, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill8skew, "\n");
							}
							if(order == 5) {
								for(i = 0; i < npts; i++) fprintf(fill10skew, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill10skew, "\n");
							}
						}
					}
				}
			}
		}
	}
	
	pmax = qxmax*maxorder_ns;
	if(qzmax > qxmax) pmax = qzmax*maxorder_ns;
	incr = 1;	
	for(n = 0; n <= maxorder_ns; n++) {
		for(m = -1*maxorder_ns; m <= maxorder_ns; m++) {
			for(p = -pmax; p <= pmax; p += incr) {
				order = n + abs(m);
				if(order <= maxorder_ns) {
					if(m == 0) {
						if(order == 1) {
							for(i = 0; i < npts; i++) fprintf(fill1norm, "%lf %lf %i %i\n", 1.*p/n, i*(qzmax-qzmin)/(npts - 1) + qzmin, m, n);
							fprintf(fill1norm, "\n");
						}
						if(order == 2) {
							for(i = 0; i < npts; i++) fprintf(fill3norm, "%lf %lf %i %i\n", 1.*p/n, i*(qzmax-qzmin)/(npts - 1) + qzmin, m, n);
							fprintf(fill3norm, "\n");
						}
						if(order == 3) {
							for(i = 0; i < npts; i++) fprintf(fill5norm, "%lf %lf %i %i\n", 1.*p/n, i*(qzmax-qzmin)/(npts - 1) + qzmin, m, n);
							fprintf(fill5norm, "\n");
						}
						if(order == 4) {
							for(i = 0; i < npts; i++) fprintf(fill7norm, "%lf %lf %i %i\n", 1.*p/n, i*(qzmax-qzmin)/(npts - 1) + qzmin, m, n);
							fprintf(fill7norm, "\n");
						}
						if(order == 5) {
							for(i = 0; i < npts; i++) fprintf(fill9norm, "%lf %lf %i %i\n", 1.*p/n, i*(qzmax-qzmin)/(npts - 1) + qzmin, m, n);
							fprintf(fill9norm, "\n");
						}
					}
					
					else {
						if( (m % 2) == 0) {
							if(order == 1) {
								for(i = 0; i < npts; i++) fprintf(fill1norm, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill1norm, "\n");
							}
							if(order == 2) {
								for(i = 0; i < npts; i++) fprintf(fill3norm, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill3norm, "\n");
							}
							if(order == 3) {
								for(i = 0; i < npts; i++) fprintf(fill5norm, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill5norm, "\n");
							}
							if(order == 4) {
								for(i = 0; i < npts; i++) fprintf(fill7norm, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill7norm, "\n");
							}
							if(order == 5) {
								for(i = 0; i < npts; i++) fprintf(fill9norm, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill9norm, "\n");
							}
						}
						else {
							if(order == 1) {
								for(i = 0; i < npts; i++) fprintf(fill1skew, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill1skew, "\n");
							}
							if(order == 2) {
								for(i = 0; i < npts; i++) fprintf(fill3skew, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill3skew, "\n");
							}
							if(order == 3) {
								for(i = 0; i < npts; i++) fprintf(fill5skew, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill5skew, "\n");
							}
							if(order == 4) {
								for(i = 0; i < npts; i++) fprintf(fill7skew, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill7skew, "\n");
							}
							if(order == 5) {
								for(i = 0; i < npts; i++) fprintf(fill9skew, "%lf %lf %i %i\n", qxmin + 1.*i*(qxmax-qxmin)/(npts - 1), -1.*n/m*(qxmin + 1.*i*(qxmax-qxmin)/(npts - 1)) + 1.*p/m, m, n);
								fprintf(fill9skew, "\n");
							}
						}
					}
				}
			}
		}
	}
	
	fclose(fill1norm); fclose(fill2norm); fclose(fill3norm); fclose(fill4norm); fclose(fill5norm);
	fclose(fill6norm); fclose(fill7norm); fclose(fill8norm); fclose(fill9norm); fclose(fill10norm);
	fclose(fill1skew); fclose(fill2skew); fclose(fill3skew); fclose(fill4skew); fclose(fill5skew); 
	fclose(fill6skew); fclose(fill7skew); fclose(fill8skew); fclose(fill9skew); fclose(fill10skew);
	
	char xrange[50], yrange[50], setoption[200];
	sprintf(xrange, "[%le:%le]", qxmin,qxmax);
	sprintf(yrange, "[%le:%le]", qzmin,qzmax);
	//xtics = (qxmax - qxmin)/5.;
	//ytics = (qzmax - qzmin)/5.;
	xtics = 0.5;
	ytics = 0.5;
	sprintf(setoption, "sample 500\nset size ratio -1\nset xtics %f offset 0,0\n set mxtics 5\nset ytics %f offset 0,0\n set mytics 5\n", xtics, ytics);
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, "Q_x", "Q_z", NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	fprintf(gp,"unset key\n");
	if(output_name != NULL) {
		gnuplot_postscript(gp, output_name);
		if(doyouskew == YES) {
			gnuplot2d_plot(gp, "nonstruct_dec_skew", "1", "2",  "lines dt 2 lw 1 lc 3", NULL, YES, YES, NO);
			gnuplot2d_plot(gp, "struct_dec_skew", "1", "2",     "lines dt 2 lw 4 lc 3", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "nonstruct_oct_skew" , "1", "2", "lines dt 2 lw 1 lc 1", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "struct_oct_skew" , "1", "2",    "lines dt 2 lw 4 lc 1", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "nonstruct_sext_skew", "1", "2", "lines dt 2 lw 1 lc 6", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "struct_sext_skew", "1", "2",    "lines dt 2 lw 4 lc 6", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "nonstruct_quad_skew", "1", "2", "lines dt 2 lw 1 lc 2", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "struct_quad_skew", "1", "2",    "lines dt 2 lw 4 lc 2", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "nonstruct_dip_skew" , "1", "2", "lines dt 2 lw 1 lc 7", NULL, YES, NO, NO);
			if(doyounorm == YES || textfilename!= NULL) gnuplot2d_plot(gp, "struct_dip_skew" , "1", "2", "lines dt 2 lw 4 lc 7", NULL, YES, NO, NO);
			else gnuplot2d_plot(gp, "struct_dip_skew" , "1", "2", "lines dt 2 lw 4 lc 7", NULL, YES, NO, YES);
		}
		if(doyounorm == YES) {
			if(doyouskew == YES) gnuplot2d_plot(gp, "nonstruct_dec_norm", "1", "2",  "lines dt 1 lw 1 lc 3", NULL, YES, NO, NO);
			else gnuplot2d_plot(gp, "nonstruct_dec_norm", "1", "2",  "lines dt 1 lw 1 lc 3", NULL, YES, YES, NO);
			gnuplot2d_plot(gp, "struct_dec_norm", "1", "2",     "lines dt 1 lw 8 lc 3", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "nonstruct_oct_norm" , "1", "2", "lines dt 1 lw 1 lc 1", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "struct_oct_norm" , "1", "2",    "lines dt 1 lw 8 lc 1", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "nonstruct_sext_norm", "1", "2", "lines dt 1 lw 1 lc 6", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "struct_sext_norm", "1", "2",    "lines dt 1 lw 8 lc 6", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "nonstruct_quad_norm", "1", "2", "lines dt 1 lw 1 lc 2", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "struct_quad_norm", "1", "2",    "lines dt 1 lw 8 lc 2", NULL, YES, NO, NO);
			gnuplot2d_plot(gp, "nonstruct_dip_norm" , "1", "2", "lines dt 1 lw 1 lc 7", NULL, YES, NO, NO);
			if(textfilename!= NULL) gnuplot2d_plot(gp, "struct_dip_norm" , "1", "2", "lines dt 1 lw 8 lc 7", NULL, YES, NO, NO);
			else gnuplot2d_plot(gp, "struct_dip_norm" , "1", "2", "lines dt 1 lw 8 lc 7", NULL, YES, NO, YES);
		}
		if(textfilename!= NULL) {
			if(doyouskew == YES || doyounorm == YES) gnuplot2d_plot(gp, textfilename, "2", "3", "linespoints ps 1 pt 2 linecolor 'orange'", NULL, YES, NO, NO);
			else gnuplot2d_plot(gp, textfilename, "2", "3", "linespoints ps 1 pt 2 linecolor 'orange'", NULL, YES, YES, NO);
			gnuplot2d_plot(gp, textfilename, "4", "5", "linespoints ps 1 pt 2 linecolor 'orange'", NULL, YES, NO, YES);
		}
	}
	gnuplot_terminal(gp);
	if(doyouskew == YES) {
		gnuplot2d_plot(gp, "nonstruct_dec_skew", "1", "2",  "lines dt 2 lw 1 lc 3", NULL, YES, YES, NO);
		gnuplot2d_plot(gp, "struct_dec_skew", "1", "2",     "lines dt 2 lw 4 lc 3", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "nonstruct_oct_skew" , "1", "2", "lines dt 2 lw 1 lc 1", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "struct_oct_skew" , "1", "2",    "lines dt 2 lw 4 lc 1", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "nonstruct_sext_skew", "1", "2", "lines dt 2 lw 1 lc 6", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "struct_sext_skew", "1", "2",    "lines dt 2 lw 4 lc 6", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "nonstruct_quad_skew", "1", "2", "lines dt 2 lw 1 lc 2", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "struct_quad_skew", "1", "2",    "lines dt 2 lw 4 lc 2", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "nonstruct_dip_skew" , "1", "2", "lines dt 2 lw 1 lc 7", NULL, YES, NO, NO);
		if(doyounorm == YES || textfilename!= NULL) gnuplot2d_plot(gp, "struct_dip_skew" , "1", "2", "lines dt 2 lw 4 lc 7", NULL, YES, NO, NO);
		else gnuplot2d_plot(gp, "struct_dip_skew" , "1", "2", "lines dt 2 lw 4 lc 7", NULL, YES, NO, YES);
	}
	if(doyounorm == YES) {
		if(doyouskew == YES) gnuplot2d_plot(gp, "nonstruct_dec_norm", "1", "2",  "lines dt 1 lw 1 lc 3", NULL, YES, NO, NO);
		else gnuplot2d_plot(gp, "nonstruct_dec_norm", "1", "2",  "lines dt 1 lw 1 lc 3", NULL, YES, YES, NO);
		gnuplot2d_plot(gp, "struct_dec_norm", "1", "2",     "lines dt 1 lw 8 lc 3", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "nonstruct_oct_norm" , "1", "2", "lines dt 1 lw 1 lc 1", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "struct_oct_norm" , "1", "2",    "lines dt 1 lw 8 lc 1", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "nonstruct_sext_norm", "1", "2", "lines dt 1 lw 1 lc 6", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "struct_sext_norm", "1", "2",    "lines dt 1 lw 8 lc 6", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "nonstruct_quad_norm", "1", "2", "lines dt 1 lw 1 lc 2", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "struct_quad_norm", "1", "2",    "lines dt 1 lw 8 lc 2", NULL, YES, NO, NO);
		gnuplot2d_plot(gp, "nonstruct_dip_norm" , "1", "2", "lines dt 1 lw 1 lc 7", NULL, YES, NO, NO);
		if(textfilename!= NULL) gnuplot2d_plot(gp, "struct_dip_norm" , "1", "2", "lines dt 1 lw 8 lc 7", NULL, YES, NO, NO);
		else gnuplot2d_plot(gp, "struct_dip_norm" , "1", "2", "lines dt 1 lw 8 lc 7", NULL, YES, NO, YES);
	}
	if(textfilename!= NULL) {
		if(doyouskew == YES || doyounorm == YES) gnuplot2d_plot(gp, textfilename, "2", "3", "linespoints ps 1 pt 2 linecolor 'orange'", NULL, YES, NO, NO);
		else gnuplot2d_plot(gp, textfilename, "2", "3", "linespoints ps 1 pt 2 linecolor 'orange'", NULL, YES, YES, NO);
		gnuplot2d_plot(gp, textfilename, "4", "5", "linespoints ps 1 pt 2 linecolor 'orange'", NULL, YES, NO, YES);
	}
	gnuplot_end(gp, output_name);
	remove("nonstruct_dec_skew"); remove("nonstruct_dec_norm"); remove("nonstruct_oct_skew"); remove("nonstruct_oct_norm");
	remove("nonstruct_sext_skew"); remove("nonstruct_sext_norm"); remove("nonstruct_quad_skew"); remove("nonstruct_quad_norm");
	remove("nonstruct_dip_skew"); remove("nonstruct_dip_norm"); remove("struct_dec_skew"); remove("struct_dec_norm");
	remove("struct_oct_skew"); remove("struct_oct_norm"); remove("struct_sext_skew"); remove("struct_sext_norm");
	remove("struct_quad_skew"); remove("struct_quad_norm"); remove("struct_dip_skew"); remove("struct_dip_norm");
}

extern void plotfunction(char *function, char *xlabel, char *ylabel, char *xrange, char *yrange, char *psfilename, char *title, char *setoption)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, NULL, NULL, xrange, yrange, NULL, NULL, setoption);
	if(title == NULL) fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		if(title == NULL) fprintf(gp,"plot %s\n", function);
		else fprintf(gp,"plot %s title '%s'\n", function, title);
	}
	gnuplot_terminal(gp);	
	if(title == NULL) fprintf(gp,"plot %s\n", function);
	else fprintf(gp,"plot %s title '%s'\n", function, title);
	gnuplot_end(gp, psfilename);
}

extern void gnuplot_3d_scatered_points(char *txtfilename, char *xcolumn, char *ycolumn, char *cbcolumn, char *xlabel, char *ylabel, char *cblabel, char *xrange, char *yrange, char *psfilename, char *setoption, double dens_max)
{
	FILE *gp=gnuplot_start();
	gnuplot_set(gp, xlabel, ylabel, NULL, cblabel, NULL, xrange, yrange, NULL, NULL, setoption);
	gnuplot_palette(gp, 0, dens_max);
	fprintf(gp,"unset key\n");
	if(psfilename != NULL) {
		gnuplot_postscript(gp, psfilename);
		gnuplot3d_plot(gp, txtfilename, xcolumn, ycolumn, cbcolumn, "points pt 7 ps 3 linecolor palette", NULL, YES, YES);
	}
	gnuplot_terminal(gp);	
	gnuplot3d_plot(gp, txtfilename, xcolumn, ycolumn, cbcolumn, "points pt 7 ps 3 linecolor palette", NULL, YES, YES);
	gnuplot_end(gp, psfilename);
}

	// ************************************************************************************ //
	//									Heat maps functions									//
	// ************************************************************************************ //


extern void compute_fieldheatmap(char *filename_prefix, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int),
	double r0, double rmax, int nbr, double th0, double thmax, int nbth, double z0, double zmax, int nbz, int doyouradial)
{
	char namex[300], namey[300], namez[300];
	int i,j,k;
	double x,y,z,bxtemp,bytemp,bx,by,bz,r,th, rstep,thstep,zstep, w_coor;
	FILE *wfilex, *wfiley, *wfilez;
	if(doyouradial==YES) {
		sprintf(namex,"%s_br.dat", filename_prefix);
		sprintf(namey,"%s_bth.dat", filename_prefix);
	}
	else {
		sprintf(namex,"%s_bx.dat", filename_prefix);
		sprintf(namey,"%s_by.dat", filename_prefix);
	}
	wfilex=fopen(namex, "w");
	wfiley=fopen(namey, "w");
	sprintf(namez,"%s_bz.dat", filename_prefix);
	wfilez=fopen(namez, "w");
	
	if(nbr <= 1 && nbz <= 1) errorstop("heatmap not possible, only 1 dimension is scanned!");
	if(nbr != 1 && nbz != 1 && nbth != 1) errorstop("heatmap not possible, 3 dimensions scanned");
	//if(nbth <= 1) errorstop("map not possible, longitudinal dimension not scanned");
	
	zstep = comp_step(z0, zmax, nbz, NO);
	rstep = comp_step(r0, rmax, nbr, NO);
	thstep = comp_step(th0, thmax, nbth, NO);
	
	if(doyouradial==YES) printf("rstep=%le[m], thstep=%le[deg], zstep=%le[m]\n",rstep,thstep*180./PI,zstep);
	else printf("xstep=%le[m], ystep=%le[m], zstep=%le[m]\n",rstep,thstep,zstep);
	
	for(j=0;j<nbr;j++) {
		r = r0 + j*rstep;
		//printf("r = %le\n", r);
		for(i=0;i<nbz;i++) {
			z = z0 + i*zstep;
			//printf("z=%le\n",z);
			for(k=0;k<nbth;k++) {
				th = th0 + k*thstep;
				//printf("th = %le\n",th*180./PI);
				if(doyouradial==YES) {
					convert_polar_to_cart(r, th, &x, &y);
					//x = r*cos(th);
					//y = r*sin(th);
				}
				else {
					x = r;
					y = th;
				}
				if(get_bfield(x, y, z, &bxtemp, &bytemp, &bz, cell, add_contribution_comp)!=ALIVE) {
					//errorstop("field not alive\n");
					bx = 0.;
					by = 0.;
					bz = 0.;
				}
				if(nbz==1) w_coor = x;
				else {
					w_coor = z;
					if(doyouradial==YES) y = th*180./PI;
				}
				if(doyouradial==YES) {
					bx = bxtemp*cos(th) + bytemp*sin(th); //br
					by = -bxtemp*sin(th) + bytemp*cos(th); //bth
				}
				else {
					bx = bxtemp;
					by = bytemp;
				}
				fprintf(wfilex,"%le\t%le\t%le\n", y, w_coor, bx);
				fprintf(wfiley,"%le\t%le\t%le\n", y, w_coor, by);
				fprintf(wfilez,"%le\t%le\t%le\n", y, w_coor, bz);
			}
			fprintf(wfilex,"\n"); // to build file to plot easyplot3dmap
			fprintf(wfiley,"\n"); // to build file to plot easyplot3dmap
			fprintf(wfilez,"\n"); // to build file to plot easyplot3dmap
		}
	}
	fclose(wfilex);
	fclose(wfiley);
	fclose(wfilez);
}

extern void compute_fieldheatmap_btot(char *filename, struct Cell *cell, void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int),
	double x0, double xmax, int nbx, double y0, double ymax, int nby, double z0, double zmax, int nbz)
{
	int i,j,k;
	double x,y,z,bxtemp,bytemp,bx,by,bz,xstep,ystep,zstep, btot,w_coor;
	FILE *wfile;
	
	wfile=fopen(filename, "w");
	
		
	zstep = comp_step(z0, zmax, nbz, NO);
	xstep = comp_step(x0, xmax, nbx, NO);
	ystep = comp_step(y0, ymax, nby, NO);
	
	printf("xstep=%le[m], ystep=%le[m], zstep=%le[m]\n",xstep,ystep,zstep);
	
	for(j=0;j<nbx;j++) {
		x = x0 + j*xstep;
		for(i=0;i<nbz;i++) {
			z = z0 + i*zstep;
			for(k=0;k<nby;k++) {
				y = y0 + k*ystep;
				
				if(get_bfield(x, y, z, &bxtemp, &bytemp, &bz, cell, add_contribution_comp)!=ALIVE) {
					//errorstop("field not alive\n");
					bx = 0.;
					by = 0.;
					bz = 0.;
				}
				if(nbz==1) w_coor = x;
				else w_coor = z;
				btot = sqrt(bx*bx+by*by+bz*bz);
				fprintf(wfile,"%le\t%le\t%le\n", y, w_coor, btot);
			}
			fprintf(wfile,"\n"); // to build file to plot easyplot3dmap
		}
	}
	fclose(wfile);
}

extern void compute_fieldheatmap_difference(char *filename_prefix, struct Cell *cell1, void(*add_contribution_comp1)(double,double,double,double*,double*,double*,struct Cell*,int), struct Cell *cell2, void(*add_contribution_comp2)(double,double,double,double*,double*,double*,struct Cell*,int), 
	double r0, double rmax, int nbr, double th0, double thmax, int nbth, double z0, double zmax, int nbz, int doyouradial)
{
	char namex[300], namey[300], namez[300];
	int i,j,k;
	double x,y,z,bx1temp,by1temp,bx2temp,by2temp,bx1,by1,bz1,bx2,by2,bz2,r,th, rstep,thstep,zstep, w_coor;
	//double residu = 1.e-8;
	FILE *wfilex, *wfiley, *wfilez;
	
	if(doyouradial==YES) {
		//sprintf(namex,"%s_bxshinji.dat", filename_prefix);
		//sprintf(namey,"%s_byshinji.dat", filename_prefix);
		sprintf(namex,"%s_diff_br.dat", filename_prefix);
		sprintf(namey,"%s_diff_bth.dat", filename_prefix);
	}
	else {
		sprintf(namex,"%s_diff_bx.dat", filename_prefix);
		sprintf(namey,"%s_diff_by.dat", filename_prefix);
	}
	wfilex=fopen(namex, "w");
	wfiley=fopen(namey, "w");
	sprintf(namez,"%s_diff_bz.dat", filename_prefix);
	wfilez=fopen(namez, "w");
	
	if(nbr <= 1 && nbz <= 1) errorstop("map not possible, only 1 dimension is scanned!");
	if(nbr != 1 && nbz != 1 && nbth != 1) errorstop("map not possible, 3 dimensions scanned");
	//if(nbth <= 1) errorstop("map not possible, longitudinal dimension not scanned");
	
	zstep = comp_step(z0, zmax, nbz, NO);
	rstep = comp_step(r0, rmax, nbr, NO);
	thstep = comp_step(th0, thmax, nbth, NO);
	
	if(doyouradial==YES) printf("rstep=%le[m], thstep=%le[deg], zstep=%le[m]\n",rstep,thstep*180./PI,zstep);
	else printf("xstep=%le[m], ystep=%le[m], zstep=%le[m]\n",rstep,thstep,zstep);
	
	for(j=0;j<nbr;j++) {
		r = r0 + j*rstep;
		for(i=0;i<nbz;i++) {
			z = z0 + i*zstep;
			for(k=0;k<nbth;k++) {
				th = k*thstep;
				//th = thmax - k*thstep;
				if(doyouradial==YES) {
					convert_polar_to_cart(r, th, &x, &y);
					//x = r*cos(th);
					//y = r*sin(th);
				}
				else {
					x = r;
					y = th;
				}
				if(get_bfield(x, y, z, &bx1temp, &by1temp, &bz1, cell1, add_contribution_comp1)!=ALIVE) {
					//errorstop("field not alive\n");
					bx1 = 0.;
					by1 = 0.;
					bz1 = 0.;
				}
				if(doyouradial==YES) {
					//bx1 = bx1temp*cos(18*PI/180.) + bytemp*sin(18*PI/180.); //br
					//by1 = -bx1temp*sin(18*PI/180.) + bytemp*cos(18*PI/180.); 
					bx1 = bx1temp*cos(th) + by1temp*sin(th); //br
					by1 = -bx1temp*sin(th) + by1temp*cos(th); //bth
				}
				else {
					//bx = bxtemp*cos(18*PI/180.) + bytemp*sin(18*PI/180.); //br
					//by = -bxtemp*sin(18*PI/180.) + bytemp*cos(18*PI/180.); 
					bx1 = bx1temp;
					by1 = by1temp;
				}
				if(get_bfield(x, y, z, &bx2temp, &by2temp, &bz2, cell2, add_contribution_comp2)!=ALIVE) {
					//errorstop("field not alive\n");
					bx2 = 0.;
					by2 = 0.;
					bz2 = 0.;
				}
				if(nbz==1) w_coor = x;
				else {
					w_coor = z;
					if(doyouradial==YES) y = th*180./PI;
				}
				if(doyouradial==YES) {
					//bx1 = bx1temp*cos(18*PI/180.) + bytemp*sin(18*PI/180.); //br
					//by1 = -bx1temp*sin(18*PI/180.) + bytemp*cos(18*PI/180.); 
					bx2 = bx2temp*cos(th) + by2temp*sin(th); //br
					by2 = -bx2temp*sin(th) + by2temp*cos(th); //bth
				}
				else {
					//bx = bxtemp*cos(18*PI/180.) + bytemp*sin(18*PI/180.); //br
					//by = -bxtemp*sin(18*PI/180.) + bytemp*cos(18*PI/180.); 
					bx2 = bx2temp;
					by2 = by2temp;
				}
				printf("(%lf, %lf, %lf)\n",x,y,z);
				fprintf(wfilex,"%le\t%le\t%le\n", y, w_coor, bx1-bx2);
				fprintf(wfiley,"%le\t%le\t%le\n", y, w_coor, by1-by2);
				fprintf(wfilez,"%le\t%le\t%le\n", y, w_coor, bz1-bz2);
				//if(fabs(bx1)>residu) fprintf(wfilex,"%le\t%le\t%le\n", y, w_coor, (bx1-bx2)/bx1);
				//else if(fabs(bx1-bx2)>residu) fprintf(wfilex,"%le\t%le\t%le\n", y, w_coor, (bx1-bx2)/bx2);
				//else fprintf(wfilex,"%le\t%le\t0\n", y, w_coor);
				//if(by1>residu) fprintf(wfiley,"%le\t%le\t%le\n", y, w_coor, (by1-by2)/by1);
				//else if(fabs(by1-by2)>residu) fprintf(wfiley,"%le\t%le\t%le\n", y, w_coor, (by1-by2)/by2);
				//else fprintf(wfiley,"%le\t%le\t0\n", y, w_coor);
				//if(fabs(bz1)>residu) fprintf(wfilez,"%le\t%le\t%le\n", y, w_coor, (bz1-bz2)/bz1);
				//else if(fabs(by1-by2)>residu) fprintf(wfilez,"%le\t%le\t%le\n", y, w_coor, (bz1-bz2)/bz2);
				//else fprintf(wfilez,"%le\t%le\t0\n", y, w_coor);
			}
			fprintf(wfilex,"\n"); // to build file to plot easyplot3dmap
			fprintf(wfiley,"\n"); // to build file to plot easyplot3dmap
			fprintf(wfilez,"\n"); // to build file to plot easyplot3dmap
		}
	}
	fclose(wfilex);
	fclose(wfiley);
	fclose(wfilez);
}
