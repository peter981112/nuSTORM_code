/*
 *  m_alloc.h
 *  Fixfield
 *
 *  Copyright 2009 Kyoto University. All rights reserved.
 *
 */

#ifndef M_ALLOC 
#define M_ALLOC

#include "constants.h"
#include "common.h"



#endif
