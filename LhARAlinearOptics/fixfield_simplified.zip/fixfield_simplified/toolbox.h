/*
 *  toolbox.h
 *  Fixfield
 *
 *  Copyright 2009 Kyoto University. All rights reserved.
 *
 */

#ifndef TOOLBOX 
#define TOOLBOX

#include "constants.h"
#include "common.h"


#endif
