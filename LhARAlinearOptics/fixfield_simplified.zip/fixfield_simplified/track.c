/*
 *  track.c
 *  Fixfield
 *
 *  Copyright 2009 Kyoto University. All rights reserved.
 *
 */

#include "track.h"

// ************************************************************************************ //
///////////  FIND CLOSED ORBITS PROCEDURES  ////////////////////////////
// ************************************************************************************ //

extern int find_closed_orbite_x(struct Particle *part, double *x_clo, double eps_clo, struct Lattice *latt, int doyouprintf)
{
	int i, n;
	double xmin, xmax, eps;
	struct Particle test_part;
	test_part = *part;
	test_part.hat = -2;	// no acceleration, no output
	eps  = 1.;
	n	 = 0.;
	
	while (eps > eps_clo) {
		xmin = xmax = test_part.x;
		test_part = *part;
		test_part.hat = -2;	// no acceleration, no output
		test_part.x = xmin;
		
		for(i = 0; i < FCLO_CROSS; i++) {
			part_cross_latt(&test_part, latt,NULL, NULL);
			xmax = MAX(test_part.x,xmax);
			xmin = MIN(test_part.x,xmin);
			if(test_part.status != ALIVE) break;
		}
		
		test_part.x = (xmin+xmax)/2.;
		eps = xmax - xmin;
		if(doyouprintf == YES) {
			CLRSCR();
			//printf("%c[2K\r", 33);
			printf("try # %i, eps = %le, xmin = %lf, xmax = %lf", n, eps, xmin, xmax);
			fflush(stdout);
		}
		if(n > FCLO_TRIES || test_part.status != ALIVE) {
			if(doyouprintf == YES) printf("\n!!! Cannot find closed orbit, eps_clo = %le [m]!!!, part. status = %i\n", eps, test_part.status);
			return FALSE;
		}
		n++;
	}
	*x_clo = test_part.x;
	if(doyouprintf == YES) {
		//if(print_color==YES) COLOR("1;34");
		printf("\nClosed orbit found: x_clo = %.8f [m], xprime_clo forced to be 0, \neps = %le [m]\n", *x_clo, eps);
		//if(print_color==YES) COLOR("0");
	}
	return TRUE;
}

extern int find_closed_orbite_xz(struct Particle *part, double *x_clo, double *z_clo, double eps_clo, struct Lattice *latt, int doyouprintf)
{
	int i, n;
	double xmin, xmax, zmin, zmax, eps;
	struct Particle test_part;
	test_part = *part;
	test_part.hat = -2;	// no acceleration, no output
	eps  = 1.;
	n	 = 0.;
	
	while (eps > eps_clo) {
		xmin = xmax = test_part.x;
		zmin = zmax = test_part.z;
		test_part = *part;
		test_part.hat = -2;	// no acceleration, no output
		test_part.x = xmin;
		test_part.z = zmin;
		
		for(i = 0; i < FCLO_CROSS; i++) {
			part_cross_latt(&test_part, latt,NULL, NULL);
			xmax = MAX(test_part.x,xmax);
			xmin = MIN(test_part.x,xmin);
			zmax = MAX(test_part.z,zmax);
			zmin = MIN(test_part.z,zmin);
			if(test_part.status != ALIVE) break;
		}
		
		test_part.x = (xmin+xmax)/2.; 
		test_part.z = (zmin+zmax)/2.;
		eps = sqrt((xmax - xmin)*(xmax - xmin) + (zmax - zmin)*(zmax - zmin));
		//eps = zmax-zmin;
		if(doyouprintf == YES) {
			//CLRSCR();
			//printf("%c[2K\r", 33);
			printf("try # %i, eps = %le, x:min,max: (%lf, %lf), z:min,max: (%lf, %lf)", n, eps, xmin, xmax, zmin, zmax);
			printf("\n");
			//fflush(stdout);
		}
		if(n > FCLO_TRIES || test_part.status != ALIVE) {
			if(doyouprintf == YES) printf("\n!!! Cannot find closed orbit, eps_clo = %le [m]!!!, part. status = %i\n", eps, test_part.status);
			return FALSE;
		}
		n++;
	}
	*x_clo = test_part.x;
	*z_clo = test_part.z;
	if(doyouprintf == YES) {
		//if(print_color==YES) COLOR("1;34");
		printf("\nClosed orbit found: x_clo = %.8f [m], z_clo = %.8f [m], xprime_clo forced to be 0, \neps = %le [m]\n", *x_clo, *z_clo, eps);
		//if(print_color==YES) COLOR("0");
	}
	return TRUE;
}

extern int find_closed_orbite_xxp(struct Particle *part, double *x_clo, double *ux_clo, double *uy_clo, double eps_clo, struct Lattice *latt, int doyouprintf)
{
	int i, n;
	double xmin, xmax, uxmin, uxmax, utot_xy, eps;
	struct Particle test_part;
	//FILE *wfile;
	//wfile = fopen("data/closedorbit.dat", "w");
	
	test_part = *part;
	utot_xy = sqrt(part->ux*part->ux + part->uy*part->uy);
	test_part.hat = -2;	// no acceleration, no output
	eps  = 1.;
	n	 = 0.;
	while (eps > eps_clo) {
		xmin = xmax = test_part.x;
		uxmin = uxmax = test_part.ux;
		test_part = *part;
		test_part.hat = -2;	// no acceleration, no output
		test_part.x = xmin;
		test_part.ux = uxmin;
		test_part.uy = sqrt(utot_xy*utot_xy - uxmin*uxmin);
		for(i = 0; i < FCLO_CROSS; i++) {
			part_cross_latt(&test_part, latt,NULL, NULL);
			xmax = MAX(test_part.x, xmax);
			xmin = MIN(test_part.x,xmin);
			uxmax = MAX(test_part.ux, uxmax);
			uxmin = MIN(test_part.ux, uxmin);
			if(test_part.status != ALIVE) break;
		}
		
		test_part.x = (xmin+xmax)/2.;
		eps = sqrt((xmax - xmin)*(xmax - xmin) + (uxmax - uxmin)*(uxmax - uxmin));
		//eps = xmax - xmin;
		test_part.ux = (uxmin + uxmax)/2.;
		test_part.uy = sqrt(utot_xy*utot_xy - uxmin*uxmin);
		if(doyouprintf == YES) {
			CLRSCR();
			printf("try # %i, eps = %le, x = %lf, %lf, x' = %le, %le", n, eps, xmin, xmax, asin(uxmin)*180./PI, asin(uxmax)*180./PI);
			fflush(stdout);
			//fprintf(wfile, "try # %i, eps = %le, x = %lf, %lf, x' = %le, %le", n, eps, xmin, xmax, asin(uxmin)*180./PI, asin(uxmax)*180./PI);
		}
		else if(doyouprintf == 2) {
			printf("try # %i, eps = %le, x = %lf, %lf, x' = %le, %le\n", n, eps, xmin, xmax, asin(uxmin)*180./PI, asin(uxmax)*180./PI);
		}
		if(n > FCLO_TRIES || test_part.status != ALIVE) {
			if(doyouprintf == YES) printf("\n!!! Cannot find closed orbit, eps_clo = %le [m]!!!, part. status = %i\n", eps, test_part.status);
			//fclose(wfile);
			return FALSE;
		}
		n++;
	}
	*x_clo = test_part.x;
	*ux_clo = test_part.ux;
	*uy_clo = test_part.uy;
	if(doyouprintf == YES) {
		//if(print_color==YES) COLOR("1;34");
		printf("\nClosed orbit found: x_clo = %.10f [m], xprime_clo = %le [deg], \neps = %le [m]\n", *x_clo, atan(*ux_clo/(*uy_clo))*180./(PI), eps);
		//if(print_color==YES) COLOR("0");
	}
	return TRUE;
	//fclose(wfile);
	
}

extern int find_closed_orbite_xxp_zzp(struct Particle *part, double *x_clo, double *ux_clo, double *uy_clo, double *z_clo, double *uz_clo, double eps_clo, struct Lattice *latt, int doyouprintf)
{
	int i, n;
	double xmin, xmax, uxmin, uxmax, eps, zmin, zmax, uzmin, uzmax;
	struct Particle test_part;
	
	test_part = *part;
	//utot_xy = sqrt(part->ux*part->ux + part->uy*part->uy + part->uz*part->uz);
	test_part.hat = -2;	// no acceleration, no output
	eps  = 1.;
	n	 = 0.;
	
	while (eps > eps_clo) {
		xmin = xmax = test_part.x;
		uxmin = uxmax = test_part.ux;
		zmin = zmax = test_part.z;
		uzmin = uzmax = test_part.uz;
		test_part = *part;
		test_part.hat = -2;	// no acceleration, no output
		test_part.x = xmin;
		test_part.ux = uxmin;
		test_part.z = zmin;
		test_part.uz = uzmin;
		//test_part.uy = sqrt(utot_xy*utot_xy - uxmin*uxmin- uzmin*uzmin);
		test_part.uy = sqrt(1.0 - uxmin*uxmin- uzmin*uzmin);
		
		for(i = 0; i < FCLO_CROSS; i++) {
			part_cross_latt(&test_part,latt,NULL, NULL);
			xmax = MAX(test_part.x, xmax);
			xmin = MIN(test_part.x,xmin);
			uxmax = MAX(test_part.ux, uxmax);
			uxmin = MIN(test_part.ux, uxmin);
			zmax = MAX(test_part.z, zmax);
			zmin = MIN(test_part.z,zmin);
			uzmax = MAX(test_part.uz, uzmax);
			uzmin = MIN(test_part.uz, uzmin);
			if(test_part.status != ALIVE) break;
		}
		
		test_part.x = (xmin+xmax)/2.;
		//eps = xmax - xmin + zmax - zmin;
		eps = sqrt((xmax - xmin)*(xmax - xmin) + (zmax - zmin)*(zmax - zmin) + (uxmax - uxmin)*(uxmax - uxmin) + (uzmax - uzmin)*(uzmax - uzmin));
		//eps = fabs(xmax - xmin) + fabs(zmax - zmin) + (fabs(uxmax - uxmin) + fabs(uzmax - uzmin))/(test_part.uy);
		test_part.ux = (uxmin + uxmax)/2.;
		test_part.z = (zmin+zmax)/2.;
		test_part.uz = (uzmin+uzmax)/2.;
		test_part.uy = sqrt(1.0 - uxmin*uxmin-uzmin*uzmin);
		if(doyouprintf == YES) {
			CLRSCR();
			printf("try # %i, eps = %le, xmin = %lf, xmax = %lf, zmin = %lf, zmax = %lf", n, eps, xmin, xmax, zmin, zmax);
			fflush(stdout);
		}
		
		if(n > FCLO_TRIES || test_part.status != ALIVE) {
			if(doyouprintf == YES) printf("\n!!! Cannot find closed orbite, eps_clo = %le [m]!!!, part. status = %i\n", eps, test_part.status);
			return FALSE;
		}
		n++;
	}
	*x_clo = test_part.x;
	*ux_clo = test_part.ux;
	*uy_clo = test_part.uy;
	*z_clo = test_part.z;
	*uz_clo = test_part.uz;
	if(doyouprintf == YES) {
		//if(print_color==YES) COLOR("1;34");
		printf("\nClosed orbit found: x_clo = %.10f [m], xprime_clo = %.10e [deg], \nz_clo = %.10f [m], zprime_clo = %.10e [deg], eps = %le [m]\n", *x_clo, atan(*ux_clo/(*uy_clo))*180./(PI), *z_clo, atan(*uz_clo/(sqrt((*uy_clo)*(*uy_clo)+(*ux_clo)*(*ux_clo))))*180./(PI), eps);
		//print_part_para("test_part to find c.o.", &test_part);
		//if(print_color==YES) COLOR("0");
	}
	
	return TRUE;
}

//not used anywhere?
extern int find_co_ellipse(struct Particle *part, double *x_clo, double *z_clo, double *ux_clo, double *uy_clo, double *uz_clo, double eps_clo, int nb_points, struct Lattice *latt, int doyouprintf)
{
	int i, n, m[5], a[5];
	double utot_xy, eps, x[nb_points], ux[nb_points], z[nb_points], uz[nb_points], p[5], e[5], q[5], f[5];
	struct Particle test_part;
	
	for(i=0;i<5;i++) {
		p[i] = 0.;
		e[i] = 0.;
		m[i] = 1;
		q[i] = 0.;
		f[i] = 0.;
		a[i] = 1;
	}
	
	test_part = *part;
	utot_xy = sqrt(part->ux*part->ux + part->uy*part->uy);
	test_part.hat = -2;	// no acceleration, no output
	p[2] = test_part.x;
	p[3] = test_part.ux;
	q[2] = test_part.z;
	q[3] = test_part.uz;
	eps  = 1.;
	n	 = 0.;
	
	while (eps > eps_clo) {
		test_part = *part;
		test_part.hat = -2;	// no acceleration, no output
		test_part.x = p[2];
		test_part.ux = p[3];
		test_part.z = q[2];
		test_part.uz = q[3];
		if(fabs(test_part.z)<TINYLENGTH && fabs(test_part.uz)<TINYDIMLESS) test_part.uy = sqrt(utot_xy - p[3]*p[3]);
		else test_part.uy = sqrt(1. - p[3]*p[3] - q[3]*q[3]);
		for(i = 0; i < nb_points; i++) {
			part_cross_latt(&test_part, latt, NULL, NULL);
			x[i] = test_part.x;
			ux[i] = test_part.ux;
			z[i] = test_part.z;
			uz[i] = test_part.uz;
			if(test_part.status != ALIVE) break;
		}
		fit_ellipse1(&nb_points, x, ux, p);
		fit_ellipse2(&nb_points, x, ux, p, e, m);
		if(fabs(test_part.z)<TINYLENGTH && fabs(test_part.uz)<TINYDIMLESS) eps = fabs(test_part.x - p[2]);
		else {
			fit_ellipse1(&nb_points, z, uz, q);
			fit_ellipse2(&nb_points, z, uz, q, f, a);
			eps = fabs(test_part.x - p[2]) + fabs(test_part.z - q[2]);
		} 
		
		if(doyouprintf == YES) {
			CLRSCR();
			printf("try # %i, eps = %le, x = %lf, ux = %lf, z = %lf, uz = %lf", n, eps, p[2], p[3], q[2], q[3]);
			fflush(stdout);
		}
		if(n > FCLO_TRIES || test_part.status != ALIVE) {
			if(doyouprintf == YES) printf("\n!!! Cannot find closed orbit, eps_clo = %le [m]!!!, part. status = %i\n", eps, test_part.status);
			return FALSE;
		}
		n++;
	}
	*x_clo = test_part.x;
	*ux_clo = test_part.ux;
	*uy_clo = test_part.uy;
	if(fabs(test_part.z)<TINYLENGTH && fabs(test_part.uz)<TINYDIMLESS) {
		*z_clo = 0.;
		*uz_clo = 0.;
	}
	else {
		*z_clo = test_part.z;
		*uz_clo = test_part.uz;
	}
	
	if(doyouprintf == YES) {
		//if(print_color==YES) COLOR("1;34");
		printf("\nClosed orbit found: x_clo = %.8f [m], xprime_clo = %le [deg], z_clo = %.8f [m], zprime_clo = %le [deg], \neps = %le [m]\n", *x_clo, atan(*ux_clo/(*uy_clo))*180./(PI), *z_clo, atan(*uz_clo/(*uy_clo))*180./(PI), eps);
		//if(print_color==YES) COLOR("0");
	}
	return TRUE;
}

extern double fn_co_xxp(struct Lattice *latt, struct Particle *part, double x[], double betax)
{
	double xi[2], xf[2];
	struct Particle part_temp;
	part_temp = *part;
	part_temp.x  = x[0];
	part_temp.ux = x[1];
	xi[0] = part_temp.x;
	xi[1] = part_temp.ux;
	//printf("%le, %le\n",xi[0],xi[1]);
	part_cross_latt(&part_temp, latt, NULL, NULL);
	if(part_temp.status != ALIVE) errorstop("part killed while crossing latt");
	xf[0] = part_temp.x;
	xf[1] = part_temp.ux;
	return (xf[0]-xi[0])*(xf[0]-xi[0]) + betax*(xf[1]-xi[1])*(xf[1]-xi[1]);
}

extern void find_co_nelmin_xxp(struct Lattice *latt, struct Particle *part, double betax, double fn_co_xxp(struct Lattice*, struct Particle*, double x[], double), 
	int n, double xmin[], double *ynewlo, double reqmin, double step[], int konvge, int kcount, int *icount, int *numres, int *ifault, int doyouprintf)
{
	int i, ihi, ilo, j, jcount, l, nn;
	double ccoeff = 0.5, del, dn, dnn, ecoeff = 2.0, eps = 1.0, rcoeff = 1.0, rq, x, *y, y2star, ylo, ystar, z, *p, *p2star, *pbar, *pstar;
	
	//Check the input parameters.
	if(reqmin <= 0.0 || n < 1 || konvge < 1) {
		*ifault = 1;
		return;
	}
	
	double start[n];
	struct Particle part_temp;
	start[0] = part->x;
	start[1] = part->ux;
	
	p = (double *) malloc(n * (n + 1) * sizeof(double));
	pstar = (double *) malloc(n * sizeof(double));
	p2star = (double *) malloc(n * sizeof(double));
	pbar = (double *) malloc(n * sizeof(double));
	y = (double *) malloc((n + 1) * sizeof(double));
	
	*icount = 0;
	*numres = 0;
	
	jcount = konvge; 
	dn = (double) (n);
	nn = n + 1;
	dnn = (double) (nn);
	del = 1.0;
	rq = reqmin * dn;
	
	//Initial or restarted loop.
	
	for(;;) {
		for(i = 0; i < n; i++) p[i+n*n] = start[i];
		//y[n] = fn(start);
		part_temp = *part;
		y[n] = fn_co_xxp(latt, &part_temp, start, betax);
		*icount = *icount + 1;
	
		for(j = 0; j < n; j++) {
			x = start[j];
			start[j] = start[j] + step[j] * del;
			for(i = 0; i < n; i++) p[i+j*n] = start[i];
			//y[n] = fn(start);
			part_temp = *part;
			y[j] = fn_co_xxp(latt, &part_temp, start, betax);
			*icount = *icount + 1;
			start[j] = x;
		}
		//The simplex construction is complete.
		//Find highest and lowest Y values.	YNEWLO = Y(IHI) indicates
		//the vertex of the simplex to be replaced.
		ylo = y[0];
		ilo = 0;
		for(i = 1; i < nn; i++) {
			if(y[i] < ylo) {
				ylo = y[i];
				ilo = i;
			}
		}
		//CLRSCR();
		//printf("try # %i, ylo = %le, x=%le, ux=%le, z=%le, uz=%le\n", *icount, ylo, part_temp.x, part_temp.ux, part_temp.z, part_temp.uz);
		//fflush(stdout);
		//Inner loop.
		for(;;) {
			if(kcount <= *icount) break;
			*ynewlo = y[0];
			ihi = 0;
			for(i = 1; i < nn; i++) {
				if(*ynewlo < y[i]) {
					*ynewlo = y[i];
					ihi = i;
				}
			}
			if(doyouprintf==YES) {
				CLRSCR();
				//printf("try # %i, ynewlo = %le, x=%le, ux=%le, z=%le, uz=%le\n", *icount, *ynewlo, part_temp.x, part_temp.ux, part_temp.z, part_temp.uz);
				printf("try # %i, ynewlo = %le", *icount, *ynewlo);
				fflush(stdout);
				//printf("ynewlo=%le\n", *ynewlo);
			}
			
			//Calculate PBAR, the centroid of the simplex vertices
			//excepting the vertex with Y value YNEWLO.
			for(i = 0; i < n; i++) {
				z = 0.0;
				for(j = 0; j < nn; j++) z = z + p[i+j*n];
				z = z - p[i+ihi*n];	
				pbar[i] = z / dn;
			}
			//Reflection through the centroid.
			for(i = 0; i < n; i++) pstar[i] = pbar[i] + rcoeff * (pbar[i] - p[i+ihi*n]);
			//ystar = fn(pstar);
			part_temp = *part;
			ystar = fn_co_xxp(latt, &part_temp, pstar, betax);
			*icount = *icount + 1;
			//Successful reflection, so extension.
			if(ystar < ylo) {
				for(i = 0; i < n; i++) p2star[i] = pbar[i] + ecoeff * (pstar[i] - pbar[i]);
				//y2star = fn(p2star);
				part_temp = *part;
				y2star = fn_co_xxp(latt, &part_temp, p2star, betax);
				*icount = *icount + 1;
				//Check extension.
				if(ystar < y2star) {
					for(i = 0; i < n; i++) p[i+ihi*n] = pstar[i];
					y[ihi] = ystar;
				}
				//Retain extension or contraction.
				else {
					for(i = 0; i < n; i++) p[i+ihi*n] = p2star[i];
					y[ihi] = y2star;
				}
			}
			//No extension.
			else {
				l = 0;
				for(i = 0; i < nn; i++) if(ystar < y[i]) l = l + 1;
	
				if(l > 1) {
					for(i = 0; i < n; i++) p[i+ihi*n] = pstar[i];
					y[ihi] = ystar;
				}
				//Contraction on the Y(IHI) side of the centroid.
				else if(l == 0) {
					for(i = 0; i < n; i++) p2star[i] = pbar[i] + ccoeff * (p[i+ihi*n] - pbar[i]);
					//y2star = fn(p2star);
					part_temp = *part;
					y2star = fn_co_xxp(latt, &part_temp, p2star, betax);
					*icount = *icount + 1;
					//Contract the whole simplex.
					if(y[ihi] < y2star) {
						for(j = 0; j < nn; j++) {
							for(i = 0; i < n; i++) {
								p[i+j*n] = (p[i+j*n] + p[i+ilo*n]) * 0.5;
								xmin[i] = p[i+j*n];
							}
							//y[j] = fn(xmin);
							part_temp = *part;
							y[j] = fn_co_xxp(latt, &part_temp, xmin, betax);
							*icount = *icount + 1;
						}
						ylo = y[0];
						ilo = 0;
						for(i = 1; i < nn; i++) {
							if(y[i] < ylo) {
								ylo = y[i];
								ilo = i;
							}
						}
						continue;
					}
					//Retain contraction.
					else {
						for(i = 0; i < n; i++) p[i+ihi*n] = p2star[i];
						y[ihi] = y2star;
					}
				}
				//Contraction on the reflection side of the centroid.
				else if(l == 1) {
					for(i = 0; i < n; i++) p2star[i] = pbar[i] + ccoeff * (pstar[i] - pbar[i]);
					//y2star = fn(p2star);
					part_temp = *part;
					y2star = fn_co_xxp(latt, &part_temp, p2star, betax);
					*icount = *icount + 1;
					//Retain reflection?
					if(y2star <= ystar) {
						for(i = 0; i < n; i++) p[i+ihi*n] = p2star[i];
						y[ihi] = y2star;
					}
					else {
						for(i = 0; i < n; i++) p[i+ihi*n] = pstar[i];
						y[ihi] = ystar;
					}
				}
			}
			//Check if YLO improved.
			if(y[ihi] < ylo) {
				ylo = y[ihi];
				ilo = ihi;
			}
			jcount = jcount - 1;
	
			if(0 < jcount) continue;
			//Check to see if minimum reached.
			if(*icount <= kcount) {
				jcount = konvge;
				z = 0.0;
				for(i = 0; i < nn; i++) z = z + y[i];
				x = z / dnn;
	
				z = 0.0;
				for(i = 0; i < nn; i++) z = z + pow(y[i] - x, 2);
				if(z <= rq) break;
			}
		}
		//Factorial tests to check that YNEWLO is a local minimum.
		for(i = 0; i < n; i++) xmin[i] = p[i+ilo*n];
		*ynewlo = y[ilo];
		//CLRSCR();
		//printf("trys # %i, eps = %le\n", *icount, *ynewlo);
		//printf("trys # %i, ynewlo = %le, x=%le, ux=%le, z=%le, uz=%le", *icount, *ynewlo, part_temp.x, part_temp.ux, part_temp.z, part_temp.uz);
		//fflush(stdout);
	
		if(kcount < *icount) {
			*ifault = 2;
			break;
		}
		*ifault = 0;
		for(i = 0; i < n; i++) {
			del = step[i] * eps;
			xmin[i] = xmin[i] + del;
			//z = fn(xmin);
			part_temp = *part;
			z = fn_co_xxp(latt, &part_temp, xmin, betax);
			*icount = *icount + 1;
			if(z < *ynewlo) {
				*ifault = 2;
				break;
			}
			xmin[i] = xmin[i] - del - del;
			//z = fn(xmin);
			part_temp = *part;
			z = fn_co_xxp(latt, &part_temp, xmin, betax);
			*icount = *icount + 1;
			if(z < *ynewlo) {
				*ifault = 2;
				break;
			}
			xmin[i] = xmin[i] + del;
		}
		if(*ifault == 0) break;
		//Restart the procedure.
		for(i = 0; i < n; i++) start[i] = xmin[i];
		del = eps;
		*numres = *numres + 1;
	}
	free(p);
	free(pstar);
	free(p2star);
	free(pbar);
	free(y);
	return;
}

extern int put_on_co_nelmin_xxp(struct Lattice *latt, struct Particle *part, double reqmin, double stepx, double stepux, int doyouprintf)
{
	int icount, numres, ifault;
	double xco[2], ynewlo, step[2];
	int n=2;
	int konvge=1;
	int kcount=1e6;
	double betax=1.0;//10.0;
	step[0] = stepx;
	step[1] = stepux;
	if(doyouprintf==YES) printf("put on closed orbit nelmin\n");
	
	find_co_nelmin_xxp(latt, part, betax, fn_co_xxp, n, xco, &ynewlo, reqmin, step, konvge, kcount, &icount, &numres, &ifault, doyouprintf);
	if(ifault==0) {
		part->x  = xco[0];
		part->ux = xco[1];
	}
	if(doyouprintf==YES) {
		if(reqmin>ynewlo) printf("\nClosed orbit found: x_clo = %.8f [m], xprime_clo = %le [deg], eps = %le < %le\n", part->x, atan(part->ux/part->uy)*180./(PI), ynewlo, reqmin);
		else printf("\nCLOSED ORBIT NOT FOUND: x = %.8f [m], xprime = %le [deg], eps = %le > %le\n", part->x, atan(part->ux/part->uy)*180./(PI), ynewlo, reqmin);
		printf("nb of iterations=%i, nb of restarts=%i, ifault=%i\n", icount, numres, ifault);
		
	}
	if(ifault==0) return TRUE;
	else return FALSE;
}

extern double fn_co(struct Lattice *latt, struct Particle *part, double x[], double betax, double betaz)
{
	double xi[4], xf[4];
	struct Particle part_temp;
	part_temp = *part;
	part_temp.x  = x[0];
	part_temp.ux = x[1];
	part_temp.z  = x[2];
	part_temp.uz = x[3];
	xi[0] = part_temp.x;
	xi[1] = part_temp.ux;
	xi[2] = part_temp.z;
	xi[3] = part_temp.uz;
	//printf("%le, %le, %le, %le\n",xi[0],xi[1],xi[2],xi[3]);
	part_cross_latt(&part_temp, latt, NULL, NULL);
	if(part_temp.status != ALIVE) errorstop("part killed while crossing latt");
	xf[0] = part_temp.x;
	xf[1] = part_temp.ux;
	xf[2] = part_temp.z;
	xf[3] = part_temp.uz;
	return (xf[0]-xi[0])*(xf[0]-xi[0]) + betax*(xf[1]-xi[1])*(xf[1]-xi[1]) + (xf[2]-xi[2])*(xf[2]-xi[2]) + betaz*(xf[3]-xi[3])*(xf[3]-xi[3]);
}

extern void find_co_nelmin(struct Lattice *latt, struct Particle *part, double betax, double betaz, double fn_co(struct Lattice*, struct Particle*, double x[], double, double), 
	int n, double xmin[], double *ynewlo, double reqmin, double step[], int konvge, int kcount, int *icount, int *numres, int *ifault)
{
	int i, ihi, ilo, j, jcount, l, nn;
	double ccoeff = 0.5, del, dn, dnn, ecoeff = 2.0, eps = 1.0, rcoeff = 1.0, rq, x, *y, y2star, ylo, ystar, z, *p, *p2star, *pbar, *pstar;
	
	//Check the input parameters.
	if(reqmin <= 0.0 || n < 1 || konvge < 1) {
		*ifault = 1;
		return;
	}
	
	double start[n];
	struct Particle part_temp;
	start[0] = part->x;
	start[1] = part->ux;
	start[2] = part->z;
	start[3] = part->uz;
	
	p = (double *) malloc(n * (n + 1) * sizeof(double));
	pstar = (double *) malloc(n * sizeof(double));
	p2star = (double *) malloc(n * sizeof(double));
	pbar = (double *) malloc(n * sizeof(double));
	y = (double *) malloc((n + 1) * sizeof(double));
	
	*icount = 0;
	*numres = 0;
	
	jcount = konvge; 
	dn = (double) (n);
	nn = n + 1;
	dnn = (double) (nn);
	del = 1.0;
	rq = reqmin * dn;
	
	//Initial or restarted loop.
	
	for(;;) {
		for(i = 0; i < n; i++) p[i+n*n] = start[i];
		//y[n] = fn(start);
		part_temp = *part;
		y[n] = fn_co(latt, &part_temp, start, betax, betaz);
		*icount = *icount + 1;
	
		for(j = 0; j < n; j++) {
			x = start[j];
			start[j] = start[j] + step[j] * del;
			for(i = 0; i < n; i++) p[i+j*n] = start[i];
			//y[n] = fn(start);
			part_temp = *part;
			y[j] = fn_co(latt, &part_temp, start, betax, betaz);
			*icount = *icount + 1;
			start[j] = x;
		}
		//The simplex construction is complete.
		//Find highest and lowest Y values.	YNEWLO = Y(IHI) indicates
		//the vertex of the simplex to be replaced.
		ylo = y[0];
		ilo = 0;
		for(i = 1; i < nn; i++) {
			if(y[i] < ylo) {
				ylo = y[i];
				ilo = i;
			}
		}
		//CLRSCR();
		printf("try # %i, ylo = %le, x=%le, ux=%le, z=%le, uz=%le\n", *icount, ylo, part_temp.x, part_temp.ux, part_temp.z, part_temp.uz);
		//fflush(stdout);
		//Inner loop.
		for(;;) {
			if(kcount <= *icount) break;
			*ynewlo = y[0];
			ihi = 0;
			for(i = 1; i < nn; i++) {
				if(*ynewlo < y[i]) {
					*ynewlo = y[i];
					ihi = i;
				}
			}
			//CLRSCR();
			//printf("try # %i, ynewlo = %le, x=%le, ux=%le, z=%le, uz=%le\n", *icount, *ynewlo, part_temp.x, part_temp.ux, part_temp.z, part_temp.uz);
			printf("try # %i, ynewlo = %le\n", *icount, *ynewlo);
			//fflush(stdout);
			//printf("ynewlo=%le\n", *ynewlo);
			//Calculate PBAR, the centroid of the simplex vertices
			//excepting the vertex with Y value YNEWLO.
			for(i = 0; i < n; i++) {
				z = 0.0;
				for(j = 0; j < nn; j++) z = z + p[i+j*n];
				z = z - p[i+ihi*n];	
				pbar[i] = z / dn;
			}
			//Reflection through the centroid.
			for(i = 0; i < n; i++) pstar[i] = pbar[i] + rcoeff * (pbar[i] - p[i+ihi*n]);
			//ystar = fn(pstar);
			part_temp = *part;
			ystar = fn_co(latt, &part_temp, pstar, betax, betaz);
			*icount = *icount + 1;
			//Successful reflection, so extension.
			if(ystar < ylo) {
				for(i = 0; i < n; i++) p2star[i] = pbar[i] + ecoeff * (pstar[i] - pbar[i]);
				//y2star = fn(p2star);
				part_temp = *part;
				y2star = fn_co(latt, &part_temp, p2star, betax, betaz);
				*icount = *icount + 1;
				//Check extension.
				if(ystar < y2star) {
					for(i = 0; i < n; i++) p[i+ihi*n] = pstar[i];
					y[ihi] = ystar;
				}
				//Retain extension or contraction.
				else {
					for(i = 0; i < n; i++) p[i+ihi*n] = p2star[i];
					y[ihi] = y2star;
				}
			}
			//No extension.
			else {
				l = 0;
				for(i = 0; i < nn; i++) if(ystar < y[i]) l = l + 1;
	
				if(l > 1) {
					for(i = 0; i < n; i++) p[i+ihi*n] = pstar[i];
					y[ihi] = ystar;
				}
				//Contraction on the Y(IHI) side of the centroid.
				else if(l == 0) {
					for(i = 0; i < n; i++) p2star[i] = pbar[i] + ccoeff * (p[i+ihi*n] - pbar[i]);
					//y2star = fn(p2star);
					part_temp = *part;
					y2star = fn_co(latt, &part_temp, p2star, betax, betaz);
					*icount = *icount + 1;
					//Contract the whole simplex.
					if(y[ihi] < y2star) {
						for(j = 0; j < nn; j++) {
							for(i = 0; i < n; i++) {
								p[i+j*n] = (p[i+j*n] + p[i+ilo*n]) * 0.5;
								xmin[i] = p[i+j*n];
							}
							//y[j] = fn(xmin);
							part_temp = *part;
							y[j] = fn_co(latt, &part_temp, xmin, betax, betaz);
							*icount = *icount + 1;
						}
						ylo = y[0];
						ilo = 0;
						for(i = 1; i < nn; i++) {
							if(y[i] < ylo) {
								ylo = y[i];
								ilo = i;
							}
						}
						continue;
					}
					//Retain contraction.
					else {
						for(i = 0; i < n; i++) p[i+ihi*n] = p2star[i];
						y[ihi] = y2star;
					}
				}
				//Contraction on the reflection side of the centroid.
				else if(l == 1) {
					for(i = 0; i < n; i++) p2star[i] = pbar[i] + ccoeff * (pstar[i] - pbar[i]);
					//y2star = fn(p2star);
					part_temp = *part;
					y2star = fn_co(latt, &part_temp, p2star, betax, betaz);
					*icount = *icount + 1;
					//Retain reflection?
					if(y2star <= ystar) {
						for(i = 0; i < n; i++) p[i+ihi*n] = p2star[i];
						y[ihi] = y2star;
					}
					else {
						for(i = 0; i < n; i++) p[i+ihi*n] = pstar[i];
						y[ihi] = ystar;
					}
				}
			}
			//Check if YLO improved.
			if(y[ihi] < ylo) {
				ylo = y[ihi];
				ilo = ihi;
			}
			jcount = jcount - 1;
	
			if(0 < jcount) continue;
			//Check to see if minimum reached.
			if(*icount <= kcount) {
				jcount = konvge;
				z = 0.0;
				for(i = 0; i < nn; i++) z = z + y[i];
				x = z / dnn;
	
				z = 0.0;
				for(i = 0; i < nn; i++) z = z + pow(y[i] - x, 2);
				if(z <= rq) break;
			}
		}
		//Factorial tests to check that YNEWLO is a local minimum.
		for(i = 0; i < n; i++) xmin[i] = p[i+ilo*n];
		*ynewlo = y[ilo];
		//CLRSCR();
		//printf("trys # %i, eps = %le\n", *icount, *ynewlo);
		//printf("trys # %i, ynewlo = %le, x=%le, ux=%le, z=%le, uz=%le", *icount, *ynewlo, part_temp.x, part_temp.ux, part_temp.z, part_temp.uz);
		//fflush(stdout);
	
		if(kcount < *icount) {
			*ifault = 2;
			break;
		}
		*ifault = 0;
		for(i = 0; i < n; i++) {
			del = step[i] * eps;
			xmin[i] = xmin[i] + del;
			//z = fn(xmin);
			part_temp = *part;
			z = fn_co(latt, &part_temp, xmin, betax, betaz);
			*icount = *icount + 1;
			if(z < *ynewlo) {
				*ifault = 2;
				break;
			}
			xmin[i] = xmin[i] - del - del;
			//z = fn(xmin);
			part_temp = *part;
			z = fn_co(latt, &part_temp, xmin, betax, betaz);
			*icount = *icount + 1;
			if(z < *ynewlo) {
				*ifault = 2;
				break;
			}
			xmin[i] = xmin[i] + del;
		}
		if(*ifault == 0) break;
		//Restart the procedure.
		for(i = 0; i < n; i++) start[i] = xmin[i];
		del = eps;
		*numres = *numres + 1;
	}
	free(p);
	free(pstar);
	free(p2star);
	free(pbar);
	free(y);
	return;
}

extern int put_on_co_nelmin(struct Lattice *latt, struct Particle *part, double reqmin, double stepx, double stepux, double stepz, double stepuz, int doyouprintf)
{
	int icount, numres, ifault;
	double xco[4], ynewlo, step[4];
	int n=4;
	int konvge=1;
	int kcount=1e6;
	double betax=1.0;//10.0;
	double betaz=1.0;//10.0;
	step[0] = stepx;
	step[1] = stepux;
	step[2] = stepz;
	step[3] = stepuz;
	
	find_co_nelmin(latt, part, betax, betaz, fn_co, n, xco, &ynewlo, reqmin, step, konvge, kcount, &icount, &numres, &ifault);
	if(ifault==0) {
		part->x  = xco[0];
		part->ux = xco[1];
		part->z  = xco[2];
		part->uz = xco[3];
	}
	if(doyouprintf==YES) {
		if(reqmin>ynewlo) printf("\nClosed orbit found: x_clo = %.8f [m], xprime_clo = %le [deg], \nz_clo = %lf [m], zprime_clo = %lf [deg], eps = %le < %le\n", part->x, atan(part->ux/part->uy)*180./(PI), part->z, atan(part->uz/part->uy)*180./(PI), ynewlo, reqmin);
		else printf("\nCLOSED ORBIT NOT FOUND: x = %.8f [m], xprime = %le [deg], \nz = %lf [m], zprime = %lf [deg], eps = %le > %le\n", part->x, atan(part->ux/part->uy)*180./(PI), part->z, atan(part->uz/part->uy)*180./(PI), ynewlo, reqmin);
		printf("nb of iterations=%i, nb of restarts=%i, ifault=%i\n", icount, numres, ifault);
		
	}
	if(ifault==0) return TRUE;
	else return FALSE;
}

extern void find_new_closed_orbit_afterb0adjust_spi(struct Particle *newpart, double x, double ux, double brho_ori, struct Lattice *latt, double ux_ori, double eps_clo)
{
	newpart->x = x*pow(newpart->brho/brho_ori, 1/(1+latt->cell[0].mpara[0][3]));
	newpart->ux += ux-ux_ori;
	newpart->uy = sqrt(1-newpart->ux*newpart->ux);
	if(find_closed_orbite_xxp(newpart, &(newpart->x), &(newpart->ux), &(newpart->uy), eps_clo, latt, YES) != TRUE) errorstop("closed orbit not found");
	
}

// ************************************************************************************ //
//////////////  ACCEPTANCE COMPUTATIONS  ///////////////////////////////
// ************************************************************************************ //

extern int acceptancex(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double axmin, double axmax, double axstep, double az)
{
	int i;
	double x, xprime, z, zprime, ampx, php_ref, atanrefx, atanrefz;
	struct Particle test_part;
	FILE *rfile;
	if(outfilename != NULL) rfile = fopen(outfilename,"a");
	
	php_ref = sqrt(pow(reference->ux, 2) + pow(reference->uy, 2));
	atanrefx = atan_ratio((reference->ux), (reference->uy));
	atanrefz = atan_ratio(reference->uz, php_ref);
	printf("acceptancex:");
	
	for (ampx = axmin; ampx <= axmax; ampx += axstep) {
		test_part = *reference;
		test_part.s = 0;
		test_part.z += az;
		test_part.x += ampx;
		test_part.hat = -2;
		printf("\namp = %lf\n", ampx);
		
		for (i = 0; i < nbpass; i++) {
			CLRSCR();
			printf("pass number %i\t", i);
			fflush(stdout);
			if (test_part.uy > 0) {
				comp_phase_space_coord(&x, &xprime, &z, &zprime,  test_part.x, test_part.z, test_part.ux, test_part.uy, test_part.uz, reference->x, atanrefx, reference->z, atanrefz);
			}
			else {
				printf("\tin acceptancex, test_part.uy <= 0!, particle is going backwards!\n");
				if(outfilename != NULL) fclose(rfile);
				return test_part.status;
			}
			if(outfilename != NULL) fprintf(rfile, "%le  %le  %le  %le  %le\n", x, xprime, z, zprime, ampx);
			part_cross_latt(&(test_part), latt,NULL, NULL);
			if(test_part.status != ALIVE) {
				if(outfilename != NULL) fclose(rfile);
				printf("\n");
				return test_part.status;
			}
		}
	}	
	
	if(outfilename != NULL) fclose(rfile);
	printf("\n");
	return test_part.status;
}

extern int acceptancez(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double azmin, double azmax, double azstep, double ax)
{
	int i;
	double x, xprime, z, zprime, ampz, php_ref, atanrefx, atanrefz;
	struct Particle test_part;
	FILE *rfile;
	if(outfilename != NULL) rfile = fopen(outfilename,"a");
	php_ref = sqrt(pow(reference->ux, 2) + pow(reference->uy, 2));
	atanrefx = atan_ratio((reference->ux), (reference->uy));
	atanrefz = atan_ratio(reference->uz, php_ref);
	printf("acceptancez:");
	for (ampz = azmin; ampz <= azmax; ampz += azstep) {
		test_part = *reference;
		test_part.s = 0;
		test_part.x += ax;
		test_part.z += ampz;
		test_part.hat = -2;
		printf("\namp = %lf\n", ampz);
		
		for (i = 0; i < nbpass; i++) {
			CLRSCR();
			printf("pass %i\t", i);
			fflush(stdout);
			if (test_part.uy > 0) {
				comp_phase_space_coord(&x, &xprime, &z, &zprime,  test_part.x, test_part.z, test_part.ux, test_part.uy, test_part.uz, reference->x, atanrefx, reference->z, atanrefz);
			}
			else {
				printf("\tin acceptancez, test_part.uy <= 0!, particle is going backwards!\n");
				if(outfilename != NULL) fclose(rfile);
				return test_part.status;
			}
			if(outfilename != NULL) fprintf(rfile, "%le  %le  %le  %le  %le\n", x, xprime, z, zprime, ampz);
			part_cross_latt(&(test_part), latt,NULL, NULL);
			if(test_part.status != ALIVE) {
				if(outfilename != NULL) fclose(rfile);
				printf("\n");
				return test_part.status;
			}
		}
	}	
	
	if(outfilename != NULL) fclose(rfile);
	printf("\n");
	return test_part.status;
}

extern int acceptancezprime(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double zprimemin, double zprimemax, double zprimestep, double ax)
{
	int i;
	double asquare, x, xprime, z, zprime, ampz, php_ref, atanrefx, atanrefz;
	struct Particle test_part;
	FILE *rfile;
	if(outfilename != NULL) rfile = fopen(outfilename,"a");
	php_ref = sqrt(pow(reference->ux, 2) + pow(reference->uy, 2));
	atanrefx = atan_ratio((reference->ux), (reference->uy));
	atanrefz = atan_ratio(reference->uz, php_ref);
	asquare = reference->ux*reference->ux/(reference->uy*reference->uy);
	
	for (ampz = zprimemin; ampz <= zprimemax; ampz += zprimestep) {
		test_part = *reference;
		test_part.s = 0;
		test_part.x += ax;
		test_part.hat = -2;
		test_part.uy = sign(reference->uy)*(1/(sqrt((asquare+1)*(tan(ampz)*tan(ampz)+1))));
		test_part.ux = sign(reference->ux)*sqrt(asquare)*test_part.uy;
		test_part.uz = test_part.uy*sqrt(1+asquare)*tan(ampz);
		
		for (i = 0; i < nbpass; i++) {
			printf("pass number %i\n", i);
			if (test_part.uy > 0) {
				comp_phase_space_coord(&x, &xprime, &z, &zprime,  test_part.x, test_part.z, test_part.ux, test_part.uy, test_part.uz, reference->x, atanrefx, reference->z, atanrefz);
			}
			else {
				printf("test_part.uy <= 0!, particle is going backwards!\n");
				if(outfilename != NULL) fclose(rfile);
				return FALSE;
			}
			if(outfilename != NULL) fprintf(rfile, "%le  %le  %le  %le  %le\n", x, xprime, z, zprime, ampz);
			part_cross_latt(&(test_part), latt,NULL, NULL);
			if(test_part.status != ALIVE) {
				if(outfilename != NULL) fclose(rfile);
				return test_part.status;
			}
		}
	}	
	
	if(outfilename != NULL) fclose(rfile);
	return test_part.status;
}

extern void acceptancex_auto(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double axmin, double *axmax, double axstep, double az) 
{
	int i, n, doyouprint=YES;
	double ax, xpart[nbpass], zpart[nbpass], ux[nbpass], uy[nbpass], uz[nbpass], x, z, xprime, zprime, php_ref, atanrefx, atanrefz;
	FILE *wfile;
	if(outfilename != NULL) wfile = fopen(outfilename, "w");
	
	php_ref = sqrt(reference->ux*reference->ux + reference->uy*reference->uy);
	atanrefx = atan_ratio((reference->ux), (reference->uy));
	atanrefz = atan_ratio(reference->uz, php_ref);
	
	ax = axmin;
	i = 0;
	*axmax = 0.;
	for(;;) {
		ax = axmin+i*axstep;
		CLRSCR();
		if(doyouprint==YES) printf("ax = %lf\t", ax);
		fflush(stdout);
		if(track_n_turns_amp(xpart, zpart, ux, uy, uz, reference, latt, nbpass, ax, az) != ALIVE) {
			if(doyouprint==YES) printf("NO!\n");
			break;
		}
		else {
			if(doyouprint==YES) printf("OK!\n");
			//*axmax = ax;
			if(outfilename != NULL) {
				for(n=0;n<nbpass;n++) {
					comp_phase_space_coord(&x, &xprime, &z, &zprime, xpart[n], zpart[n], ux[n], uy[n], uz[n], reference->x, atanrefx, reference->z, atanrefz);
					fprintf(wfile, "%le  %le  %le  %le  %le\n", x, xprime, z, zprime, ax);
				}
			}
		}
		i++;
	}
	if(i==0) *axmax = 0.;
	else *axmax = ax-axstep;
	if(outfilename != NULL) fclose(wfile);
	if(doyouprint==YES) printf("final: ax = %le\n",*axmax);
}

extern int track_n_turns_amp(double x[],double z[], double ux[], double uy[], double uz[], struct Particle *reference, struct Lattice *latt, int nbpass, double ax, double az) 
{
	int i;
	struct Particle test_part;
	test_part = *reference;
	test_part.s = 0;
	test_part.z += az;
	test_part.x += ax;
	for(i=0;i<nbpass;i++) {
		if(test_part.status != ALIVE) return test_part.status;
		else {
			x[i] = test_part.x;
			z[i] = test_part.z;
			ux[i] = test_part.ux;
			uy[i] = test_part.uy;
			uz[i] = test_part.uz;
		}
		part_cross_latt(&(test_part), latt,NULL, NULL);
	}
	return test_part.status;
}

extern void acceptancez_auto(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double azmin, double *azmax, double azstep, double ax) 
{
	int i, n, doyouprint=YES;
	double az, xpart[nbpass], zpart[nbpass], ux[nbpass], uy[nbpass], uz[nbpass], x, z, xprime, zprime, php_ref, atanrefx, atanrefz;
	FILE *wfile;
	if(outfilename != NULL) wfile = fopen(outfilename, "w");
	
	php_ref = sqrt(reference->ux*reference->ux + reference->uy*reference->uy);
	atanrefx = atan_ratio((reference->ux), (reference->uy));
	atanrefz = atan_ratio(reference->uz, php_ref);
	
	az = azmin;
	i = 0;
	*azmax = 0.;
	for(;;) {
		az = azmin+i*azstep;
		CLRSCR();
		if(doyouprint==YES) printf("az = %lf\t", az);
		fflush(stdout);
		if(track_n_turns_amp(xpart, zpart, ux, uy, uz, reference, latt, nbpass, ax, az) != ALIVE) {
			if(doyouprint==YES) printf("NO!\n");
			break;
		}
		else {
			if(doyouprint==YES) printf("OK!\n");
			//*azmax = az;
			if(outfilename != NULL) {
				for(n=0;n<nbpass;n++) {
					comp_phase_space_coord(&x, &xprime, &z, &zprime, xpart[n], zpart[n], ux[n], uy[n], uz[n], reference->x, atanrefx, reference->z, atanrefz);
					fprintf(wfile, "%le  %le  %le  %le  %le\n", x, xprime, z, zprime, az);
				}
			}
		}
		i++;
	}
	if(i==0) *azmax = 0.;
	else *azmax = az-azstep;
	if(outfilename != NULL) fclose(wfile);
	if(doyouprint==YES) printf("final: az = %le\n",*azmax);
}

//geometric emittance, not normalised emittance, not working on coupled case
extern void acceptance_2d_emit_auto(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double emitmin, double *emitmax, double emitstep)
{
	int i, n, doyouprint=YES;
	double qx, qz, beta_x, alpha_x, beta_z, alpha_z, gamma_x, gamma_z, emit;
	double amp_x_tune = 1.e-5, amp_z_tune = 1.e-5;
	double ax, az, xpart[nbpass], zpart[nbpass], ux[nbpass], uy[nbpass], uz[nbpass], x, z, xprime, zprime, php_ref, atanrefx, atanrefz;
	FILE *wfile;
	struct Particle test_part = *reference;
	test_part.hat = -2;
	test_part.status = ALIVE;
	test_part.s = 0;
	
	if(outfilename != NULL) wfile = fopen(outfilename, "w");
	php_ref = sqrt(reference->ux*reference->ux + reference->uy*reference->uy);
	atanrefx = atan_ratio((reference->ux), (reference->uy));
	atanrefz = atan_ratio(reference->uz, php_ref);
	
	//calc_tune_twiss(&test_part, &qx, &qz, &beta_x, &alpha_x, &beta_z, &alpha_z, amp_x_tune, amp_x_tune, amp_z_tune, amp_z_tune, latt, part_cross_latt, YES, NULL,0);//flag: 0=2d, 1=4d decoupled, anything else=4d undecoupled.
	iterative_calc_tune_twiss(&test_part, &qx, &qz, &beta_x, &alpha_x, &beta_z, &alpha_z, amp_x_tune, amp_z_tune, latt, part_cross_latt, YES, NULL);
	gamma_x = (1+alpha_x*alpha_x)/beta_x;
	gamma_z = (1+alpha_z*alpha_z)/beta_z;
	printf("gamma_x = %lf, gamma_z = %lf\n",gamma_x,gamma_z);
	emit = emitmin;
	i = 0;
	*emitmax = 0.;
	for(;;) {
		emit = emitmin+i*emitstep;
		ax = sqrt(emit/gamma_x);
		az = sqrt(emit/gamma_z);
		//CLRSCR();
		if(doyouprint==YES) printf("unnorm. emit = %le [m], ampx = %lf, ampz = %lf\t", emit, ax, az);
		//fflush(stdout);
		if(track_n_turns_amp(xpart, zpart, ux, uy, uz, &test_part, latt, nbpass, ax, az) != ALIVE) {
			if(doyouprint==YES) printf("NO!\n");
			break;
		}
		else {
			if(doyouprint==YES) printf("OK!\n");
			//*axmax = ax;
			if(outfilename != NULL) {
				for(n=0;n<nbpass;n++) {
					comp_phase_space_coord(&x, &xprime, &z, &zprime, xpart[n], zpart[n], ux[n], uy[n], uz[n], test_part.x, atanrefx, test_part.z, atanrefz);
					fprintf(wfile, "%le  %le  %le  %le  %le  %le  %le\n", x, xprime, z, zprime, emit, ax, az);
				}
			}
		}
		i++;
	}
	if(i==0) *emitmax = 0.;
	else *emitmax = emit-emitstep;
	if(outfilename != NULL) fclose(wfile);
	if(doyouprint==YES) printf("final: emit = %le\n",*emitmax);
}

// compute acceptance in (u,u') and (v,v') phase spaces with an initial amplitude in u (VFFA)
extern int acceptanceu(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double aumin, double aumax, double austep, double av)
{
	int i;
	double m4d[4][4], decoup_to_coup[4][4], decoup_to_coup_inv[4][4], u_vect[4], x_vect[4];
	//double decoup_m[4][4], output[6];
	double php_ref, xprime_ref, zprime_ref, band_bias, amp_u;
	struct Particle test_part;
	FILE *rfile;
	if(outfilename != NULL) rfile = fopen(outfilename,"a");
	
	printf("acceptance in u:");
	php_ref = sqrt(pow(reference->ux, 2) + pow(reference->uy, 2));
	xprime_ref = atan_ratio(reference->ux, reference->uy);
	zprime_ref  = atan_ratio(reference->uz, php_ref);
	x_vect[0] = 1.e-5;
	x_vect[1] = 1.e-5;
	x_vect[2] = 1.e-5;
	x_vect[3] = 1.e-5;
	if(get_matrix_firstorder_4d(m4d, &band_bias, reference, x_vect[0], x_vect[1], x_vect[2], x_vect[3], latt, part_cross_latt, YES) != TRUE) return FALSE;
	//decouple_matrix_parzen(m4d, decoup_m, decoup_to_coup, output, NULL);
	matrix_inverse_4d(decoup_to_coup, decoup_to_coup_inv);
	
	for(amp_u = aumin; amp_u <= aumax; amp_u += austep) {
		u_vect[0] = amp_u; // u
		u_vect[1] = 0; //uprime
		u_vect[2] = av; //v
		u_vect[3] = 0; //vprime
		mvprod4(x_vect, decoup_to_coup, u_vect);
		test_part = *reference;
		test_part.s = 0;
		test_part.x += x_vect[0]/cos(xprime_ref);
		test_part.z += x_vect[2]/cos(zprime_ref);
		test_part.ux = sin(xprime_ref + x_vect[1])*cos(zprime_ref + x_vect[3]);
		test_part.uy = cos(xprime_ref + x_vect[1])*cos(zprime_ref + x_vect[3]);
		test_part.uz = sin(zprime_ref + x_vect[3]);
		test_part.hat = -2;
		printf("\namp = %lf\n", amp_u);
		
		for(i = 0; i < nbpass; i++) {
			CLRSCR();
			printf("pass number %i\t", i);
			fflush(stdout);
			if (test_part.uy > 0) {
				comp_phase_space_coord(&(x_vect[0]), &(x_vect[1]), &(x_vect[2]), &(x_vect[3]), test_part.x, test_part.z, test_part.ux, test_part.uy, test_part.uz, reference->x, xprime_ref, reference->z, zprime_ref);
				mvprod4(u_vect, decoup_to_coup_inv, x_vect);
			}
			else {
				printf("\tin acceptanceu, test_part.uy <= 0!, particle is going backwards!\n");
				if(outfilename != NULL) fclose(rfile);
				return test_part.status;
			}
			if(outfilename != NULL) fprintf(rfile, "%le  %le  %le  %le  %le  %le  %le  %le  %le\n", x_vect[0], x_vect[1], x_vect[2], x_vect[3], u_vect[0], u_vect[1], u_vect[2], u_vect[3], amp_u);
			part_cross_latt(&(test_part), latt, NULL, NULL);
			if(test_part.status != ALIVE) {
				if(outfilename != NULL) fclose(rfile);
				printf("\n");
				return test_part.status;
			}
		}
	}	
	
	if(outfilename != NULL) fclose(rfile);
	printf("\n");
	return test_part.status;
}

// compute acceptance in (u,u') and (v,v') phase spaces with an initial amplitude in u (VFFA)
extern int acceptancev(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double avmin, double avmax, double avstep, double au)
{
	int i;
	double m4d[4][4], decoup_to_coup[4][4], decoup_to_coup_inv[4][4], u_vect[4], x_vect[4];
	//double decoup_m[4][4], output[6];
	double php_ref, xprime_ref, zprime_ref, band_bias, amp_v;
	struct Particle test_part;
	FILE *rfile;
	if(outfilename != NULL) rfile = fopen(outfilename,"a");

	printf("acceptance in v:");
	php_ref = sqrt(pow(reference->ux, 2) + pow(reference->uy, 2));
	xprime_ref = atan_ratio(reference->ux, reference->uy);
	zprime_ref  = atan_ratio(reference->uz, php_ref);
	x_vect[0] = 1.e-5;
	x_vect[1] = 1.e-5;
	x_vect[2] = 1.e-5;
	x_vect[3] = 1.e-5;
	if(get_matrix_firstorder_4d(m4d, &band_bias, reference, x_vect[0], x_vect[1], x_vect[2], x_vect[3], latt, part_cross_latt, YES) != TRUE) return FALSE;
	//decouple_matrix_parzen(m4d, decoup_m, decoup_to_coup, output, NULL);
	matrix_inverse_4d(decoup_to_coup, decoup_to_coup_inv);
	
	for(amp_v = avmin; amp_v <= avmax; amp_v += avstep) {
		u_vect[0] = au; // u
		u_vect[1] = 0; //uprime
		u_vect[2] = amp_v; //v
		u_vect[3] = 0; //vprime
		mvprod4(x_vect, decoup_to_coup, u_vect);
		test_part = *reference;
		test_part.s = 0;
		test_part.x += x_vect[0]/cos(xprime_ref);
		test_part.z += x_vect[2]/cos(zprime_ref);
		test_part.ux = sin(xprime_ref + x_vect[1])*cos(zprime_ref + x_vect[3]);
		test_part.uy = cos(xprime_ref + x_vect[1])*cos(zprime_ref + x_vect[3]);
		test_part.uz = sin(zprime_ref + x_vect[3]);
		test_part.hat = -2;
		printf("\namp = %lf\n", amp_v);
		
		for(i = 0; i < nbpass; i++) {
			CLRSCR();
			printf("pass number %i\t", i);
			fflush(stdout);
			if (test_part.uy > 0) {
				comp_phase_space_coord(&(x_vect[0]), &(x_vect[1]), &(x_vect[2]), &(x_vect[3]), test_part.x, test_part.z, test_part.ux, test_part.uy, test_part.uz, reference->x, xprime_ref, reference->z, zprime_ref);
				mvprod4(u_vect, decoup_to_coup_inv, x_vect);
			}
			else {
				printf("\tin acceptancev, test_part.uy <= 0!, particle is going backwards!\n");
				if(outfilename != NULL) fclose(rfile);
				return test_part.status;
			}
			if(outfilename != NULL) fprintf(rfile, "%le  %le  %le  %le  %le  %le  %le  %le  %le\n", x_vect[0], x_vect[1], x_vect[2], x_vect[3], u_vect[0], u_vect[1], u_vect[2], u_vect[3], amp_v);
			part_cross_latt(&(test_part), latt, NULL, NULL);
			if(test_part.status != ALIVE) {
				if(outfilename != NULL) fclose(rfile);
				printf("\n");
				return test_part.status;
			}
		}
	}	
	
	if(outfilename != NULL) fclose(rfile);
	printf("\n");
	return test_part.status;
}

// Automatic acceptance in u (VFFA)
extern int acceptanceu_auto(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double aumin, double *aumax, double austep, double av) 
{
	int i, n;
	double m4d[4][4], decoup_to_coup[4][4], decoup_to_coup_inv[4][4], u_vect[4], x_vect[4];
	//double decoup_m[4][4], output[6];
	
	double au, band_bias, xpart[nbpass], zpart[nbpass], ux[nbpass], uy[nbpass], uz[nbpass], xprime_ref, zprime_ref, php_ref;
	struct Particle test_part;
	FILE *wfile;
	if(outfilename != NULL) wfile = fopen(outfilename, "w");
	
	php_ref = sqrt(pow(reference->ux, 2) + pow(reference->uy, 2));
	xprime_ref = atan_ratio(reference->ux, reference->uy);
	zprime_ref  = atan_ratio(reference->uz, php_ref);
	x_vect[0] = 1.e-5;
	x_vect[1] = 1.e-5;
	x_vect[2] = 1.e-5;
	x_vect[3] = 1.e-5;
	if(get_matrix_firstorder_4d(m4d, &band_bias, reference, x_vect[0], x_vect[1], x_vect[2], x_vect[3], latt, part_cross_latt, YES) != TRUE) return FALSE;
	//decouple_matrix_parzen(m4d, decoup_m, decoup_to_coup, output, NULL);
	matrix_inverse_4d(decoup_to_coup, decoup_to_coup_inv);
	
	//au = aumin;
	i = 0;
	*aumax = 0.;
	for(;;) {
		au = aumin+i*austep;
		//CLRSCR();
		//printf("amp_u = %lf\t", au);
		//fflush(stdout);
		u_vect[0] = au; // u
		u_vect[1] = 0; //uprime
		u_vect[2] = av; //v
		u_vect[3] = 0; //vprime
		mvprod4(x_vect, decoup_to_coup, u_vect);
		test_part = *reference;
		test_part.s = 0;
		test_part.x += x_vect[0]/cos(xprime_ref);
		test_part.z += x_vect[2]/cos(zprime_ref);
		test_part.ux = sin(xprime_ref + x_vect[1])*cos(zprime_ref + x_vect[3]);
		test_part.uy = cos(xprime_ref + x_vect[1])*cos(zprime_ref + x_vect[3]);
		test_part.uz = sin(zprime_ref + x_vect[3]);
		test_part.hat = -2;
		
		if(track_n_turns_amp(xpart, zpart, ux, uy, uz, &test_part, latt, nbpass, 0, 0) != ALIVE) {
			printf("NO!\n");
			break;
		}
		else {
			printf("OK!\n");
			if(outfilename != NULL) {
				for(n=0;n<nbpass;n++) {
					comp_phase_space_coord(&(x_vect[0]), &(x_vect[1]), &(x_vect[2]), &(x_vect[3]), xpart[n], zpart[n], ux[n], uy[n], uz[n], reference->x, xprime_ref, reference->z, zprime_ref);
					mvprod4(u_vect, decoup_to_coup_inv, x_vect);
					fprintf(wfile, "%le  %le  %le  %le  %le  %le  %le  %le  %le\n", x_vect[0], x_vect[1], x_vect[2], x_vect[3], u_vect[0], u_vect[1], u_vect[2], u_vect[3], au);
				}
			}
		}
		i++;
	}
	if(i==0) *aumax = 0.;
	else *aumax = au-austep;
	if(outfilename != NULL) fclose(wfile);
	printf("final: amp_u = %le\n",*aumax);
	return TRUE;
}

// Automatic acceptance in v (VFFA)
extern int acceptancev_auto(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double avmin, double *avmax, double avstep, double au) 
{
	int i, n;
	double m4d[4][4], decoup_to_coup[4][4], decoup_to_coup_inv[4][4], u_vect[4], x_vect[4];
	//double decoup_m[4][4], output[6];
	double av, band_bias, xpart[nbpass], zpart[nbpass], ux[nbpass], uy[nbpass], uz[nbpass], xprime_ref, zprime_ref, php_ref;
	struct Particle test_part;
	FILE *wfile;
	if(outfilename != NULL) wfile = fopen(outfilename, "w");
	
	php_ref = sqrt(pow(reference->ux, 2) + pow(reference->uy, 2));
	xprime_ref = atan_ratio(reference->ux, reference->uy);
	zprime_ref  = atan_ratio(reference->uz, php_ref);
	x_vect[0] = 1.e-5;
	x_vect[1] = 1.e-5;
	x_vect[2] = 1.e-5;
	x_vect[3] = 1.e-5;
	if(get_matrix_firstorder_4d(m4d, &band_bias, reference, x_vect[0], x_vect[1], x_vect[2], x_vect[3], latt, part_cross_latt, YES) != TRUE) return FALSE;
	//decouple_matrix_parzen(m4d, decoup_m, decoup_to_coup, output, NULL);
	matrix_inverse_4d(decoup_to_coup, decoup_to_coup_inv);
	
	//av = avmin;
	i = 0;
	*avmax = 0.;
	for(;;) {
		av = avmin+i*avstep;
		CLRSCR();
		printf("amp_v = %lf\t", av);
		fflush(stdout);
		u_vect[0] = au; // u
		u_vect[1] = 0; //uprime
		u_vect[2] = av; //v
		u_vect[3] = 0; //vprime
		mvprod4(x_vect, decoup_to_coup, u_vect);
		test_part = *reference;
		test_part.s = 0;
		test_part.x += x_vect[0]/cos(xprime_ref);
		test_part.z += x_vect[2]/cos(zprime_ref);
		test_part.ux = sin(xprime_ref + x_vect[1])*cos(zprime_ref + x_vect[3]);
		test_part.uy = cos(xprime_ref + x_vect[1])*cos(zprime_ref + x_vect[3]);
		test_part.uz = sin(zprime_ref + x_vect[3]);
		test_part.hat = -2;
		
		if(track_n_turns_amp(xpart, zpart, ux, uy, uz, &test_part, latt, nbpass, 0, 0) != ALIVE) {
			printf("NO!\n");
			break;
		}
		else {
			printf("OK!\n");
			if(outfilename != NULL) {
				for(n=0;n<nbpass;n++) {
					comp_phase_space_coord(&(x_vect[0]), &(x_vect[1]), &(x_vect[2]), &(x_vect[3]), xpart[n], zpart[n], ux[n], uy[n], uz[n], reference->x, xprime_ref, reference->z, zprime_ref);
					mvprod4(u_vect, decoup_to_coup_inv, x_vect);
					fprintf(wfile, "%le  %le  %le  %le  %le  %le  %le  %le  %le\n", x_vect[0], x_vect[1], x_vect[2], x_vect[3], u_vect[0], u_vect[1], u_vect[2], u_vect[3], au);
				}
			}
		}
		i++;
	}
	if(i==0) *avmax = 0.;
	else *avmax = av-avstep;
	if(outfilename != NULL) fclose(wfile);
	printf("final: amp_u = %le\n",*avmax);
	return TRUE;
}

// compute acceptance in (u,u') and (v,v') phase spaces with an initial amplitude in u and v
//return ALIVE if successful
extern int acceptance_uv(char *outfilename, struct Particle *reference, struct Lattice *latt, int nbpass, double au, double av, double decoup_to_coup[4][4])
{
	int i;
	double x_vect[4], u_vect[4], decoup_to_coup_inv[4][4];
	double php_ref, xprime_ref, zprime_ref;//, band_bias, amp_v;
	struct Particle test_part;
	FILE *rfile;
	if(outfilename != NULL) rfile = fopen(outfilename,"a");

	printf("acceptance in u and v:");
	php_ref = sqrt(pow(reference->ux, 2) + pow(reference->uy, 2));
	xprime_ref = atan_ratio(reference->ux, reference->uy);
	zprime_ref  = atan_ratio(reference->uz, php_ref);
	
	u_vect[0] = au; // u
	u_vect[1] = 0; //uprime
	u_vect[2] = av; //v
	u_vect[3] = 0; //vprime
	mvprod4(x_vect, decoup_to_coup, u_vect); //xvect physical space vector x,x',z,z'
	test_part = *reference;
	test_part.s = 0;
	test_part.x += x_vect[0]/cos(xprime_ref);
	test_part.z += x_vect[2]/cos(zprime_ref);
	test_part.ux = sin(xprime_ref + x_vect[1])*cos(zprime_ref + x_vect[3]);
	test_part.uy = cos(xprime_ref + x_vect[1])*cos(zprime_ref + x_vect[3]);
	test_part.uz = sin(zprime_ref + x_vect[3]);
	test_part.hat = -2;
	printf("au = %lf, av = %lf\n", au, av);
	
	for(i = 0; i < nbpass; i++) {
		//CLRSCR();
		//printf("pass number %i\t", i);
		//fflush(stdout);
		if (test_part.uy > 0) {
			comp_phase_space_coord(&(x_vect[0]), &(x_vect[1]), &(x_vect[2]), &(x_vect[3]), test_part.x, test_part.z, test_part.ux, test_part.uy, test_part.uz, reference->x, xprime_ref, reference->z, zprime_ref);
			matrix_inverse_4d(decoup_to_coup, decoup_to_coup_inv);
			mvprod4(u_vect, decoup_to_coup_inv, x_vect);
		}
		else {
			printf("\tin acceptance_uv, test_part.uy <= 0!, particle is going backwards!\n");
			if(outfilename != NULL) fclose(rfile);
			return test_part.status;
		}
		if(outfilename != NULL) fprintf(rfile, "%le  %le  %le  %le  %le  %le  %le  %le  %le  %le\n", x_vect[0], x_vect[1], x_vect[2], x_vect[3], u_vect[0], u_vect[1], u_vect[2], u_vect[3], au, av);
		part_cross_latt(&(test_part), latt, NULL, NULL);
		if(test_part.status != ALIVE) {
			if(outfilename != NULL) fclose(rfile);
			printf("\n");
			return test_part.status;
		}
	}
	if(outfilename != NULL) fclose(rfile);
	printf("\n");
	return test_part.status;
}

// ************************************************************************************ //
//////////////////  Beam tracking  /////////////////////////////////////
// ************************************************************************************ //

extern void beam_oneturn(struct Beam *bunch, struct Lattice *latt, char *txtfile, char *pickupfile)
{
	int i;
	
	for(i = 0; i < bunch->npart ; i++) {
		part_oneturn(&(bunch->part[i]), latt, txtfile, pickupfile);
	}
}

extern void beam_cross_latt(struct Beam *bunch, struct Lattice *latt, char *txtfile, char *pickupfile)
{
	int i;
	
	for(i = 0; i < bunch->npart ; i++) {
		part_cross_latt(&(bunch->part[i]), latt, txtfile, pickupfile);
	}
}

extern void part_oneturn(struct Particle *part, struct Lattice *latt, char *txtfile, char *pickupfile)
{
	int i;
	struct Lattice tempo_latt;

	part->s = 0; //part->s reset to 0 at the beginnig of each new Lattice
	
	//copy a Lattice, with cell[] stored at a diffent memory address, 
	//!!!and DO NOT FORGET to free the allocated memory before exiting part_oneturn!!!
	copy_latt(&tempo_latt, latt);
	if(latt->periodicity == 0) errorstop("!!!ERROR in part_oneturn: cell->periodicity = 0!!!");
	
	if(part->hat == 3) part->t = 0; //force t = 0 for rfscheme.cavity[].dt0 initialization turn
	
	for(i = 0; i < tempo_latt.periodicity; i++) {
		tempo_latt.cellnumber = i;
		//printf("cell %i\n",i);
		part_cross_latt(part, &tempo_latt,txtfile, pickupfile);
		
		//move framework
		latt_move_exit_to_entrance(&tempo_latt);
	}
	
	//free allocated memory
	free(tempo_latt.cell);
}

extern void part_cross_latt(struct Particle *part, struct Lattice *latt, char *txtfile, char *pickupfile)
{
	int i;

	if(latt->nbcell <= 0) errorstop("!!!ERROR in part_cross_latt: latt->nbcell <= 0!!!");
	
	for(i = 0; i < latt->nbcell; i++) {
		if(strcmp(latt->cell[i].keyword, "rf-thingap") == 0) {	//rf cavity
			if(part->hat > 0) {
				//printf("latt->cellnumber = %i\n", latt->cellnumber);
				if (latt->cellnumber < 0) {
					printf("latt->cellnumber = %i\n", latt->cellnumber);
					errorstop("!!!ERROR in part_cross_latt: cannot call part_cross_thingap() since latt->cellnumber < 0!!!\n");
				}
				part_cross_thingap(part, &(latt->cell[i].cav[latt->cellnumber]));
			}
		}
		else if(strcmp(latt->cell[i].keyword, "thin-hdipole") == 0) {
			if(part->hat > 0) part_thindipole(part,  &(latt->cell[i])); //localized dipole kick
		}
		else if(strcmp(latt->cell[i].keyword, "collimator") == 0) {
			if(part->status == ALIVE) part_collimator(part,  &(latt->cell[i])); //localized collimator
		}
		else if(strcmp(latt->cell[i].keyword, "float-faraday") == 0) {
			if(part->status == ALIVE) part_float_faraday(part,  &(latt->cell[i])); //localized collimator
		}
		else {	//in any other case call part_cross_cell
			//printf("\n\n\ncell %i nb of poles %i\n\n\n", i, latt->cell[i].nbcomp);
			if(part_cross_cell(part, &(latt->cell[i]),txtfile, pickupfile) == CUP) break;	//and if part is stop on a cup, break.
		}
	}
	latt->cellnumber = -1; //set cellnumber to a < 0 value, to be sure that a value will be given explicitely later. (other wise errorstop procedure is called, see above)
}

extern int part_cross_cell(struct Particle *part, struct Cell *cell, char *txtfile, char *pickupfile)
{
	int awd_answer;

	//debug tests
	if(part->status != ALIVE) return NO;
	if(cell->stepsize <= 0) errorstop("!!!ERROR in part_cross_cell: stepsize <= 0!!!");

	//change framework and do some checks
	getready_part(part, cell);
	
	//track untill reach a pickup, a cup or the cell boundary 
	awd_answer = part_callrk(part,cell,txtfile, pickupfile);
	
	//if(awd_answer == PICKUP) { //reached a pickup, do not return yet, but swich off the pickup and call part_callrk again.
	//	if(part->status == ALIVE) {
	//		cell->instrutype = NO;
	//		awd_answer = part_callrk(part,cell,txtfile, pickupfile); //call again part_callrk
	//		cell->instrutype = PICKUP; //restore initial status
	//	}
	//}
	if(awd_answer == YES) { //reached boundary, return
		if(part->status == ALIVE) update_part(awd_answer, part, cell);
		return awd_answer;
	}
	if(awd_answer == CUP) { //reached a cup, return
		if(part->status == ALIVE) update_part(awd_answer, part, cell);
		return awd_answer;
	}

	//if(part->status == ALIVE) errorstop("!!!ERROR in part_cross_cell: End of function reached but no boundary reached, while part->status is still =  ALIVE!!!");
	if(part->status == ALIVE) printf("!!!WARNING in part_cross_cell: End of function reached but no boundary reached, while part->status is still =  ALIVE!!!");
	return awd_answer;
}

extern int part_callrk(struct Particle *part, struct Cell *cell, char *txtfile, char *pickupfile)
{
	int awd_answer = NO;

	//track until a pickup of the cell boundary, choosing between the different methods to get the B field
	if (strcmp(cell->keyword, "drift") == 0)			rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_drift);
	else if (strcmp(cell->keyword, "drift-cyl") == 0)		rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_drift);
	else if (strcmp(cell->keyword, "ffag-r-lin") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGradial_lin);
	else if (strcmp(cell->keyword, "ffag-r-enge") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGradial_purescale);
	else if (strcmp(cell->keyword, "ffag-r-he") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGradial_he);
	else if (strcmp(cell->keyword, "ffag-s-he") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGstraight_he);
	else if (strcmp(cell->keyword, "ffag-s-lin") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGstraight_lin);
	else if (strcmp(cell->keyword, "ffag-s-enge") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGstraight_purescale);
	else if (strcmp(cell->keyword, "ffag-s-enge-add") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGstraight_add);
	
	else if (strcmp(cell->keyword, "field-cylmap") == 0) rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, get_bfield_cylindrical_map);
	else if (strcmp(cell->keyword, "field-cylmap-cubic") == 0) rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, get_bfield_cylindrical_map_tricubic);
	else if (strcmp(cell->keyword, "field-cylmap2d") == 0) rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, get_bfield_2dpolarmap);
	else if (strcmp(cell->keyword, "field-cartmap") == 0) rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, get_bfield_cartesian_map);
	else if (strcmp(cell->keyword, "field-cartmap-cubic") == 0) rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, get_bfield_cartesian_map_tricubic);
	else if (strcmp(cell->keyword, "field-cartmap2d") == 0) rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, get_bfield_2dcartmap);
	
	else if (strcmp(cell->keyword, "ffag-spi-he") == 0)		rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGspiral_he);
	else if (strcmp(cell->keyword, "ffag-spi-lin") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGspiral_lin);
	else if (strcmp(cell->keyword, "ffag-spi-enge") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGspiral_enge);
	else if (strcmp(cell->keyword, "polyn-spi-he") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_polynom_spiral_he);
	else if (strcmp(cell->keyword, "polyn-spi-lin") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_polynom_spiral_lin);
	else if (strcmp(cell->keyword, "polyn-spi-enge") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_polynom_spiral_enge);
	else if (strcmp(cell->keyword, "ffag-spi-fullenge") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGspiral_fullenge);
	else if (strcmp(cell->keyword, "ffag-sti-he") == 0)		rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGstraighttilt_he);
	else if (strcmp(cell->keyword, "ffag-sti-lin") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGstraighttilt_lin);
	//else if (strcmp(cell->keyword, "ffag-sti-enge") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_FFAGstraighttilt_purescale);
	else if (strcmp(cell->keyword, "realbend") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_realbend);
	else if (strcmp(cell->keyword, "quad-he") == 0)		rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_quad_he);
	else if (strcmp(cell->keyword, "quad-lin") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_quad_lin);
	else if (strcmp(cell->keyword, "quad-enge") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_quad_enge);
	//else if (strcmp(cell->keyword, "sext-he") == 0)		errorstop("sext-he not implemented yet\n");
	//else if (strcmp(cell->keyword, "sext-lin") == 0)	errorstop("sext-lin not implemented yet\n");
	//else if (strcmp(cell->keyword, "sext-enge") == 0)	errorstop("sext-enge not implemented yet\n");
	//else if (strcmp(cell->keyword, "oct-he") == 0)		errorstop("sext-he not implemented yet\n");
	//else if (strcmp(cell->keyword, "oct-lin") == 0)	errorstop("sext-lin not implemented yet\n");
	//else if (strcmp(cell->keyword, "oct-enge") == 0)	errorstop("sext-enge not implemented yet\n");
	//else if (strcmp(cell->keyword, "purebend-he") == 0)		errorstop("purebend-he not implemented yet\n");
	else if (strcmp(cell->keyword, "purebend-lin") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_sector_purebend_lin);
	else if (strcmp(cell->keyword, "purebend-enge") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_sector_purebend);

	else if (strcmp(cell->keyword, "vffa-rect-he") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_rect_he);
	else if (strcmp(cell->keyword, "vffa-rect-lin") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_rect_lin);
	else if (strcmp(cell->keyword, "vffa-rect-enge") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_rect_enge);
	else if (strcmp(cell->keyword, "vffa-rect-atan") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_rect_atan);
	else if (strcmp(cell->keyword, "vffa-rect-enge-add") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_rect_enge_add);
	else if (strcmp(cell->keyword, "vffa-rect-enge-separ") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_rect_enge_separate_func);
	else if (strcmp(cell->keyword, "vffa-rect-enge-bx") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_rect_bx_add);
	
	else if (strcmp(cell->keyword, "vffa-rect-str-he") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_rect_he_str);
	else if (strcmp(cell->keyword, "vffa-rect-str-lin") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_rect_lin_str);
	else if (strcmp(cell->keyword, "vffa-rect-str-enge") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_rect_str_enge);
	else if (strcmp(cell->keyword, "vffa-rect-atan-str") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_rect_str_atan);
	
	//else if (strcmp(cell->keyword, "vffa-sect-he") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, add_field_comp_VFFA_sect_he);
	else if (strcmp(cell->keyword, "vffa-sect-lin") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_sect_lin);
	else if (strcmp(cell->keyword, "vffa-sect-enge") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, pickupfile, add_field_comp_VFFA_sect_enge);
	//else if (strcmp(cell->keyword, "multiple-poles") == 0)	rkdrive(part, &awd_answer, cell->stepsize,derivs,cell,txtfile, add_multiple_poles);
	
	else{
		printf("\n!!!ERROR 2 in part_callrk: unexpected keyword : \"%s\"!!!\n", cell->keyword);
		errorstop("unexpected Cell's keywork");
	}
	return awd_answer;
}

extern void part_cross_thingap(struct Particle *part, struct Cavity *cav)
{
	double e_tot_part, wt, v_rf, brho_before;//, u_hp_before;
	
	wt = TWOPI*(part->t - cav->t0)*cav->frf;
	wt	= wt - floor(wt/(TWOPI))*TWOPI;
	//printf("wt=%lf\n", wt);
	//if(part->hat == 3) {	//if part->hat == 3, it means that we are initializing cav->t0... 
	//	cav->t0 = part->t;
	//	wt= 0;
	//}
	
	v_rf= cav->v0*sin(wt + cav->phi0);
	//printf("wt+phi0=%lf [deg]\n", (wt+cav->phi0)*180./(PI));
	//printf("vrf=%le [V], phi = %lf\n", v_rf, (wt+cav->phi0)*180./PI);
	
	e_tot_part	= sqrt(pow(part->m0*CLIGHT2,2) + (part->brho*part->q*part->brho*part->q)*CLIGHT2) + v_rf*part->q;
	//printf("etotpart=%le, delta e = %le\n", e_tot_part, v_rf*part->q);
	
	if(e_tot_part - part->m0*CLIGHT2 <= 0) { //kill particle if stoped or strats going bakward
		printf("\n!Warning in part_cross_thingap: particle is going backward, particle marked as lost (LOST_BACK)!\n");
		part->status = LOST_BACK;
		return;
	}
	
	//u_hp_before = sqrt(part->ux*part->ux + part->uy*part->uy);
	brho_before = part->brho;
	part->brho = sqrt(e_tot_part*e_tot_part/(CLIGHT2) - part->m0*CLIGHT2*part->m0)/part->q;
	
	//assuming that Px and Pz are unchanged:
	//part->uy = brho_before/part->brho*sqrt(pow(part->brho/brho_before,2) - part->ux*part->ux - part->uz*part->uz);
	part->ux = part->ux*brho_before/part->brho;
	part->uz = part->uz*brho_before/part->brho;
	part->uy = sqrt(1. - part->ux*part->ux - part->uz*part->uz);
	
	if(isnan(part->uy)) {
		printf("\n!Warning in part_cross_thingap: error has been done computing rf kick, particle marked as (LOST_ERR_RF),\nv_rf = %le, part->ux =%le, brho_before = %le, part->brho =%le\n", v_rf, part->ux, brho_before, part->brho);
		part->status = LOST_ERR_RF;
	}
	
}

extern void part_thindipole(struct Particle *part, struct Cell *cell)
{
	double xprime, uhp;
	
	uhp = sqrt(part->ux*part->ux + part->uy*part->uy);
	xprime = atan(part->ux/part->uy);
	xprime += cell->mpara[0][0]/part->brho; // kick of an angle BL*q/p
	part->ux = uhp*sin(xprime);
	part->uy = uhp*cos(xprime);
}

extern void part_collimator(struct Particle *part, struct Cell *cell)
{
	double r;
	
	if(cell->boun.thmax != 0) r = sqrt(part->x*part->x + part->y*part->y);
	else r = part->x;
	
	
	if(r < cell->collim.rmin) {
			printf("part_collimator: particle hits Horizontal aperture,  r = %lf < rmin = %lf [m]\n", r, cell->collim.rmin);
			part->status = LOST_H_MIN;
			return;
	}
	if(r > cell->collim.rmax) {
			printf("part_collimator: particle hits Horizontal aperture,  r = %lf > rmax = %lf [m]\n", r, cell->collim.rmax);
			part->status = LOST_H_MAX;
			return;
	}
	if(part->z < cell->collim.zmin) {
			printf("part_collimator: particle hits Vertical aperture, z = %lf < zmin = %lf [m]\n", part->z, cell->collim.zmin);
			part->status = LOST_V_MIN;
			return;
	}
	if(part->z > cell->collim.zmax) {
			printf("part_collimator: particle hits Vertical aperture, z = %lf > zmax = %lf [m]\n", part->z, cell->collim.zmax);
			part->status = LOST_V_MAX;
			return;
	}
}

// careful with vffa?
extern void part_float_faraday(struct Particle *part, struct Cell *cell)
{
	double r;
	
	if(cell->boun.thmax != 0) r = sqrt(part->x*part->x + part->y*part->y);
	else r = part->x;
	
	
	if(r > cell->collim.rmin && r < cell->collim.rmax) {
		printf("part_float_faraday: particle hits faraday cup, rmin = %lf < r = %lf < rmax = %lf [m]\n", cell->collim.rmin, r, cell->collim.rmax);
		part->status = LOST_FARADAY;
		return;
	}
}

extern void derivs(struct Particle *part, double dfds[], double bprobe[], struct Cell *cell,
	void(*add_contribution_comp)(double,double,double,double*,double*,double*,struct Cell*,int))
{
	double gamma;
	
	//Note: bprobe[0] = bx, bprobe[1] = by, and bprobe[2] = bz;
	part->status = get_bfield(part->x,part->y, part->z, &bprobe[0], &bprobe[1], &bprobe[2], cell, add_contribution_comp);
	//if(part->status!=ALIVE) printf("part status: %i\n", part->status);
	//printf("part_status=%i\n",part->status);
	//printf("part:x=%lf,y=%lf,z=%lf,ux=%lf,uy=%lf,uz=%lf\n",part->x,part->y, part->z, part->ux,part->uy, part->uz);
	//printf("b:%lf,%lf,%lf\n", bprobe[0],bprobe[1],bprobe[2]);
	
	dfds[0] = part->ux; //dx/ds
	dfds[1] = part->uy; //dy/ds
	dfds[2] = part->uz; //dz/ds
	dfds[3] = (part->uy*bprobe[2] - part->uz*bprobe[1])/part->brho; //dux/ds
	dfds[4] = (part->uz*bprobe[0] - part->ux*bprobe[2])/part->brho; //duy/ds
	dfds[5] = (part->ux*bprobe[1] - part->uy*bprobe[0])/part->brho; //duz/ds
	gamma = sqrt(1. + pow(part->q*part->brho/(part->m0*CLIGHT),2)); //reltivistic gamma
	dfds[6] = gamma/(CLIGHT*sqrt(gamma*gamma - 1.)); //dt/ds (= 1/(beta*CLIGHT))
	//printf("%lf,%lf,%lf,%lf,%lf,%lf,%lf\n", dfds[0], dfds[1],dfds[2],dfds[3],dfds[4],dfds[5],dfds[6]);
}

