/*
 *  main.c
 *  Fixfield
 *
 *  Created by Jean-Baptiste Lagrange on 12/1/09.
 *  Copyright 2009 Kyoto University. All rights reserved.
 *
 */

#include "main.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
//int main(void) {
	int comp_ph_adv_scan,comp_tune,comp_adj_r0,comp_accx,comp_accz,comp_acc_2d,comp_disp,comp_beta,comp_plot_betafunc,comp_plot_disp,comp_track;
	struct Lattice latt;
	struct Beam beam;
	
	/* global variables initialisation */
	//sound_option = NO;
	//debug = YES;
	//doyou_long_boun_sym = YES;
	//write_enge = NO;
	//print_color = YES;
	//force_spi_deg = 30.;
	//force_spi_r0 = 4.;
	
	//if(print_color==YES) COLOR("46");
	printf("\nFixField code, Tracking code RK4\n");
	printf("__________    __________  _____ __   _____   \n");
	printf("| ____| \\ \\  / | ____| | |  ___| |   |  _ \\  \n");
	printf("| |_  | |\\ \\/ /| |_  | | | |_  | |   | | \\ \\ \n");
	printf("| __| | | )  ( | __| | | |  _| | |   | |  ) )\n");
	printf("| |   | |/ /\\ \\| |   | | | |___| |___| |_/ / \n");
	printf("|_|   |_/_/  \\_|_|   |_| |_____|_____|____/  \n");
	//if(print_color==YES) COLOR("0");
	printf("\n");
	
	///* empty output files */
	//struct stat st= {0};
	//if(stat("data", &st) == -1) {
	//	FILE *shell_read;
	//	shell_read = popen("mkdir data","r");
	//	pclose(shell_read);
	//}
	if(argc<4) errorstop("argument missing:\n1. lattice file name,\n2.read beam file name,\n3. write beam file name\n");
	
	load_lattice(&latt, argv[1]);
	//load_beam(&beam, argv[2], &latt, YES);
	double x_offset = 49.07538815;
	load_textfile_beam_nustorm(&beam, argv[2], x_offset);
	
	//print_beam_para("beam", &beam);
	//load_lattice(&latt, "inputs/fodo_enge.latt");
	//load_beam(&beam, "inputs/proton.beam", &latt, YES);
	
	// ************************************************************************************ //
	//									main loop(s)										//
	// ************************************************************************************ //
	
	///////////////  phase advance scan  //////////////
	comp_ph_adv_scan = NO;
	if(comp_ph_adv_scan == YES) {
		emptyfile("data/tune_fets_ffa_proto_16fold.dat");
		//emptyfile("data/scan_ph_adv.dat");
		phase_adv_scan("data/tune_fets_ffa_proto_16fold.dat", &latt, &(beam.part[0]), 1.e-12, 3.0e6, 12.0e6, 300, 1.e-5);
		//phase_adv_scan_woco("data/scan_ph_adv.dat", &latt, &(beam.part[0]), 2.896202e9, 4.303608e9, 50, 1.e-4); //nustorm FODO 3.8 gev/c -8.1% to +9.2%
		easyplot2("data/tune_fets_ffa_proto_16fold.dat", "data/tune_fets_ffa_proto_16fold.dat", "($1*1.e-6)", "2", "($1*1.e-6)", "3", "lines lt 1 lw 2 lc 3", "lines lt 2 lw 2 lc 1", "horizontal", "vertical", "Ekin [MeV]", "{/Symbol n}_x_,_z []", NULL, NULL, "data/tune_fets_ffa_proto_16fold", NULL);
	}
	
	/////////////////  ADJUST RADIUS /////////////////
	comp_adj_r0 = NO;
	if(comp_adj_r0==YES) {
		//double r0;
		//adjust_r0_with_b0(&latt, &(beam.part[0]), 2.914, &r0, 1.e-9);
		adjust_rav_with_b0_ffag_spi(&latt, &(beam.part[0]), 4.006,1.e-12, 1.e-5);
		//adjust_r0_with_b0_ffag_spi(&latt, &(beam.part[0]), 4., 1.e-10, 1.e-6); //3 MeV
		//adjust_rav_with_b0_ffag_spi(&latt, &(beam.part[0]), 4., 1.e-10, 1.e-6);
	}
	
	/////////////////  Tune - Amplitude  /////////////////
	comp_tune = NO;
	if(comp_tune == YES) {
		double qx, qz, beta_x, alpha_x, beta_z, alpha_z;
		struct Beam beam2;
		load_beam(&beam2, "data/muon5-2gevc.beam", &latt, YES);
		calc_tune_twiss(&(beam2.part[0]), &qx, &qz, &beta_x, &alpha_x, &beta_z, &alpha_z, 1.e-5, 1.e-5, 1.e-5, 1.e-5, &latt, part_cross_latt, YES, NULL, 0);//flag: 0=2d, 1=4d decoupled, anything else=4d undecoupled.
		free_beam(&beam);
	}
	
	/////////////////   acceptancex   /////////////////
	comp_accx = NO;
	if(comp_accx == YES) {
		int offset = YES;
		double z_offset, axmax=0, emitmax, gamma_x, gamma_z, e_tot, beta_lor, gamma_lor;
		double qx, qz, beta_x, alpha_x, beta_z, alpha_z;
		calc_tune_twiss(&(beam.part[0]), &qx, &qz, &beta_x, &alpha_x, &beta_z, &alpha_z, 1.e-5, 1.e-5, 1.e-5, 1.e-5, &latt, part_cross_latt, YES, NULL,0);//flag: 0=2d, 1=4d decoupled, anything else=4d undecoupled.
		gamma_x = (1+alpha_x*alpha_x)/beta_x;
		gamma_z = (1+alpha_z*alpha_z)/beta_z;
		get_ebg_part(&e_tot, &beta_lor, &gamma_lor, &(beam.part[0]));
		if(offset==YES) {
			z_offset = sqrt(10.e-6/gamma_z/beta_lor/gamma_lor);
		}
		else z_offset = 0.01;
		printf("gammax=%le\t", gamma_x);
		printf("gammaz=%le\t", gamma_z);
		printf("z_offset=%le\n", z_offset);
		emptyfile("data/poincarex.dat");
		acceptancex_auto(NULL, &(beam.part[0]), &latt, 1000, 0.01, &axmax, 0.01, z_offset);
		emitmax = axmax*axmax*gamma_x;
		printf("\tUnnormalised emittance max %le [mm]\n", emitmax*1000);
		printf("\tNormalised emittance max %le [mm]\n", emitmax*beta_lor*gamma_lor*1000);
		//acceptancex("data/poincarex.dat", &(beam.part[0]), &latt, 1000, 0.056, 0.061, 0.07, z_offset);
		//easyplot("data/poincarex.dat", "($1*1000)", "($2*1000)", "points pt 7 ps 0.8","x [mm]", "x\251 [mrad]", NULL, NULL, "data/poincarex","mxtics 5\nset mytics 5");
		write_ellipse("data/ellipsex.dat", emitmax*1.e6, beta_x, alpha_x, 0.0, 0);
		//write_ellipse2("data/ellipsex.dat", emitmax*1.e6, beta_x, alpha_x, 0.0, 0);
		//easyplot("data/ellipsex.dat", "($1*1000)", "($2*1000)","lines lw 4 lc 0", "x [mm]", "x\251 [mrad]", NULL, NULL, "data/ellipse","mxtics 5\nset mytics 5");
		easyplot2("data/poincarex.dat", "data/ellipsex.dat", "($1*1000)", "($2*1000)", "($1*1000)", "($2*1000)", "points pt 7 ps 0.8", "lines lw 4 lc 0", NULL,NULL,"{/Symbol D}r [mm]", "{/Symbol D}r\251 [mrad]", NULL, NULL, "data/poincarex","mxtics 5\nset mytics 5");
		easyplot("data/poincarex.dat", "($3*1000)", "($4*1000)","points pt 7 ps 1.", "z [mm]", "z\251 [mrad]", NULL, NULL, "data/poincarex_otherplane","mxtics 5\nset mytics 5");
	}
	
	/////////////////   acceptancez   /////////////////
	comp_accz = NO;
	if(comp_accz == YES) {
		int offset = YES;
		double x_offset, azmax=0, gamma_x, gamma_z, emitmax, e_tot, beta_lor, gamma_lor;
		double qx, qz, beta_x, alpha_x, beta_z, alpha_z;
		calc_tune_twiss(&(beam.part[0]), &qx, &qz, &beta_x, &alpha_x, &beta_z, &alpha_z, 1.e-5, 1.e-5, 1.e-5, 1.e-5, &latt, part_cross_latt, YES, NULL,0);//flag: 0=2d, 1=4d decoupled, anything else=4d undecoupled.
		gamma_x = (1+alpha_x*alpha_x)/beta_x;
		gamma_z = (1+alpha_z*alpha_z)/beta_z;
		get_ebg_part(&e_tot, &beta_lor, &gamma_lor, &(beam.part[0]));
		if(offset==YES) {
			//printf("gamma=%le\t", gamma_z);
			x_offset = sqrt(10.e-6/gamma_x/beta_lor/gamma_lor);
		}
		else x_offset = 0.001;
		printf("gammax=%le\t", gamma_x);
		printf("gammaz=%le\t", gamma_z);
		printf("x_offset=%le\n",x_offset);
		emptyfile("data/poincarez.dat");
		acceptancez_auto(NULL, &(beam.part[0]), &latt, 1000, 0.01, &azmax, 0.01, x_offset); 
		//acceptancez("data/poincarez.dat", &(beam.part[0]), &latt, 1000, 0.02, 0.021, 0.03, x_offset);
		//acceptancezprime("data/poincarez.dat", &(beam.part[0]), &latt, 200, -0.002, -0.003, 0.002, 0.001);
		emitmax = azmax*azmax*gamma_z;
		printf("\tUnnormalised emittance max %le [mm]\n", emitmax*1000);
		printf("\tNormalised emittance max %le [mm]\n", emitmax*beta_lor*gamma_lor*1000);
		//easyplot("data/poincarez.dat", "($3*1000)", "($4*1000)","points pt 7 ps 1.", "z [mm]", "z\251 [mrad]", NULL, NULL, "data/poincarez", "mxtics 5\nset mytics 5");	
		
		write_ellipse("data/ellipsez.dat", emitmax*1.e6, beta_z, alpha_z, 0, 0);
		easyplot2("data/poincarez.dat", "data/ellipsez.dat", "($3*1000)", "($4*1000)", "($1*1000)", "($2*1000)", "points pt 7 ps 0.8", "lines lw 4 lc 0",NULL,NULL, "z [mm]", "z\251 [mrad]", NULL, NULL, "data/poincarez", "mxtics 5\nset mytics 5");
		//easyplot("data/poincarez.dat", "($3*1000)", "($4*1000)","points pt 7 ps 1.", "z [mm]", "z\251 [mrad]", NULL, NULL, "data/poincarez", "xtics 50\nset mxtics 5\nset mytics 5");	
		easyplot("data/poincarez.dat", "($1*1000)", "($2*1000)","points pt 7 ps 1.", "{/Symbol D}r [mm]", "{/Symbol D}r\251 [mrad]", NULL, NULL, "data/poincarez_otherplane", "mxtics 5\nset mytics 5");	
	}
	
	comp_acc_2d = NO;
	if(comp_acc_2d == YES) {
		double emitmax=0, e_tot, beta_lor, gamma_lor;
		double qx, qz, beta_x, alpha_x, beta_z, alpha_z;
		calc_tune_twiss(&(beam.part[0]), &qx, &qz, &beta_x, &alpha_x, &beta_z, &alpha_z, 1.e-5, 1.e-5, 1.e-5, 1.e-5, &latt, part_cross_latt, NO, NULL,0);//flag: 0=2d, 1=4d decoupled, anything else=4d undecoupled.
		get_ebg_part(&e_tot, &beta_lor, &gamma_lor, &(beam.part[0]));
		
		//emptyfile("data/poincare2d_12mev.dat");
		//emptyfile("data/poincare2d_1_2gev_fd.dat");
		printf("ori_latt\n");
		acceptance_2d_emit_auto(NULL, &(beam.part[0]), &latt, 1000, 500.e-6, &emitmax, 5.e-6);
		//acceptance_2d_emit_auto2(NULL, &(beam.part[0]), &latt, 1000, 200.e-6, &emitmax, 128.e-6, 3.e-6);
		
		//acceptance_2d_emit_auto("data/poincare2d.dat", &(beam.part[0]), &latt, 6000, 5.e-4, &emitmax, 5.e-5);
		printf("\tNormalised emittance max %le [mm]\n", emitmax*beta_lor*gamma_lor*1000);
	//	emitmax = 8.e-4;
		//printf("modif_latt\n");
		//acceptance_2d_emit_auto("data/poincare2d_2.dat", &(beam2.part[0]), &latt2, 4000, 1.e-4, &emitmax, 1.e-5);
		//printf("\tNormalised emittance max %le [mm]\n", emitmax*beta_lor*gamma_lor*1000);
	//	acceptancex("data/poincare2d_3mev.dat", &(beam.part[0]), &latt, 4000,  0.028244, 0.050036, 0.07, 0.033536);
		//acceptancex("data/poincare2d_12mev.dat", &(beam.part[0]), &latt, 1000,  0.035051, 0.050036, 0.07, 0.043489);
		//printf("\tNormalised emittance max %le [mm]\n", emitmax*beta_lor*gamma_lor*1000);
	//	write_ellipse("data/ellipsex.dat", emitmax*1.e6, beta_x, alpha_x, 0, 0);
		//write_ellipse("data/ellipsex.dat", 00131*1.e2, beta_x, alpha_x, 0, 0); //8.000000e-04 
		//write_ellipse2("data/ellipsex.dat", 00131*1.e6, beta_x, alpha_x, 0, 0);
	//	easyplot2("data/poincare2d_3mev.dat", "data/ellipsex.dat", "($1*1000)", "($2*1000)", "($1*1000)", "($2*1000)", "points pt 7 ps 0.8", "lines lw 4 lc 0",NULL,NULL, "{/Symbol D}r [mm]", "{/Symbol D}r\251 [mrad]", NULL, NULL, "data/poincare2d_x", "mxtics 5\nset mytics 5");
	//	write_ellipse("data/ellipsez.dat", emitmax*1.e6, beta_z, alpha_z, 0, 0);
		//write_ellipse("data/ellipsez.dat", 00131, beta_z, alpha_z, 0, 0);
		//write_ellipse2("data/ellipsez.dat", 00131*1.e6, beta_z, alpha_z, 0, 0);
	//	easyplot2("data/poincare2d_3mev.dat", "data/ellipsez.dat", "($3*1000)", "($4*1000)", "($1*1000)", "($2*1000)", "points pt 7 ps 0.8", "lines lw 4 lc 0",NULL,NULL, "z [mm]", "z\251 [mrad]", NULL, NULL, "data/poincare2d_z", "mxtics 5\nset mytics 5");
		//easyplot("data/poincare2d_12mev.dat", "($3*1000)", "($4*1000)","points pt 7 ps 1.", "z [mm]", "z\251 [mrad]", NULL, NULL, "data/poincare2d_zzprime", "mxtics 5\nset mytics 5");
		//easyplot("data/poincare2d_12mev.dat", "($1*1000)", "($2*1000)","points pt 7 ps 1.", "{/Symbol D}r [mm]", "{/Symbol D}r\251 [mrad]", NULL, NULL, "data/poincare2d_xxprime", "mxtics 5\nset mytics 5");	
		//easyplot("data/poincare2d_3mev.dat", "($1*1000)", "($2*1000)","points pt 7 ps 1.", "{/Symbol D}r [mm]", "{/Symbol D}r\251 [mrad]", NULL, NULL, "data/poincare2d_xxprime", "mxtics 5\nset mytics 5");	
		//easyplot("data/poincare2d_3mev.dat", "($3*1000)", "($4*1000)","points pt 7 ps 1.", "z [mm]", "z\251 [mrad]", NULL, NULL, "data/poincare2d_zzprime", "mxtics 5\nset mytics 5");
	}
	
	/////////////////  Dispersion  /////////////////
	comp_disp = NO;
	if(comp_disp==YES) {
		//double disp0=0., dispprime0=0.;
		emptyfile("data/dispersion.dat");
		//compute_dispersion_2d("data/dispersion.dat", 100, 1.e-4, 1.e-4, 1.e-4, &(beam.part[0]), &latt, disp0, dispprime0, YES);
		compute_periodic_dispersion_2d("data/dispersion.dat", 100, 1.e-5, 1.e-5, 1.e-5, &(beam.part[0]), &latt, YES);
	}

	/////////////////   Betafunctions   /////////////////
	comp_beta = NO;
	if(comp_beta==YES) {
		//force_spi_deg = 0;
		//force_spi_r0 = 0;
		emptyfile("data/betafunc.dat");
		//compute_betafunc("data/betafunc.dat", 30, 1.e-4, 1.e-4, 1.e-4, 1.e-4, &(beam.part[0]), &latt, betax0, alphax0, betaz0, alphaz0, 0);
		compute_periodic_betafunc("data/betafunc.dat", 100, 1.e-5, 1.e-5, 1.e-5, 1.e-5, &(beam.part[0]), &latt, 0);
	}
	
	/////////////   Plots Betafunc dispersion   //////////
	comp_plot_betafunc = NO;
	comp_plot_disp = NO;
	if(comp_plot_betafunc==YES) {
		char xrange[100], betarange[100];
		//char xrange2[100], betarange2[100];
		get_xrange("data/betafunc.dat", xrange);
		get_betarange("data/betafunc.dat", betarange);
		emptyfile("data/efb_betafunc.dat");
		write_efb_txtfile("data/efb_betafunc.dat", &(beam.part[0]), &latt);
		if(comp_plot_disp==YES) {
			char disprange[100];
			get_disprange("data/dispersion.dat", disprange);
			get_xrange("data/dispersion.dat", xrange);
			easyplot_beta_disp("data/betafunc.dat", "data/dispersion.dat", "data/efb_betafunc.dat", "1", "2", "1", "4", "1", "2", "lines lt 1 lw 4 lc 3","lines lt 2 lw 4 lc 1", "lines lt 5 lw 6 lc rgb 'forest-green'",
			//easyplot_beta_disp("data/betafunc.dat", "data/dispersion.dat", NULL, 
			"s [m]", "{/Symbol b} [m]", " {/Symbol h}[m]", xrange, betarange, disprange, "data/beta_disp", "y2tics 0.05 offset -1.5,0\nset grid", 0.1, CR);
		}
		else {
			easyplot2("data/betafunc.dat", "data/betafunc.dat", "1", "2", "1", "4","lines lt 1 lw 4 lc 3","lines lt 2 lw 4 lc 1","horizontal", "vertical", "s [m]", "{/Symbol b} [m]", xrange, betarange, "data/betafunc", "grid\nset mxtics 5\nset mytics 5\n");
			//get_xrange("inputs/fets/4_fold_sym/shinji/betafunc_12mev_4fold.dat", xrange);
			//get_betarange("inputs/fets/4_fold_sym/shinji/betafunc_12mev_4fold.dat", betarange);
			//easyplot2("inputs/fets/4_fold_sym/shinji/betafunc_12mev_4fold.dat", "inputs/fets/4_fold_sym/shinji/betafunc_12mev_4fold.dat", "1", "2", "1", "4","lines lt 1 lw 4 lc 3","lines lt 2 lw 4 lc 1","horizontal", "vertical", "s [m]", "{/Symbol b} [m]", xrange, betarange, "inputs/fets/4_fold_sym/shinji/betafunc_12mev_4fold", "grid\nset mxtics 5\nset mytics 5\n");
			
			//easyplot3("data/betafunc_3mev_4fold.dat", "data/betafunc_3mev_4fold.dat", "data/efb_betafunc.dat", "1", "2", "1", "4", "1", "($2*0.5)", "lines lt 1 lw 4 lc 3","lines lt 2 lw 4 lc 1", "lines lt 1 lc 0 lw 1", 
			//"horizontal", "vertical", NULL,"s [m]", "{/Symbol b} [m]", xrange, betarange, "data/betafunc_3mev_4fold-efb", "grid\nset mxtics 5\nset mytics 5\n");
			//easyplot3("data/betafunc.dat", "data/betafunc.dat", "data/efb_betafunc.dat", "1", "2", "1", "4", "1", "($2*0.5+2)", "lines lt 1 lw 4 lc 3","lines lt 2 lw 4 lc 1", "lines lt 1 lc 0 lw 1", 
			//"horizontal", "vertical", NULL,"s [m]", "{/Symbol b} [m]", xrange, betarange, "data/betafunc-efb", "grid\nset mxtics 5\nset mytics 5\n");
		}
	}
	
	////////////////   Tracking   ////////////////////
	comp_track = YES;
	if(comp_track==YES) {
		//trackout output:
		//1: s; 2: x; 3: y; 4: z; 5: bx; 6: by; 7: bz; 8: ux; 9: uy; 10: uz; 
		//11: r; 12: theta_deg; 13: th_glob_deg; 14: br; 15: btheta; 16: Brho
		//emptyfile("data/trackout.dat");
		//part_cross_latt(&(beam.part[0]), &latt, "data/trackout.dat", NULL);
		printf("start tracking...\n");
		//beam_cross_latt(&beam, &latt, "data/trackout.dat", NULL);
		beam_cross_latt(&beam, &latt, NULL, NULL);
		printf("tracking done.\n");
		export_textfile_beam_nustorm(&beam, argv[3], x_offset);
		//auto_plot_trackout_gen("data/trackout.dat", "th_glob_deg", "bz", 1, 0, 1, 0, "lines lw 3 lc 7", "theta global [deg]", "B vert [T]", "data/bz_thglob", NULL);
		//auto_plot_trackout_gen("data/trackout.dat", "s", "bz", 1, 0, 1, 0, "lines lw 3 lc 7", "s [m]", "B vert [T]", "data/bz_s", NULL);
		//auto_plot_trackout_gen("data/trackout.dat", "s", "r", 1, 0, 1, 0, "lines lw 3 lc 7", "s [m]", "r [m]", "data/r_s", NULL);
		//auto_plot_traj(&latt, "data/trackout.dat", "data/aspect.dat", "data/traj_hor_long", "size ratio -1");
	}
	
	// ************************************************************************************ //
	//										terminate										//
	// ************************************************************************************ //
	printf("clean up...");
	free_latt(&latt);
	free_beam(&beam);
	
	//if(sound_option==YES) say("-v Daniel 'computation is done'");
	//if(print_color==YES) COLOR("0");
	printf("\nDONE\n");
	return 0;
}

