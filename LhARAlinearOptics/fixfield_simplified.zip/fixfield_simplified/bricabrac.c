/*
 *  bricabrac.c
 *  Fixfield
 *
 *  Copyright 2009 Kyoto University. All rights reserved.
 *
 */


#include "bricabrac.h"

extern void load_textfile_beam_nustorm(struct Beam *beam, char *textfile, double x_offset)
{
	int n = get_nb_lines_file(textfile);
	double m0,q,x,y,z,ptot,ux,uy,uz,px,py,pz;
	printf("reading %s... (%i lines)\n", textfile, n);
	FILE *rfile = NULL;
	rfile = fopen(textfile, "r");
	if(rfile==NULL) errorstop("file cannot be read\n");
	newline(rfile);
	printf("create beam made of %i particle(s)...\n", n-1);
	if(n<2) errorstop("file does not have the minimum number of lines. Abort.\n");
	alloc_beam(beam, n-1);
	
	for(int i = 0;i<n-1;i++) {
		fscanf(rfile, "%le	%le	%le	%le	%le	%le	%le	%le	%le",&m0,&q,&x,&y,&z,&ptot,&ux,&uy,&uz);
		//printf("%le	%le	%le	%le	%le	%le	%le	%le	%le\n", m0,q,x,y,z,ptot,ux,uy,uz);
		x+=x_offset;
		m0 = m0*1.e6*UNITCHARGE/(CLIGHT2); //convert to [kg]
		q = q*UNITCHARGE; //convert to [C]
		ptot = ptot/CLIGHT*(UNITCHARGE)*1.e6; //[MeV/c] to SI
		px = ux*ptot;
		py = uy*ptot;
		pz = uz*ptot;
		//gene_singlepart(&(beam->part[i]), m0, q, x, y, z, px, py, pz, 0, NO);
		gene_singlepart(&(beam->part[i]), m0, q, x, 0, z, px, py, pz, 0, NO);
	}
	fclose(rfile);
	printf("beam created.\n");
}

extern void export_textfile_beam_nustorm(struct Beam *beam, char *textfile, double x_offset)
{
	int n = 0;
	FILE *wfile = NULL;
	wfile = fopen(textfile, "w");
	if(wfile==NULL) errorstop("cannot open file\n");
	
	printf("writing beam parameters in %s...\n", textfile);
	fprintf(wfile, "m0 [MeV*c^-2], q [unit charge], x [m], y [m], z [m], Ptot [MeV/c], ux [], uy [], uz []\n");
	for(int i = 0;i<beam->npart;i++) {
		double ptot, m0, q;
		if(beam->part[i].status == ALIVE) {
			ptot = beam->part[i].brho*beam->part[i].q*CLIGHT/(UNITCHARGE)/1.e6; //SI to [MeV/c]
			m0 = beam->part[i].m0/1.e6/UNITCHARGE*(CLIGHT2); //convert to [MeV*c^-2]
			q = beam->part[i].q/UNITCHARGE; //convert to [q.C]
			//fprintf(wfile, "%.9e	%.9e	%.9e	%.9e	%.9e	%.9e	%.9e	%.9e	%.9e\n", round_nb(m0,10),round_nb(q,10),round_nb(beam->part[i].x-x_offset, 10),round_nb(beam->part[i].y, 10),round_nb(beam->part[i].z, 10), round_nb(ptot,10), round_nb(beam->part[i].ux/shouldbeone, 10),round_nb(beam->part[i].uy/shouldbeone, 10),round_nb(beam->part[i].uz/shouldbeone, 10));
			//fprintf(wfile, "%.9e	%.9e	%.9e	%.9e	%.9e	%.9e	%.9e	%.9e	%.9e\n", round_nb(m0,10),round_nb(q,10),round_nb(beam->part[i].x-x_offset, 10),round_nb(beam->part[i].y, 10),round_nb(beam->part[i].z, 10), round_nb(ptot,10), (beam->part[i].ux/shouldbeone),(beam->part[i].uy/shouldbeone),(beam->part[i].uz/shouldbeone));
			fprintf(wfile, "%le	%le	%le	%le	%le	%le	%le	%le	%le\n", round_nb(m0,10),round_nb(q,10),round_nb(beam->part[i].x-x_offset, 10),round_nb(beam->part[i].y, 10),round_nb(beam->part[i].z, 10), round_nb(ptot,10), (beam->part[i].ux),(beam->part[i].uy),(beam->part[i].uz));
			n++;
		}
	}
	fclose(wfile);
	printf("writing done.\n%i/%i particles survived tracking\n", n, beam->npart);
}